schedule function c164art:obs-motion/c40/3 4t replace
data merge entity @e[type=minecraft:item_display,x=6.4006,y=203.3125,z=0.5,distance=..0.05,tag=m.mach_clock_pendulum,limit=1] {start_interpolation:0,interpolation_duration:7,transformation:{left_rotation:[0.0f,0.0f,-0.048726f,0.998812f],right_rotation:[0.0f,0.0f,0.0f,1.0f],scale:[1.0f,1.0f,1.0f],translation:[-0.068439f,-0.699786f,0.0f]}}
particle minecraft:campfire_signal_smoke 87.4 223.8 23.1 0.0262 1.0 0.1944 0.0651 0 force
