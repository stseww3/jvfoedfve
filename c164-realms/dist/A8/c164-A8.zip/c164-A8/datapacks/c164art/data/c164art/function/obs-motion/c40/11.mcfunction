schedule function c164art:obs-motion/c40/12 2t replace
particle minecraft:wax_off -23.0 200.7688 -2.4375 0.0 0.0 0.0 0.0 1 normal
