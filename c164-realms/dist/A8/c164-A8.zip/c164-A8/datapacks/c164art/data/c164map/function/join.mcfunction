scoreboard players set @s c164j 0
gamemode adventure @s
attribute @s minecraft:block_interaction_range base set 0
execute at @s run function #c164map:join
