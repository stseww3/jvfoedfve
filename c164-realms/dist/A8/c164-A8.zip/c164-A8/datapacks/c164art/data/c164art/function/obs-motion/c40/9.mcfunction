schedule function c164art:obs-motion/c40/10 3t replace
particle minecraft:wax_off 5.25 201.8 -6.0312 0.0 0.0 0.0 0.0 1 normal
