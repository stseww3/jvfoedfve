scoreboard objectives add c164m dummy
scoreboard players set #obs c164m 0
schedule function c164art:obs-motion/watch 28t replace
