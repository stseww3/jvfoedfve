schedule function c164art:obs-motion/c8/0 4t replace
execute positioned 10.198 218.0 1.4 as @a[distance=..1,tag=!c164.done] run function c164art:guide/lens
execute positioned 4.5 224.0 0.5 as @a[scores={c164f=1..}] run function c164art:guide/glow
