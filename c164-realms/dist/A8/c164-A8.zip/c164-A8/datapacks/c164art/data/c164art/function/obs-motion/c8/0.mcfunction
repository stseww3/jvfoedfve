execute unless score #run c164m matches 571309228 run return run function c164art:obs-motion/halt
schedule function c164art:obs-motion/c8/1 4t replace
scoreboard players set #obs c164m 1
execute positioned 69.5 194.0 23.7812 as @a[tag=!c164.c1,distance=..1.6] positioned 70.375 194.0 23.7812 if entity @s[distance=..1.6] run function c164art:guide/c1
execute positioned 12.5 207.0 -6.2188 as @a[tag=!c164.c2,distance=..1.6] positioned 12.5 207.0 -6.8875 if entity @s[distance=..1.6] run function c164art:guide/c2
execute positioned 8.0 207.0 17.6875 as @a[tag=!c164.c3,distance=..1.6] positioned 8.0 207.0 18.5625 if entity @s[distance=..1.6] run function c164art:guide/c3
execute positioned 3.7812 200.0 7.5938 as @a[tag=!c164.c4,distance=..1.6] positioned 3.7812 200.0 8.4375 if entity @s[distance=..1.6] run function c164art:guide/c4
execute positioned 5.25 200.0 -6.0312 as @a[tag=!c164.c5,distance=..1.6] positioned 5.25 200.0 -6.6 if entity @s[distance=..1.6] run function c164art:guide/c5
execute positioned -23.0 200.0 -2.4375 as @a[tag=!c164.c6,distance=..1.6] positioned -23.75 200.0 -2.4375 if entity @s[distance=..1.6] run function c164art:guide/c6
