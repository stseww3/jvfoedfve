schedule function c164art:obs-motion/c160/0 9t replace
particle minecraft:cloud 57.75 201.6238 33.5 0.0 1.0 0.1584 0.022 0 normal
