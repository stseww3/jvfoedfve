schedule function c164art:obs-motion/c160/10 6t replace
particle minecraft:cloud 79.75 198.2375 28.5 0.0875 1.0 0.1228 0.075 0 normal
particle minecraft:electric_spark 71.0625 196.5938 32.4375 0.01 0.03 0.02 0.2 2 normal
