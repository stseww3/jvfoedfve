execute unless score #run c164m matches 571309228 run return run function c164art:obs-motion/halt
schedule function c164art:obs-motion/c60/1 8t replace
data merge entity @e[type=minecraft:item_display,x=18.3125,y=201.2031,z=33.5781,distance=..0.05,tag=m.prop_pipe_gauge_needle,limit=1] {start_interpolation:0,interpolation_duration:10,transformation:{left_rotation:[0.22833f,-0.669227f,0.22833f,0.669227f],right_rotation:[0.0f,0.0f,0.0f,1.0f],scale:[1.0f,1.0f,1.0f],translation:[-0.028651f,0.0371f,-0.007812f]}}
