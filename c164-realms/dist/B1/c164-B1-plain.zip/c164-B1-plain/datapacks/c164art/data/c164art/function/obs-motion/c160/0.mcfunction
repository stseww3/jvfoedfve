execute unless score #run c164m matches 571309228 run return run function c164art:obs-motion/halt
schedule function c164art:obs-motion/c160/1 12t replace
playsound c164:hum block @a[x=72.0,y=195.0,z=37.75,distance=..16.0] 72.0 195.0 37.75 2.3 1.0
