schedule function c164art:obs-motion/c100/5 13t replace
data merge entity @e[type=minecraft:item_display,x=13.5,y=252.625,z=-29.5,distance=..0.05,tag=m.bld_tower_vane,limit=1] {start_interpolation:0,interpolation_duration:15,transformation:{left_rotation:[0.0f,-0.117172f,0.0f,0.993112f],right_rotation:[0.0f,0.0f,0.0f,1.0f],scale:[4.0f,4.0f,4.0f],translation:[0.218185f,-0.03125f,-0.911757f]}}
