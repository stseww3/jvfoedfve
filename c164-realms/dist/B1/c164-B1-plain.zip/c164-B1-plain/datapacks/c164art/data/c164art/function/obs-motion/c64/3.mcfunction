schedule function c164art:obs-motion/c64/0 16t replace
data merge entity @e[type=minecraft:item_display,x=89.0,y=197.625,z=-37.375,distance=..0.05,tag=m.mach_cable_drum,limit=1] {start_interpolation:0,interpolation_duration:18,transformation:{left_rotation:[-0.098017f,0.0f,0.0f,-0.995185f],right_rotation:[0.0f,0.0f,0.0f,1.0f],scale:[2.0f,2.0f,2.0f],translation:[0.0f,0.0f,0.0f]}}
