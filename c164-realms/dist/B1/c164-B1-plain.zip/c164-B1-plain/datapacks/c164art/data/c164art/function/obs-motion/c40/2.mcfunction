schedule function c164art:obs-motion/c40/3 2t replace
particle minecraft:wax_off 69.5 195.0812 23.7812 0.0 0.0 0.0 0.0 1 normal
