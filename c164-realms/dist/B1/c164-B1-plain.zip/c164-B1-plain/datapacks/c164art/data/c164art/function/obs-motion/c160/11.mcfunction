schedule function c164art:obs-motion/c160/12 13t replace
particle minecraft:cloud 79.75 198.2375 28.5 0.0 1.0 0.2309 0.06 0 normal
particle minecraft:electric_spark 72.0 194.75 38.2812 0.03 0.01 0.06 0.2 2 normal
