schedule function c164art:obs-motion/c40/5 1t replace
particle minecraft:wax_off 12.5 208.8 -6.2188 0.0 0.0 0.0 0.0 1 normal
