schedule function c164art:obs-motion/c160/11 2t replace
particle minecraft:cloud 57.75 201.6238 33.5 0.0 1.0 0.2493 0.03 0 normal
