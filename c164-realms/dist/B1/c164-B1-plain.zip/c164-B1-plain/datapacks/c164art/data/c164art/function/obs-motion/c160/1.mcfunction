schedule function c164art:obs-motion/c160/2 1t replace
particle minecraft:small_flame 78.7 195.4688 28.2 -0.6 1.0 -0.6 0.04 0 normal
