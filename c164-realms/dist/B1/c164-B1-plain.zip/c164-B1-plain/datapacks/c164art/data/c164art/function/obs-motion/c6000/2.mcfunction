schedule function c164art:obs-motion/c6000/3 100t replace
data merge entity @e[type=minecraft:item_display,x=13.5,y=247.5,z=-29.5,distance=..0.05,tag=m.mach_clock_ball,limit=1] {start_interpolation:0,interpolation_duration:100,transformation:{left_rotation:[0.0f,0.250841f,0.0f,0.968028f],right_rotation:[0.0f,0.0f,0.0f,1.0f],scale:[1.0f,1.0f,1.0f],translation:[0.0f,1.71875f,0.0f]}}
