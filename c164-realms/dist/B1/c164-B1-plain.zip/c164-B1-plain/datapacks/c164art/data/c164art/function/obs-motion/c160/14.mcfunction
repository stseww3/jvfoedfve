schedule function c164art:obs-motion/c160/15 21t replace
particle minecraft:cloud 19.4062 200.6238 33.5 0.0 1.0 0.3249 0.034 0 normal
