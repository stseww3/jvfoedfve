schedule function c164art:obs-motion/c160/5 18t replace
particle minecraft:cloud 85.4 196.3425 35.695 0.0524 1.0 0.1763 0.035 0 normal
particle minecraft:electric_spark 72.0 195.25 38.2812 0.03 0.01 0.06 0.2 2 normal
