scoreboard objectives add c164m dummy
function c164art:obs-motion/rest
scoreboard players set #run c164m 571309228
scoreboard players set #obs c164m 1
schedule function c164art:obs-motion/c16/0 3t replace
schedule function c164art:obs-motion/c24/0 2t replace
schedule function c164art:obs-motion/c40/0 2t replace
schedule function c164art:obs-motion/c48/0 1t replace
schedule function c164art:obs-motion/c90/0 4t replace
schedule function c164art:obs-motion/c130/0 20t replace
schedule function c164art:obs-motion/c170/0 5t replace
schedule function c164art:obs-motion/c1001/0 13t replace
schedule function c164art:obs-motion/c1617/0 9t replace
schedule function c164art:obs-motion/c2002/0 8t replace
schedule function c164art:obs-motion/c2457/0 3t replace
schedule function c164art:obs-motion/c3003/0 8t replace
schedule function c164art:obs-motion/c5577/0 4t replace
schedule function c164art:obs-motion/c9009/0 6t replace
