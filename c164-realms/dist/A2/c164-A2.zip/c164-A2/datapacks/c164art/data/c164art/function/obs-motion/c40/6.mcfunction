schedule function c164art:obs-motion/c40/7 5t replace
data merge entity @e[type=minecraft:item_display,x=6.4006,y=203.3125,z=0.5,distance=..0.05,tag=m.mach_clock_pendulum,limit=1] {start_interpolation:0,interpolation_duration:7,transformation:{left_rotation:[0.0f,0.0f,0.025739f,0.999669f],right_rotation:[0.0f,0.0f,0.0f,1.0f],scale:[1.0f,1.0f,1.0f],translation:[0.036183f,-0.702193f,0.0f]}}
