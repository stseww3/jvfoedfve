execute as @a[tag=!c164.in] run function c164map:first
execute as @a[scores={c164j=1..}] run function c164map:join
execute as @a at @s if entity @s[y=-512,dy=681] run function c164map:back
