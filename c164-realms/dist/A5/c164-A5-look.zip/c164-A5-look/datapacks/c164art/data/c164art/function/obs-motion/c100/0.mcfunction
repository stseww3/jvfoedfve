execute unless score #run c164m matches 571309228 run return run function c164art:obs-motion/halt
schedule function c164art:obs-motion/c100/0 100t replace
playsound c164:fire block @a[x=78.75,y=195.4688,z=28.5,distance=..12.0] 78.75 195.4688 28.5 1.0 1.0
