schedule function c164art:obs-motion/c160/0 64t replace
particle minecraft:cloud 79.75 198.2375 28.5 0.0 1.0 0.2309 0.06 0 normal
