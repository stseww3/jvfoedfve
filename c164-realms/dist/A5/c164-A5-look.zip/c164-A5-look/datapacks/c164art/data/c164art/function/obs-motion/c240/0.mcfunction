execute unless score #run c164m matches 571309228 run return run function c164art:obs-motion/halt
schedule function c164art:obs-motion/c240/0 240t replace
playsound c164:wind ambient @a[x=60.5,y=201.5,z=0.5,distance=..16.0] 60.5 201.5 0.5 1.0 1.0
playsound c164:wind ambient @a[x=45.5,y=196.5,z=52.5,distance=..16.0] 45.5 196.5 52.5 1.0 1.0
playsound c164:wind ambient @a[x=13.5,y=233.5,z=-29.5,distance=..6.0] 13.5 233.5 -29.5 1.0 1.0
