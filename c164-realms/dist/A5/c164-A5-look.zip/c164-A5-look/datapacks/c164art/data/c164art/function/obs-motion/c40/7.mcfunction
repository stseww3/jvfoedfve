schedule function c164art:obs-motion/c40/0 5t replace
data merge entity @e[type=minecraft:item_display,x=6.4006,y=203.3125,z=0.5,distance=..0.05,tag=m.mach_clock_pendulum,limit=1] {start_interpolation:0,interpolation_duration:7,transformation:{left_rotation:[0.0f,0.0f,-0.012341f,0.999924f],right_rotation:[0.0f,0.0f,0.0f,1.0f],scale:[1.0f,1.0f,1.0f],translation:[-0.017353f,-0.702911f,0.0f]}}
particle minecraft:campfire_signal_smoke 86.4 223.65 23.05 0.0 1.0 0.1495 0.0686 0 force
