schedule function c164art:obs-motion/c160/3 8t replace
particle minecraft:cloud 79.75 198.2375 28.5 0.0875 1.0 0.1228 0.075 0 normal
