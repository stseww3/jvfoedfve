execute unless score #run c164m matches 571309228 run return run function c164art:obs-motion/halt
schedule function c164art:obs-motion/c300/1 6t replace
playsound c164:telegraph block @a[x=6.5,y=208.5,z=-23.5,distance=..6.0] 6.5 208.5 -23.5 1.0 1.0
