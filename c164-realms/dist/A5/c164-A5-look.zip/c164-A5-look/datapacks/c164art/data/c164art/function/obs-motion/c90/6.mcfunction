schedule function c164art:obs-motion/c90/7 11t replace
data merge entity @e[type=minecraft:item_display,x=71.1094,y=197.375,z=27.0,distance=..0.05,tag=m.needle_north,limit=1] {start_interpolation:0,interpolation_duration:13,transformation:{left_rotation:[0.20721f,0.0f,0.0f,0.978297f],right_rotation:[0.0f,0.0f,0.0f,1.0f],scale:[1.0f,1.0f,1.0f],translation:[-0.023438f,0.114266f,0.050678f]}}
