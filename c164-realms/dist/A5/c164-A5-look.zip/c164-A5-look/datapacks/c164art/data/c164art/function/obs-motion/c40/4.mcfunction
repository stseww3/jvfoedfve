schedule function c164art:obs-motion/c40/5 5t replace
data merge entity @e[type=minecraft:item_display,x=6.4006,y=203.3125,z=0.5,distance=..0.05,tag=m.mach_clock_pendulum,limit=1] {start_interpolation:0,interpolation_duration:7,transformation:{left_rotation:[0.0f,0.0f,0.043181f,0.999067f],right_rotation:[0.0f,0.0f,0.0f,1.0f],scale:[1.0f,1.0f,1.0f],translation:[0.060667f,-0.700503f,0.0f]}}
particle minecraft:campfire_signal_smoke 87.55 223.5 22.6 0.0437 1.0 0.1853 0.0728 0 force
playsound c164:tock block @a[x=6.3906,y=203.3125,z=0.5,distance=..10.0] 6.3906 203.3125 0.5 1.0 1.0
playsound c164:tock block @a[x=2.5,y=209.5312,z=-24.74,distance=..8.0] 2.5 209.5312 -24.74 1.0 1.0
playsound c164:tock block @a[x=13.5,y=209.5312,z=-24.74,distance=..8.0] 13.5 209.5312 -24.74 1.0 1.0
playsound c164:tock block @a[x=4.5,y=220.0312,z=10.8338,distance=..8.0] 4.5 220.0312 10.8338 1.0 1.0
