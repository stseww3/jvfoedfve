scoreboard objectives add c164j minecraft.custom:minecraft.leave_game
difficulty peaceful
