execute if score #run c164m matches 571309228 unless score #obs c164m matches 1 run function c164art:obs-motion/start
