scoreboard objectives add c164m dummy
execute if score #run c164m matches 571309228 run scoreboard players set #run c164m 0
function c164art:obs-motion/rest
