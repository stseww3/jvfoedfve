execute unless score #run c164m matches 571309228 run return run function c164art:obs-motion/halt
schedule function c164art:obs-motion/c50/0 50t replace
particle minecraft:dripping_water 6.9375 201.0625 25.5 0.0 0.0 0.0 0.0 1 normal
