execute unless score #run c164m matches 571309228 run return run function c164art:obs-motion/halt
schedule function c164art:obs-motion/c16/1 4t replace
scoreboard players set #obs c164m 1
data merge entity @e[type=minecraft:item_display,x=72.0,y=195.0,z=37.75,distance=..0.05,tag=m.mach_engine_armature,limit=1] {start_interpolation:0,interpolation_duration:6,transformation:{left_rotation:[0.0f,0.0f,-0.92388f,0.382683f],right_rotation:[0.0f,0.0f,0.0f,1.0f],scale:[2.0f,2.0f,2.0f],translation:[0.0f,0.0f,0.203125f]}}
