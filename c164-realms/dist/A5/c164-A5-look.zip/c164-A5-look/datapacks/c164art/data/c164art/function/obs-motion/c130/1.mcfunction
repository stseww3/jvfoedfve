schedule function c164art:obs-motion/c130/2 17t replace
data merge entity @e[type=minecraft:item_display,x=71.1094,y=197.375,z=29.5,distance=..0.05,tag=m.needle_main,limit=1] {start_interpolation:0,interpolation_duration:19,transformation:{left_rotation:[0.275048f,0.0f,0.0f,0.961431f],right_rotation:[0.0f,0.0f,0.0f,1.0f],scale:[1.0f,1.0f,1.0f],translation:[-0.023437f,0.106087f,0.06611f]}}
