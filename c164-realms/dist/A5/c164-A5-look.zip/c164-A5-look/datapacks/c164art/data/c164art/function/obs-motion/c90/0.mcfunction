execute unless score #run c164m matches 571309228 run return run function c164art:obs-motion/halt
schedule function c164art:obs-motion/c90/1 11t replace
data merge entity @e[type=minecraft:item_display,x=71.1094,y=197.375,z=27.0,distance=..0.05,tag=m.needle_north,limit=1] {start_interpolation:0,interpolation_duration:13,transformation:{left_rotation:[0.169669f,0.0f,0.0f,0.985501f],right_rotation:[0.0f,0.0f,0.0f,1.0f],scale:[1.0f,1.0f,1.0f],translation:[-0.023437f,0.117803f,0.041802f]}}
