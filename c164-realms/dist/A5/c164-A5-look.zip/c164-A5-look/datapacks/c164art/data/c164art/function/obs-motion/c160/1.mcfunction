schedule function c164art:obs-motion/c160/2 8t replace
particle minecraft:cloud 79.75 198.2375 28.5 -0.0699 1.0 0.1763 0.09 0 normal
playsound c164:hiss block @a[x=79.75,y=198.1875,z=28.5,distance=..12.0] 79.75 198.1875 28.5 1.0 1.0
