scoreboard objectives add c164m dummy
function c164art:obs-motion/rest
scoreboard players set #run c164m 571309228
scoreboard players set #obs c164m 1
schedule function c164art:obs-motion/c16/0 4t replace
schedule function c164art:obs-motion/c24/0 2t replace
schedule function c164art:obs-motion/c32/0 6t replace
schedule function c164art:obs-motion/c40/0 3t replace
schedule function c164art:obs-motion/c48/0 1t replace
schedule function c164art:obs-motion/c50/0 7t replace
schedule function c164art:obs-motion/c80/0 2t replace
schedule function c164art:obs-motion/c90/0 1t replace
schedule function c164art:obs-motion/c100/0 11t replace
schedule function c164art:obs-motion/c110/0 4t replace
schedule function c164art:obs-motion/c130/0 4t replace
schedule function c164art:obs-motion/c150/0 10t replace
schedule function c164art:obs-motion/c160/0 16t replace
schedule function c164art:obs-motion/c170/0 6t replace
schedule function c164art:obs-motion/c240/0 11t replace
schedule function c164art:obs-motion/c260/0 12t replace
schedule function c164art:obs-motion/c300/0 2t replace
schedule function c164art:obs-motion/c1001/0 3t replace
schedule function c164art:obs-motion/c1200/0 15t replace
schedule function c164art:obs-motion/c1617/0 5t replace
schedule function c164art:obs-motion/c2002/0 19t replace
schedule function c164art:obs-motion/c2400/0 15t replace
schedule function c164art:obs-motion/c2457/0 7t replace
schedule function c164art:obs-motion/c3003/0 5t replace
schedule function c164art:obs-motion/c5577/0 15t replace
schedule function c164art:obs-motion/c9009/0 19t replace
