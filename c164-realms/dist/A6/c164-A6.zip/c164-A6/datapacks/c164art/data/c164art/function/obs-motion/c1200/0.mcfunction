execute unless score #run c164m matches 571309228 run return run function c164art:obs-motion/halt
schedule function c164art:obs-motion/c1200/1 200t replace
data merge entity @e[type=minecraft:item_display,x=13.5,y=226.3125,z=-29.125,distance=..0.05,tag=m.int_clockroom_escape,limit=1] {start_interpolation:0,interpolation_duration:202,transformation:{left_rotation:[0.0f,0.0f,-0.504528f,0.863396f],right_rotation:[0.0f,0.0f,0.0f,1.0f],scale:[1.0f,1.0f,1.0f],translation:[-0.001383f,0.002454f,0.0f]}}
