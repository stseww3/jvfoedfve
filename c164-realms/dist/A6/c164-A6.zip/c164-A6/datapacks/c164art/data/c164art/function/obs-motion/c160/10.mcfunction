schedule function c164art:obs-motion/c160/11 29t replace
particle minecraft:small_flame 78.7 195.4688 28.2 -1.0 1.0 -0.1 0.035 0 normal
particle minecraft:electric_spark 72.0 194.75 38.2812 0.03 0.01 0.06 0.2 2 normal
particle minecraft:electric_spark 71.0625 196.5938 32.4375 0.01 0.03 0.02 0.2 2 normal
