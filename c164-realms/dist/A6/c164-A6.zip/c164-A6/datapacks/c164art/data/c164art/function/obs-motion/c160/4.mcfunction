schedule function c164art:obs-motion/c160/5 24t replace
particle minecraft:small_flame 78.7 195.4688 28.2 -0.5 1.0 -0.8 0.045 0 normal
