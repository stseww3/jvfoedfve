execute unless score #run c164m matches 571309228 run return run function c164art:obs-motion/halt
schedule function c164art:obs-motion/c32/1 8t replace
data merge entity @e[type=minecraft:item_display,x=11.625,y=219.3438,z=32.8125,distance=..0.05,tag=m.int_astroroom_governor,limit=1] {start_interpolation:0,interpolation_duration:10,transformation:{left_rotation:[0.0f,0.83147f,0.0f,0.55557f],right_rotation:[0.0f,0.0f,0.0f,1.0f],scale:[1.0f,1.0f,1.0f],translation:[0.0f,0.203125f,0.0f]}}
