tag @s remove c164.say3
tellraw @s [{text:"[c164 试传 T2] ",color:"gold"},{text:"这个存档不带自定义生物群系和时间线，天是游戏自己的。"}]
execute if entity @s[tag=c164.adv] run tellraw @s [{text:"[c164 试传 T2] ",color:"gold"},{text:"进来时已经是冒险模式；难度 "},{score:{name:"#diff",objective:"c164v"}},{text:"（0 是和平）。"}]
execute unless entity @s[tag=c164.adv] run tellraw @s [{text:"[c164 试传 T2] ",color:"gold"},{text:"进来时不是冒险模式（函数已改成冒险）；难度 "},{score:{name:"#diff",objective:"c164v"}},{text:"（0 是和平）。"}]
tellraw @s [{text:"[c164 试传 T2] ",color:"gold"},{text:"请先别动鼠标，按 F2 截一张图；再低头看平台、回头看身后。",color:"yellow"}]
