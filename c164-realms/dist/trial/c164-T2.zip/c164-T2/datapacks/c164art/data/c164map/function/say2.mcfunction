tag @s remove c164.say2
tag @s add c164.say3
execute store result score #diff c164v run difficulty
data merge entity @e[type=minecraft:text_display,tag=c164.l2,limit=1] {text:{text:"数据包的函数：在跑",color:"green"}}
execute if entity @s[tag=c164.adv] run data merge entity @e[type=minecraft:text_display,tag=c164.l4,limit=1] {text:{text:"进来时：冒险模式",color:"green"}}
execute unless entity @s[tag=c164.adv] run data merge entity @e[type=minecraft:text_display,tag=c164.l4,limit=1] {text:{text:"进来时：不是冒险模式",color:"yellow"}}
execute if score #diff c164v matches 0 run data merge entity @e[type=minecraft:text_display,tag=c164.l5,limit=1] {text:{text:"难度：和平",color:"green"}}
execute if score #diff c164v matches 1 run data merge entity @e[type=minecraft:text_display,tag=c164.l5,limit=1] {text:{text:"难度：简单（不是和平）",color:"yellow"}}
execute if score #diff c164v matches 2 run data merge entity @e[type=minecraft:text_display,tag=c164.l5,limit=1] {text:{text:"难度：普通（不是和平）",color:"yellow"}}
execute if score #diff c164v matches 3 run data merge entity @e[type=minecraft:text_display,tag=c164.l5,limit=1] {text:{text:"难度：困难（不是和平）",color:"yellow"}}
