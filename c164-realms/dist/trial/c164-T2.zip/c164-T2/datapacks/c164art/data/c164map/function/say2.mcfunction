tag @s remove c164.say2
tag @s add c164.say3
execute store result score #diff c164v run difficulty
