execute if score #run c164m matches 304677571 unless score #obs_export_probe c164m matches 1 run function c164art:obs_export_probe-motion/start
