scoreboard objectives add c164m dummy
function c164art:obs_export_probe-motion/rest
scoreboard players set #run c164m 304677571
scoreboard players set #obs_export_probe c164m 1
schedule function c164art:obs_export_probe-motion/c24/0 1t replace
