schedule function c164art:obs_export_probe-motion/c24/5 4t replace
data merge entity @e[type=minecraft:item_display,x=-4.125,y=204.1562,z=0.5,distance=..0.05,tag=m.site_weather_cups,limit=1] {start_interpolation:0,interpolation_duration:4,transformation:{left_rotation:[0.0f,0.5f,0.0f,-0.866025f],right_rotation:[0.0f,0.0f,0.0f,1.0f],scale:[1.0f,1.0f,1.0f],translation:[-0.067658f,0.0f,0.039063f]}}
