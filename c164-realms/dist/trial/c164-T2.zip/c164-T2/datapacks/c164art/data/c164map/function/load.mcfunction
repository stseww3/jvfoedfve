scoreboard objectives add c164j minecraft.custom:minecraft.leave_game
scoreboard objectives add c164v dummy
