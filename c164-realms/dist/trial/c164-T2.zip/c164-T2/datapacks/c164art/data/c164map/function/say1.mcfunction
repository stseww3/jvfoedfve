tag @s remove c164.say1
tag @s add c164.say2
scoreboard players set @s c164v 0
tellraw @s [{text:"[c164 试传 T2] ",color:"gold"},{text:"数据包的函数在跑：这几行字是函数说的。"}]
