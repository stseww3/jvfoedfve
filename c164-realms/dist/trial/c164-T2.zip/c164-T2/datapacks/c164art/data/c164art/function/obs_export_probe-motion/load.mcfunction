scoreboard objectives add c164m dummy
scoreboard players set #obs_export_probe c164m 0
schedule function c164art:obs_export_probe-motion/watch 44t replace
