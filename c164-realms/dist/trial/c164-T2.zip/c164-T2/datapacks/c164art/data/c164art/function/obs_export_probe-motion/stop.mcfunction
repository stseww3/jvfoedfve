scoreboard objectives add c164m dummy
execute if score #run c164m matches 304677571 run scoreboard players set #run c164m 0
function c164art:obs_export_probe-motion/rest
