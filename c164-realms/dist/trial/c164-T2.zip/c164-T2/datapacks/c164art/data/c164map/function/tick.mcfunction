execute as @a[tag=!c164.in] run function c164map:first
execute as @a[scores={c164j=1..}] run function c164map:join
execute as @a at @s if entity @s[y=-512,dy=681] run function c164map:back
execute as @a[tag=c164.say3] at @s run function c164map:say3
execute as @a[tag=c164.say2] run scoreboard players add @s c164v 1
execute as @a[tag=c164.say2,scores={c164v=40..}] at @s run function c164map:say2
execute as @a[tag=c164.say1] at @s run function c164map:say1
