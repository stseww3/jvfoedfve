scoreboard players set @s c164j 0
tag @s remove c164.adv
execute if entity @s[gamemode=adventure] run tag @s add c164.adv
gamemode adventure @s
attribute @s minecraft:block_interaction_range base set 0
function c164map:back
tag @s remove c164.say2
tag @s remove c164.say3
tag @s remove c164.bar
tag @s add c164.say1
