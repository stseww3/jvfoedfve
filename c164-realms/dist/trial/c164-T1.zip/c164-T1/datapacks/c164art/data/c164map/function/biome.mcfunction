execute if biome ~ ~ ~ c164art:obs_blue run scoreboard players set #biome c164v 1
execute if score #biome c164v matches 1 run data merge entity @e[type=minecraft:text_display,tag=c164.l3,limit=1] {text:{text:"生物群系 obs_blue：在",color:"green"}}
