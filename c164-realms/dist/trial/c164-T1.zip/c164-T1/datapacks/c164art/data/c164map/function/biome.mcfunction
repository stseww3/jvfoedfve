execute if biome ~ ~ ~ c164art:obs_blue run scoreboard players set #biome c164v 1
