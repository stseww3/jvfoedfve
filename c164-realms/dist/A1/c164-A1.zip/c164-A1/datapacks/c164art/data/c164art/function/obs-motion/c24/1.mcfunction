schedule function c164art:obs-motion/c24/2 2t replace
data merge entity @e[type=minecraft:item_display,x=5.875,y=205.1562,z=-46.5,distance=..0.05,tag=m.site_weather_cups,limit=1] {start_interpolation:0,interpolation_duration:4,transformation:{left_rotation:[0.0f,0.866025f,0.0f,0.5f],right_rotation:[0.0f,0.0f,0.0f,1.0f],scale:[1.0f,1.0f,1.0f],translation:[0.067658f,0.0f,-0.039062f]}}
