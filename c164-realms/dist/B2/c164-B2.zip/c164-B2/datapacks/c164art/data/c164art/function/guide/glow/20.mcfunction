particle minecraft:end_rod ~-5.7667 ~11.651 ~-0.8 0.0896 0.0444 0 1 0 force @s
particle minecraft:end_rod ~-5.3566 ~11.8451 ~1.6 0.0911 0.0412 0 1 0 force @s
particle minecraft:end_rod ~-4.8348 ~12.0675 ~0.3 0.0928 0.0372 0 1 0 force @s
