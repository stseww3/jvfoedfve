schedule function c164art:obs-motion/c150/0 19t replace
data merge entity @e[type=minecraft:item_display,x=6.0,y=203.375,z=-24.1406,distance=..0.05,tag=m.bboard_needle_west,limit=1] {start_interpolation:0,interpolation_duration:21,transformation:{left_rotation:[0.240967f,0.0f,0.0f,0.970533f],right_rotation:[0.0f,0.0f,0.0f,1.0f],scale:[1.0f,1.0f,1.0f],translation:[-0.023438f,0.110484f,0.058467f]}}
