particle minecraft:end_rod ~-7.1436 ~10.8613 ~1.5 0.0835 0.055 0 1 0 force @s
particle minecraft:end_rod ~-6.6631 ~11.1626 ~-0.2 0.0859 0.0513 0 1 0 force @s
particle minecraft:end_rod ~-7.4255 ~10.6706 ~-1.6 0.0821 0.0571 0 1 0 force @s
