execute unless score #run c164m matches 571309228 run return run function c164art:obs-motion/halt
schedule function c164art:obs-motion/c100/1 13t replace
data merge entity @e[type=minecraft:item_display,x=13.5,y=252.625,z=-29.5,distance=..0.05,tag=m.bld_tower_vane,limit=1] {start_interpolation:0,interpolation_duration:15,transformation:{left_rotation:[0.0f,0.117172f,0.0f,0.993112f],right_rotation:[0.0f,0.0f,0.0f,1.0f],scale:[4.0f,4.0f,4.0f],translation:[-0.218185f,-0.03125f,-0.911757f]}}
data merge entity @e[type=minecraft:item_display,x=-5.47,y=225.9944,z=0.5,distance=..0.05,tag=m.mach_dome_pull,limit=1] {start_interpolation:0,interpolation_duration:15,transformation:{left_rotation:[0.0f,0.0f,-0.008808f,0.999961f],right_rotation:[0.0f,0.0f,0.0f,1.0f],scale:[3.0f,3.0f,3.0f],translation:[-0.054999f,-3.121702f,0.0f]}}
playsound c164:fire block @a[x=78.75,y=195.4688,z=28.5,distance=..12.0] 78.75 195.4688 28.5 1.0 1.0
