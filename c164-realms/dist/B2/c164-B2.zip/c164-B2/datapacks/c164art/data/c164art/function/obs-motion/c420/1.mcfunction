schedule function c164art:obs-motion/c420/0 70t replace
data merge entity @e[type=minecraft:item_display,x=11.375,y=202.6875,z=-3.99,distance=..0.05,tag=m.int_starhall_flag_4,limit=1] {item:{components:{"minecraft:item_model":"c164:int_starhall_flag_down"}}}
