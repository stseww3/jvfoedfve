particle minecraft:end_rod ~-6.0027 ~11.5311 ~-1.4 0.0887 0.0462 0 1 0 force @s
particle minecraft:end_rod ~-6.598 ~11.2012 ~1.1 0.0862 0.0508 0 1 0 force @s
particle minecraft:end_rod ~-5.6988 ~11.6843 ~-0.3 0.0899 0.0438 0 1 0 force @s
