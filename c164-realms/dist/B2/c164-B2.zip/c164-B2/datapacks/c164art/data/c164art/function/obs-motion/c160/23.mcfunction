schedule function c164art:obs-motion/c160/24 1t replace
particle minecraft:cloud 19.4062 200.6238 33.5 0.0 1.0 0.1584 0.022 0 normal
particle minecraft:small_flame 78.7 195.4688 28.2 -1.3 1.0 -0.7 0.03 0 normal
