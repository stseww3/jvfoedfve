tag @s add c164.c4
function c164art:guide/count
playsound minecraft:block.note_block.chime master @s ~ ~ ~ 0.6 1.2
title @s actionbar [{text:"Star chart "},{score:{name:"@s",objective:"c164g"}},{text:" of 6"}]
