schedule function c164art:obs-motion/c160/54 4t replace
particle minecraft:trail{target:[80.9045d,198.3766d,-17.8064d],color:9405544,duration:8} 81.4074 198.5808 -17.8098 0 0 0 0 1 normal
particle minecraft:trail{target:[80.3314d,198.6138d,-8.7783d],color:9405544,duration:8} 79.8552 198.4208 -9.1404 0 0 0 0 1 normal
particle minecraft:trail{target:[73.7568d,201.4933d,-8.6357d],color:9405544,duration:8} 73.8252 201.3648 -9.4472 0 0 0 0 1 normal
