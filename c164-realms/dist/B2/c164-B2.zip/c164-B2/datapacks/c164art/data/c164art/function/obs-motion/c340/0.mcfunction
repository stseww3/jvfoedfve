execute unless score #run c164m matches 571309228 run return run function c164art:obs-motion/halt
schedule function c164art:obs-motion/c340/1 270t replace
data merge entity @e[type=minecraft:item_display,x=11.625,y=202.9062,z=-3.99,distance=..0.05,tag=m.int_starhall_flag_3,limit=1] {item:{components:{"minecraft:item_model":"c164:int_starhall_flag_up"}}}
