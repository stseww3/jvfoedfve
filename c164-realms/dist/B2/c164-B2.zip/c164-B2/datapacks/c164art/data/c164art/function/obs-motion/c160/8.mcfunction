schedule function c164art:obs-motion/c160/9 4t replace
particle minecraft:trail{target:[79.7972d,198.254d,-10.2405d],color:9405544,duration:8} 79.0154 198.3722 -10.1097 0 0 0 0 1 normal
particle minecraft:trail{target:[72.5968d,201.545d,-9.2571d],color:9405544,duration:8} 72.2339 201.6499 -9.5223 0 0 0 0 1 normal
particle minecraft:trail{target:[72.3593d,201.4734d,9.5115d],color:9405544,duration:8} 72.5883 201.4134 9.7058 0 0 0 0 1 normal
