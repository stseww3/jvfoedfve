schedule function c164art:obs-motion/c160/50 4t replace
particle minecraft:trail{target:[81.099d,198.0449d,-17.5368d],color:9405544,duration:8} 80.8557 198.1745 -16.7689 0 0 0 0 1 normal
particle minecraft:trail{target:[80.4374d,198.2922d,-8.9677d],color:9405544,duration:8} 79.3228 198.2537 -8.5511 0 0 0 0 1 normal
