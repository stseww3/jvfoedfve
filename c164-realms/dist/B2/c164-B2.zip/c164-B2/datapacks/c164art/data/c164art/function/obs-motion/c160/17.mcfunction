schedule function c164art:obs-motion/c160/18 2t replace
particle minecraft:cloud 74.77 196.1 20.88 -0.04 1.0 -0.22 0.066 0 normal
particle minecraft:trail{target:[81.2149d,198.1177d,-18.3121d],color:9405544,duration:8} 80.7917 198.3231 -17.9121 0 0 0 0 1 normal
particle minecraft:trail{target:[73.5266d,201.0265d,10.1698d],color:9405544,duration:8} 73.4438 201.1459 10.0899 0 0 0 0 1 normal
