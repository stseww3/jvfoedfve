execute unless score #run c164m matches 571309228 run return run function c164art:obs-motion/halt
schedule function c164art:obs-motion/c240/1 10t replace
data merge entity @e[type=minecraft:item_display,x=8.0,y=208.0437,z=13.5781,distance=..0.05,tag=m.int_chart_bridge_screw,limit=1] {start_interpolation:0,interpolation_duration:12,transformation:{left_rotation:[0.128104f,0.0f,0.0f,-0.991761f],right_rotation:[0.0f,0.0f,0.0f,1.0f],scale:[1.0f,1.0f,1.0f],translation:[0.182813f,0.025755f,-0.006766f]}}
data merge entity @e[type=minecraft:item_display,x=8.0,y=208.0625,z=13.625,distance=..0.05,tag=m.int_chart_bridge_carriage,limit=1] {start_interpolation:0,interpolation_duration:10,transformation:{left_rotation:[0.0f,0.0f,0.0f,1.0f],right_rotation:[0.0f,0.0f,0.0f,1.0f],scale:[1.0f,1.0f,1.0f],translation:[0.786823f,0.278569f,0.0625f]}}
playsound c164:wind ambient @a[x=60.5,y=201.5,z=0.5,distance=..16.0] 60.5 201.5 0.5 1.0 1.0
playsound c164:wind ambient @a[x=45.5,y=196.5,z=52.5,distance=..16.0] 45.5 196.5 52.5 1.0 1.0
playsound c164:wind ambient @a[x=13.5,y=233.5,z=-29.5,distance=..6.0] 13.5 233.5 -29.5 1.0 1.0
