schedule function c164art:obs-motion/c160/4 1t replace
particle minecraft:trail{target:[79.6582d,198.8669d,-10.386d],color:9405544,duration:8} 80.1342 197.9894 -9.9396 0 0 0 0 1 normal
particle minecraft:trail{target:[72.2013d,201.2446d,9.8749d],color:9405544,duration:8} 72.503 201.3075 9.9228 0 0 0 0 1 normal
particle minecraft:small_flame 78.7 195.4688 28.2 -0.6 1.0 -0.6 0.04 0 normal
