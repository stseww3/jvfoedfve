schedule function c164art:obs-motion/c340/0 70t replace
data merge entity @e[type=minecraft:item_display,x=11.625,y=202.9062,z=-3.99,distance=..0.05,tag=m.int_starhall_flag_3,limit=1] {item:{components:{"minecraft:item_model":"c164:int_starhall_flag_down"}}}
