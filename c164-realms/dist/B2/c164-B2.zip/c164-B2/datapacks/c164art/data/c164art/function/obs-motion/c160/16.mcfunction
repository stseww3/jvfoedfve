schedule function c164art:obs-motion/c160/17 4t replace
particle minecraft:trail{target:[73.7648d,201.7715d,-9.3115d],color:9405544,duration:8} 73.0004 200.8411 -9.9296 0 0 0 0 1 normal
particle minecraft:trail{target:[73.3043d,201.2816d,9.2647d],color:9405544,duration:8} 74.0543 201.1641 9.7709 0 0 0 0 1 normal
