particle minecraft:end_rod ~-5.0098 ~11.9959 ~1.5 0.0923 0.0385 0 1 0 force @s
particle minecraft:end_rod ~-4.4818 ~12.203 ~-0.2 0.0939 0.0345 0 1 0 force @s
particle minecraft:end_rod ~-5.3221 ~11.8607 ~-1.6 0.0912 0.0409 0 1 0 force @s
