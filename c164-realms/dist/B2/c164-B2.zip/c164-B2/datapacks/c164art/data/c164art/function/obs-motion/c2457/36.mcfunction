schedule function c164art:obs-motion/c2457/37 7t replace
data merge entity @e[type=minecraft:item_display,x=11.5,y=207.5,z=0.5,distance=..0.05,tag=m.mach_orrery_a_arm_mars,limit=1] {start_interpolation:0,interpolation_duration:191,transformation:{left_rotation:[0.0f,-0.002557f,0.0f,-0.999997f],right_rotation:[0.0f,0.0f,0.0f,1.0f],scale:[2.0f,2.0f,2.0f],translation:[-0.466665f,1.429375f,0.0045f]}}
