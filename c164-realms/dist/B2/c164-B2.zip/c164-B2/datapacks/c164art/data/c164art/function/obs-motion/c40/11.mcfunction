schedule function c164art:obs-motion/c40/12 3t replace
particle minecraft:end_rod 5.25 201.8 -6.0312 0.0 0.0 0.0 0.0 1 normal
