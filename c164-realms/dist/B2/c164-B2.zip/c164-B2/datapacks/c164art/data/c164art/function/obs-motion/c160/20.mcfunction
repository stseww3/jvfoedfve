schedule function c164art:obs-motion/c160/21 4t replace
particle minecraft:trail{target:[80.232d,198.6189d,-18.3064d],color:9405544,duration:8} 81.2149 198.1177 -18.3121 0 0 0 0 1 normal
particle minecraft:trail{target:[73.8122d,200.9468d,9.4779d],color:9405544,duration:8} 73.5266 201.0265 10.1698 0 0 0 0 1 normal
