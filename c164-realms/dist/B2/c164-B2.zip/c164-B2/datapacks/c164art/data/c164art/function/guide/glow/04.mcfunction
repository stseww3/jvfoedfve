particle minecraft:end_rod ~-12.1365 ~4.6588 ~-0.8 0.0358 0.0934 0 1 0 force @s
particle minecraft:end_rod ~-11.9666 ~5.0795 ~1.6 0.0391 0.0921 0 1 0 force @s
particle minecraft:end_rod ~-11.7336 ~5.5966 ~0.3 0.0431 0.0903 0 1 0 force @s
