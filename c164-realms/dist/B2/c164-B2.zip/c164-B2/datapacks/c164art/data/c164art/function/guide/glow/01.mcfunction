particle minecraft:end_rod ~-12.6138 ~3.145 ~1.5 0.0242 0.097 0 1 0 force @s
particle minecraft:end_rod ~-12.4647 ~3.6922 ~-0.2 0.0284 0.0959 0 1 0 force @s
particle minecraft:end_rod ~-12.6138 ~3.145 ~-1.6 0.0242 0.097 0 1 0 force @s
