# as whoever is new, once (the map's function tag first): the title, in two seconds
tag @s add c164.new
schedule function c164art:guide/title 40t
