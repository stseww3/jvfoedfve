schedule function c164art:obs-motion/c160/16 1t replace
particle minecraft:small_flame 78.7 195.4688 28.2 -0.5 1.0 -0.8 0.045 0 normal
particle minecraft:electric_spark 72.0 194.75 38.2812 0.03 0.01 0.06 0.2 2 normal
