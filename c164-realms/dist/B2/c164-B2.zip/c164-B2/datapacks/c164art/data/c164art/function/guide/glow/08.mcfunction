particle minecraft:end_rod ~-11.0645 ~6.8247 ~-0.8 0.0525 0.0851 0 1 0 force @s
particle minecraft:end_rod ~-10.8196 ~7.2067 ~1.6 0.0554 0.0832 0 1 0 force @s
particle minecraft:end_rod ~-10.4949 ~7.6718 ~0.3 0.059 0.0807 0 1 0 force @s
