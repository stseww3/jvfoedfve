schedule function c164art:obs-motion/c40/14 2t replace
particle minecraft:end_rod -23.0 200.7688 -2.4375 0.0 0.0 0.0 0.0 1 normal
