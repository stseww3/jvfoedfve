tag @s add c164.done
scoreboard objectives add c164f dummy
scoreboard players set @s c164f 25
title @s times 20 80 30
title @s title {text:"THE COMET, IN FOCUS"}
playsound minecraft:block.bell.use master @s ~ ~ ~ 1 0.8
