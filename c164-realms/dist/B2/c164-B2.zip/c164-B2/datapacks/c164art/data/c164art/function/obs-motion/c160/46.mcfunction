schedule function c164art:obs-motion/c160/47 4t replace
particle minecraft:cloud 74.24 196.1 20.88 -0.02 1.0 -0.2 0.064 0 normal
particle minecraft:trail{target:[80.8557d,198.1745d,-16.7689d],color:9405544,duration:8} 80.0799 198.1278 -17.0228 0 0 0 0 1 normal
particle minecraft:trail{target:[79.3228d,198.2537d,-8.5511d],color:9405544,duration:8} 79.3446 198.3198 -9.02 0 0 0 0 1 normal
