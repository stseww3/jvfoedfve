schedule function c164art:obs-motion/c160/25 4t replace
particle minecraft:trail{target:[81.3465d,198.4467d,-17.2986d],color:9405544,duration:8} 81.213 198.3813 -17.9064 0 0 0 0 1 normal
particle minecraft:trail{target:[73.3469d,201.3832d,-9.3703d],color:9405544,duration:8} 73.8555 201.4455 -9.3514 0 0 0 0 1 normal
particle minecraft:trail{target:[73.6937d,201.4937d,9.9393d],color:9405544,duration:8} 73.5009 201.4377 9.9476 0 0 0 0 1 normal
