particle minecraft:end_rod ~-9.6101 ~8.7548 ~-0.8 0.0673 0.0739 0 1 0 force @s
particle minecraft:end_rod ~-9.2987 ~9.0848 ~1.6 0.0699 0.0715 0 1 0 force @s
particle minecraft:end_rod ~-8.8936 ~9.4818 ~0.3 0.0729 0.0684 0 1 0 force @s
