particle minecraft:end_rod ~-8.3272 ~9.9828 ~0.7 0.0768 0.0641 0 1 0 force @s
particle minecraft:end_rod ~-8.9211 ~9.4559 ~-1 0.0727 0.0686 0 1 0 force @s
particle minecraft:end_rod ~-8.0631 ~10.1974 ~1.7 0.0784 0.062 0 1 0 force @s
