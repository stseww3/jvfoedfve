schedule function c164art:obs-motion/c300/4 4t replace
data merge entity @e[type=minecraft:item_display,x=6.8906,y=208.5969,z=-23.4688,distance=..0.05,tag=m.mach_rec_telegraph_sounder,limit=1] {start_interpolation:0,interpolation_duration:2,transformation:{left_rotation:[0.0f,0.0f,0.0f,1.0f],right_rotation:[0.0f,0.0f,0.0f,1.0f],scale:[1.0f,1.0f,1.0f],translation:[0.29375f,-0.039062f,0.1125f]}}
playsound c164:telegraph_up block @a[x=6.5,y=208.5,z=-23.5,distance=..6.0] 6.5 208.5 -23.5 1.0 1.0
