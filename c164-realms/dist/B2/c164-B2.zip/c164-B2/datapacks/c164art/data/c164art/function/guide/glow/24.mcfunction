particle minecraft:end_rod ~-3.5105 ~12.517 ~-0.8 0.0963 0.027 0 1 0 force @s
particle minecraft:end_rod ~-3.0715 ~12.6319 ~1.6 0.0972 0.0236 0 1 0 force @s
particle minecraft:end_rod ~-2.7029 ~12.7159 ~0.3 0.0978 0.0208 0 1 0 force @s
