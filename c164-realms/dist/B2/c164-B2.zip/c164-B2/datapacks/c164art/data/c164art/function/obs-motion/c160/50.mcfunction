schedule function c164art:obs-motion/c160/51 4t replace
particle minecraft:trail{target:[81.4074d,198.5808d,-17.8098d],color:9405544,duration:8} 80.4765 198.1168 -18.4831 0 0 0 0 1 normal
particle minecraft:trail{target:[79.8552d,198.4208d,-9.1404d],color:9405544,duration:8} 79.9384 198.5357 -8.9332 0 0 0 0 1 normal
particle minecraft:trail{target:[73.8252d,201.3648d,-9.4472d],color:9405544,duration:8} 73.424 201.3677 -9.2788 0 0 0 0 1 normal
