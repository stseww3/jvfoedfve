schedule function c164art:obs-motion/c160/11 4t replace
particle minecraft:trail{target:[79.6424d,198.5745d,-9.9444d],color:9405544,duration:8} 79.7972 198.254 -10.2405 0 0 0 0 1 normal
particle minecraft:trail{target:[72.439d,201.6855d,-9.4776d],color:9405544,duration:8} 72.5968 201.545 -9.2571 0 0 0 0 1 normal
particle minecraft:trail{target:[73.1119d,201.7101d,9.3475d],color:9405544,duration:8} 72.3593 201.4734 9.5115 0 0 0 0 1 normal
