schedule function c164art:obs-motion/c160/26 4t replace
particle minecraft:trail{target:[80.3225d,198.9257d,-18.4262d],color:9405544,duration:8} 81.0305 198.5823 -18.2527 0 0 0 0 1 normal
particle minecraft:trail{target:[73.3738d,201.0488d,10.1067d],color:9405544,duration:8} 73.571 200.8564 10.2504 0 0 0 0 1 normal
