particle minecraft:end_rod ~-9.7864 ~8.5573 ~-1.4 0.0658 0.0753 0 1 0 force @s
particle minecraft:end_rod ~-10.2208 ~8.0334 ~1.1 0.0618 0.0786 0 1 0 force @s
particle minecraft:end_rod ~-9.559 ~8.8105 ~-0.3 0.0678 0.0735 0 1 0 force @s
