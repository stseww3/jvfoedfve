schedule function c164art:obs-motion/c160/23 3t replace
particle minecraft:cloud 74.2 196.1 20.88 0.1 1.0 -0.2 0.048 0 normal
particle minecraft:trail{target:[81.0305d,198.5823d,-18.2527d],color:9405544,duration:8} 80.232 198.6189 -18.3064 0 0 0 0 1 normal
particle minecraft:trail{target:[73.571d,200.8564d,10.2504d],color:9405544,duration:8} 73.8122 200.9468 9.4779 0 0 0 0 1 normal
