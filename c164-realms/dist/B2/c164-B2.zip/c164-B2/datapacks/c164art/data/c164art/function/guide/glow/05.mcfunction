particle minecraft:end_rod ~-11.8138 ~5.4254 ~1.5 0.0417 0.0909 0 1 0 force @s
particle minecraft:end_rod ~-11.5659 ~5.9355 ~-0.2 0.0457 0.089 0 1 0 force @s
particle minecraft:end_rod ~-11.9517 ~5.1143 ~-1.6 0.0393 0.0919 0 1 0 force @s
