execute unless score #run c164m matches 571309228 run return run function c164art:obs-motion/halt
schedule function c164art:obs-motion/c110/1 14t replace
data merge entity @e[type=minecraft:item_display,x=10.0,y=203.375,z=-24.1406,distance=..0.05,tag=m.bboard_needle_east,limit=1] {start_interpolation:0,interpolation_duration:16,transformation:{left_rotation:[-0.170546f,0.0f,0.0f,0.98535f],right_rotation:[0.0f,0.0f,0.0f,1.0f],scale:[1.0f,1.0f,1.0f],translation:[-0.023438f,0.117728f,-0.042012f]}}
