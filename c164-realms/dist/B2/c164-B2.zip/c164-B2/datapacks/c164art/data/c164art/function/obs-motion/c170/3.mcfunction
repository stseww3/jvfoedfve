schedule function c164art:obs-motion/c170/4 21t replace
data merge entity @e[type=minecraft:item_display,x=71.1094,y=197.375,z=32.0,distance=..0.05,tag=m.needle_south,limit=1] {start_interpolation:0,interpolation_duration:23,transformation:{left_rotation:[-0.102212f,0.0f,0.0f,0.994763f],right_rotation:[0.0f,0.0f,0.0f,1.0f],scale:[1.0f,1.0f,1.0f],translation:[-0.023437f,0.122388f,-0.025419f]}}
