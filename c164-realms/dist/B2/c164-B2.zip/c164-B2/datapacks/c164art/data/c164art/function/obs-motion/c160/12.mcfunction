schedule function c164art:obs-motion/c160/13 2t replace
particle minecraft:cloud 57.75 201.6238 33.5 0.0 1.0 0.3249 0.034 0 normal
