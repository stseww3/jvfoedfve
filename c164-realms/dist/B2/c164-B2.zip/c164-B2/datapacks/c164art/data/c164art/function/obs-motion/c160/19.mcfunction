schedule function c164art:obs-motion/c160/20 4t replace
particle minecraft:trail{target:[72.9884d,201.2902d,-9.6726d],color:9405544,duration:8} 73.7648 201.7715 -9.3115 0 0 0 0 1 normal
particle minecraft:trail{target:[73.7945d,201.526d,10.0107d],color:9405544,duration:8} 73.3043 201.2816 9.2647 0 0 0 0 1 normal
