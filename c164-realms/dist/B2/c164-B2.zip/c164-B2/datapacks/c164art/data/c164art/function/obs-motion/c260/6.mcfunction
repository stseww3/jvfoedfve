schedule function c164art:obs-motion/c260/7 5t replace
data merge entity @e[type=minecraft:item_display,x=11.375,y=203.125,z=-3.99,distance=..0.05,tag=m.int_starhall_flag_0,limit=1] {item:{components:{"minecraft:item_model":"c164:int_starhall_flag_down"}}}
