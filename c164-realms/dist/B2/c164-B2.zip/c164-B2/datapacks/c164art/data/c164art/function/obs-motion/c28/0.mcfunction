execute unless score #run c164m matches 571309228 run return run function c164art:obs-motion/halt
schedule function c164art:obs-motion/c28/1 7t replace
data merge entity @e[type=minecraft:item_display,x=89.75,y=196.5625,z=-35.625,distance=..0.05,tag=m.mach_cable_sheave,limit=1] {start_interpolation:0,interpolation_duration:9,transformation:{left_rotation:[0.846724f,0.0f,0.0f,0.532032f],right_rotation:[0.0f,0.0f,0.0f,1.0f],scale:[1.0f,1.0f,1.0f],translation:[0.0f,0.0f,0.0f]}}
