schedule function c164art:obs-motion/c160/40 1t replace
particle minecraft:cloud 16.7812 202.4363 13.2 0.0 1.0 0.1584 0.022 0 normal
