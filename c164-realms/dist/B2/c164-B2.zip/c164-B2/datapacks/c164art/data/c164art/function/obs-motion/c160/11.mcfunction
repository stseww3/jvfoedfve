schedule function c164art:obs-motion/c160/12 2t replace
particle minecraft:trail{target:[79.7335d,198.3988d,-9.95d],color:9405544,duration:8} 79.4409 197.8786 -10.444 0 0 0 0 1 normal
particle minecraft:trail{target:[73.7824d,200.8372d,10.1358d],color:9405544,duration:8} 73.2316 200.9207 10.7202 0 0 0 0 1 normal
