particle minecraft:end_rod ~-7.8236 ~10.3823 ~-0.8 0.0799 0.0602 0 1 0 force @s
particle minecraft:end_rod ~-7.4565 ~10.649 ~1.6 0.0819 0.0574 0 1 0 force @s
particle minecraft:end_rod ~-6.9849 ~10.9641 ~0.3 0.0843 0.0537 0 1 0 force @s
