execute unless score #run c164m matches 571309228 run return run function c164art:obs-motion/halt
schedule function c164art:obs-motion/c160/1 4t replace
particle minecraft:trail{target:[80.9647d,198.3965d,-17.703d],color:9405544,duration:64} 80.9045 198.3766 -17.8064 0 0 0 0 1 normal
particle minecraft:trail{target:[79.4229d,198.5204d,-8.8258d],color:9405544,duration:8} 80.3314 198.6138 -8.7783 0 0 0 0 1 normal
particle minecraft:trail{target:[72.9892d,201.9131d,-8.1586d],color:9405544,duration:8} 73.7568 201.4933 -8.6357 0 0 0 0 1 normal
playsound c164:hum block @a[x=72.0,y=195.0,z=37.75,distance=..16.0] 72.0 195.0 37.75 2.3 1.0
