schedule function c164art:obs-motion/c160/55 2t replace
particle minecraft:trail{target:[80.8784d,198.3048d,-17.8308d],color:9405544,duration:8} 80.9916 198.0255 -18.1046 0 0 0 0 1 normal
particle minecraft:trail{target:[79.8694d,198.1423d,-9.7588d],color:9405544,duration:8} 80.1965 198.0461 -9.9616 0 0 0 0 1 normal
