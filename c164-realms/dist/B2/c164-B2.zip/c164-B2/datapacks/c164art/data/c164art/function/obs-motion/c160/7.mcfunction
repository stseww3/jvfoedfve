schedule function c164art:obs-motion/c160/8 4t replace
particle minecraft:cloud 74.68 196.1 20.88 0.08 1.0 -0.18 0.05 0 normal
particle minecraft:trail{target:[80.0083d,197.8328d,-9.9051d],color:9405544,duration:8} 79.6582 198.8669 -10.386 0 0 0 0 1 normal
particle minecraft:trail{target:[72.6105d,201.7406d,10.444d],color:9405544,duration:8} 72.2013 201.2446 9.8749 0 0 0 0 1 normal
particle minecraft:cloud 85.4 196.3425 35.695 0.0524 1.0 0.1763 0.035 0 normal
particle minecraft:electric_spark 72.0 195.25 38.2812 0.03 0.01 0.06 0.2 2 normal
