particle minecraft:end_rod ~-11.3883 ~6.2694 ~0.7 0.0482 0.0876 0 1 0 force @s
particle minecraft:end_rod ~-11.7498 ~5.5625 ~-1 0.0428 0.0904 0 1 0 force @s
particle minecraft:end_rod ~-11.2203 ~6.5654 ~1.7 0.0505 0.0863 0 1 0 force @s
