schedule function c164art:obs-motion/c1001/8 61t replace
data merge entity @e[type=minecraft:item_display,x=11.5,y=207.5,z=0.5,distance=..0.05,tag=m.mach_orrery_a_arm_mercury,limit=1] {start_interpolation:0,interpolation_duration:93,transformation:{left_rotation:[0.0f,0.912222f,0.0f,0.409697f],right_rotation:[0.0f,0.0f,0.0f,1.0f],scale:[2.0f,2.0f,2.0f],translation:[0.117884f,1.460625f,0.14947f]}}
