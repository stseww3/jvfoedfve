schedule function c164art:obs-motion/c160/27 4t replace
particle minecraft:trail{target:[80.6187d,198.9519d,-16.5538d],color:9405544,duration:8} 81.3465 198.4467 -17.2986 0 0 0 0 1 normal
particle minecraft:trail{target:[73.424d,201.3677d,-9.2788d],color:9405544,duration:64} 73.3469 201.3832 -9.3703 0 0 0 0 1 normal
particle minecraft:trail{target:[73.4543d,201.0639d,10.5827d],color:9405544,duration:8} 73.6937 201.4937 9.9393 0 0 0 0 1 normal
particle minecraft:cloud 79.75 198.2375 28.5 -0.0699 1.0 0.1763 0.09 0 normal
particle minecraft:electric_spark 72.0 195.25 38.2812 0.03 0.01 0.06 0.2 2 normal
playsound c164:hiss block @a[x=79.75,y=198.1875,z=28.5,distance=..12.0] 79.75 198.1875 28.5 1.0 1.0
