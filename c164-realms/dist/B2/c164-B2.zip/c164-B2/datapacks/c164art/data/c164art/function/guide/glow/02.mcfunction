particle minecraft:end_rod ~-12.352 ~4.0532 ~0.7 0.0312 0.095 0 1 0 force @s
particle minecraft:end_rod ~-12.5764 ~3.2915 ~-1 0.0253 0.0967 0 1 0 force @s
particle minecraft:end_rod ~-12.2417 ~4.3751 ~1.7 0.0337 0.0942 0 1 0 force @s
