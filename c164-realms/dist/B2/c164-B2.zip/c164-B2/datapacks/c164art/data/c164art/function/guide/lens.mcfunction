function c164art:guide/count
execute if score @s c164g matches 6.. run return run function c164art:guide/done
execute if score @s c164g matches 1.. run title @s actionbar [{text:"Star charts: "},{score:{name:"@s",objective:"c164g"}},{text:" of 6"}]
