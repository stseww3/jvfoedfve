# as whoever joins (the map's function tag join): who left before his title came is owed it
execute if entity @s[tag=c164.new] run schedule function c164art:guide/title 40t
