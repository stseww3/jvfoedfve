schedule function c164art:obs-motion/c160/45 4t replace
particle minecraft:trail{target:[80.0799d,198.1278d,-17.0228d],color:9405544,duration:8} 80.2025 198.1532 -17.1538 0 0 0 0 1 normal
particle minecraft:trail{target:[79.3446d,198.3198d,-9.02d],color:9405544,duration:8} 79.2588 198.2658 -8.832 0 0 0 0 1 normal
particle minecraft:trail{target:[72.503d,201.3075d,9.9228d],color:9405544,duration:48} 72.5326 201.3291 9.8076 0 0 0 0 1 normal
