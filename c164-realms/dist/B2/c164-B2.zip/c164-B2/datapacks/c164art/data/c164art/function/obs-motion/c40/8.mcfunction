schedule function c164art:obs-motion/c40/9 1t replace
particle minecraft:end_rod 3.7812 201.0812 7.5938 0.0 0.0 0.0 0.0 1 normal
