schedule function c164art:obs-motion/c160/41 4t replace
particle minecraft:trail{target:[79.6051d,198.3721d,-18.1894d],color:9405544,duration:8} 80.0712 198.4266 -17.7665 0 0 0 0 1 normal
particle minecraft:trail{target:[80.0946d,198.6257d,-9.3999d],color:9405544,duration:8} 79.9613 198.6873 -10.2054 0 0 0 0 1 normal
particle minecraft:trail{target:[72.531d,201.4159d,9.8105d],color:9405544,duration:8} 72.2851 201.4598 9.561 0 0 0 0 1 normal
