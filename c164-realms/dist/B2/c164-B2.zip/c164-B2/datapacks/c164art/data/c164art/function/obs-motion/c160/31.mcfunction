schedule function c164art:obs-motion/c160/32 2t replace
particle minecraft:cloud 57.75 201.6238 33.5 0.0 1.0 0.2493 0.03 0 normal
particle minecraft:cloud 16.9988 201.5637 12.05 0.8 0.8 0.45 0.045 0 normal
