particle minecraft:end_rod ~-10.0311 ~8.269 ~0.7 0.0636 0.0772 0 1 0 force @s
particle minecraft:end_rod ~-10.5172 ~7.6412 ~-1 0.0588 0.0809 0 1 0 force @s
particle minecraft:end_rod ~-9.8112 ~8.5288 ~1.7 0.0656 0.0755 0 1 0 force @s
