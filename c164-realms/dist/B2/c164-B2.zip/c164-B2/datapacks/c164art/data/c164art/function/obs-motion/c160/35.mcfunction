schedule function c164art:obs-motion/c160/36 4t replace
particle minecraft:trail{target:[80.0712d,198.4266d,-17.7665d],color:9405544,duration:8} 79.8475 198.5495 -17.8294 0 0 0 0 1 normal
particle minecraft:trail{target:[79.9613d,198.6873d,-10.2054d],color:9405544,duration:8} 79.7429 198.5729 -9.8993 0 0 0 0 1 normal
particle minecraft:trail{target:[72.2851d,201.4598d,9.561d],color:9405544,duration:8} 72.2495 201.1249 10.2196 0 0 0 0 1 normal
