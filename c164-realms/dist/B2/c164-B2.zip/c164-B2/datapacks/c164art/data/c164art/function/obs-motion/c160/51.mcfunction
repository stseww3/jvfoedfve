schedule function c164art:obs-motion/c160/52 3t replace
particle minecraft:cloud 74.6 196.1 20.88 0.07 1.0 -0.24 0.052 0 normal
particle minecraft:trail{target:[80.9916d,198.0255d,-18.1046d],color:9405544,duration:8} 81.099 198.0449 -17.5368 0 0 0 0 1 normal
particle minecraft:trail{target:[80.1965d,198.0461d,-9.9616d],color:9405544,duration:8} 80.4374 198.2922 -8.9677 0 0 0 0 1 normal
