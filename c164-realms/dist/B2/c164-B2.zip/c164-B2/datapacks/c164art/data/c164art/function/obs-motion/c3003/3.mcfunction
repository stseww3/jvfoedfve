schedule function c164art:obs-motion/c3003/4 143t replace
data merge entity @e[type=minecraft:item_display,x=11.8979,y=207.5,z=1.1892,distance=..0.05,tag=m.mach_orrery_a_lay,limit=1] {start_interpolation:0,interpolation_duration:145,transformation:{left_rotation:[0.0f,-0.565048f,0.0f,0.825058f],right_rotation:[0.0f,0.0f,0.0f,1.0f],scale:[1.0f,1.0f,1.0f],translation:[0.00232f,2.71875f,0.005985f]}}
