particle minecraft:end_rod ~-3.7647 ~12.443 ~-1.4 0.0957 0.029 0 1 0 force @s
particle minecraft:end_rod ~-4.4107 ~12.2289 ~1.1 0.0941 0.0339 0 1 0 force @s
particle minecraft:end_rod ~-3.4376 ~12.5372 ~-0.3 0.0964 0.0264 0 1 0 force @s
