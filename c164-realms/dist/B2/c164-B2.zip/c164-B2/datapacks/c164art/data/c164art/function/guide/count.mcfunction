scoreboard objectives add c164g dummy
scoreboard players set @s c164g 0
execute if entity @s[tag=c164.c1] run scoreboard players add @s c164g 1
execute if entity @s[tag=c164.c2] run scoreboard players add @s c164g 1
execute if entity @s[tag=c164.c3] run scoreboard players add @s c164g 1
execute if entity @s[tag=c164.c4] run scoreboard players add @s c164g 1
execute if entity @s[tag=c164.c5] run scoreboard players add @s c164g 1
execute if entity @s[tag=c164.c6] run scoreboard players add @s c164g 1
