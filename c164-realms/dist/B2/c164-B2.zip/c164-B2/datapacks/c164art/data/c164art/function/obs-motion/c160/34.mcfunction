schedule function c164art:obs-motion/c160/35 4t replace
particle minecraft:trail{target:[79.6498d,198.8313d,-17.6769d],color:9405544,duration:8} 80.3729 198.7506 -18.0622 0 0 0 0 1 normal
particle minecraft:trail{target:[78.8774d,197.9743d,-9.9723d],color:9405544,duration:8} 79.5977 198.347 -10.3081 0 0 0 0 1 normal
particle minecraft:trail{target:[72.5739d,201.0082d,9.2198d],color:9405544,duration:8} 73.6257 201.4635 9.1898 0 0 0 0 1 normal
