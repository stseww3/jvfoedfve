schedule function c164art:obs-motion/c160/42 2t replace
particle minecraft:cloud 74.72 196.1 20.88 0.03 1.0 -0.26 0.058 0 normal
particle minecraft:trail{target:[80.2025d,198.1532d,-17.1538d],color:9405544,duration:8} 79.8949 197.7951 -16.8212 0 0 0 0 1 normal
particle minecraft:trail{target:[79.2588d,198.2658d,-8.832d],color:9405544,duration:8} 78.8702 198.6902 -9.1466 0 0 0 0 1 normal
particle minecraft:trail{target:[72.5326d,201.3291d,9.8076d],color:9405544,duration:8} 72.3924 201.0608 9.9837 0 0 0 0 1 normal
