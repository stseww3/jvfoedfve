particle minecraft:end_rod ~-10.6054 ~7.5183 ~1.5 0.0578 0.0816 0 1 0 force @s
particle minecraft:end_rod ~-10.2674 ~7.9738 ~-0.2 0.0613 0.079 0 1 0 force @s
particle minecraft:end_rod ~-10.7986 ~7.2381 ~-1.6 0.0557 0.0831 0 1 0 force @s
