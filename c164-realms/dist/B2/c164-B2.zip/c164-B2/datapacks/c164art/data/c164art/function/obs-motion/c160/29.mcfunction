schedule function c164art:obs-motion/c160/30 2t replace
particle minecraft:cloud 16.9988 201.5637 12.05 0.9 0.55 0.35 0.055 0 normal
