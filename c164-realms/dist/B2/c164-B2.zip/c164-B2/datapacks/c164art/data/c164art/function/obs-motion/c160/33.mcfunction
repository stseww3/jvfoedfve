schedule function c164art:obs-motion/c160/34 1t replace
particle minecraft:cloud 16.9988 201.5637 12.05 0.6 1.0 0.5 0.035 0 normal
