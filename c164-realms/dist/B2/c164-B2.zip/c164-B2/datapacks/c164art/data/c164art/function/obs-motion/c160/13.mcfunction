schedule function c164art:obs-motion/c160/14 4t replace
particle minecraft:trail{target:[79.7429d,198.5729d,-9.8993d],color:9405544,duration:64} 79.6424 198.5745 -9.9444 0 0 0 0 1 normal
particle minecraft:trail{target:[73.0004d,200.8411d,-9.9296d],color:9405544,duration:8} 72.439 201.6855 -9.4776 0 0 0 0 1 normal
particle minecraft:trail{target:[74.0543d,201.1641d,9.7709d],color:9405544,duration:8} 73.1119 201.7101 9.3475 0 0 0 0 1 normal
