particle minecraft:end_rod ~-9.0306 ~9.3514 ~1.5 0.0719 0.0695 0 1 0 force @s
particle minecraft:end_rod ~-8.6141 ~9.7364 ~-0.2 0.0749 0.0663 0 1 0 force @s
particle minecraft:end_rod ~-9.2723 ~9.1118 ~-1.6 0.0701 0.0713 0 1 0 force @s
