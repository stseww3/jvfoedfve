schedule function c164art:obs-motion/c40/3 2t replace
particle minecraft:end_rod 69.5 195.0812 23.7812 0.0 0.0 0.0 0.0 1 normal
