schedule function c164art:obs-motion/c170/2 22t replace
data merge entity @e[type=minecraft:item_display,x=71.1094,y=197.375,z=32.0,distance=..0.05,tag=m.needle_south,limit=1] {start_interpolation:0,interpolation_duration:24,transformation:{left_rotation:[-0.140108f,0.0f,0.0f,0.990136f],right_rotation:[0.0f,0.0f,0.0f,1.0f],scale:[1.0f,1.0f,1.0f],translation:[-0.023437f,0.120092f,-0.034681f]}}
