schedule function c164art:obs-motion/c160/46 4t replace
particle minecraft:trail{target:[79.6714d,198.8252d,-18.044d],color:9405544,duration:8} 80.4132 197.8724 -18.374 0 0 0 0 1 normal
particle minecraft:trail{target:[79.1142d,197.7736d,-8.8658d],color:9405544,duration:8} 80.0691 198.6558 -8.612 0 0 0 0 1 normal
