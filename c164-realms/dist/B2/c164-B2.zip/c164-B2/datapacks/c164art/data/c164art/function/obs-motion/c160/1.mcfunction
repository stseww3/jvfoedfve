schedule function c164art:obs-motion/c160/2 4t replace
particle minecraft:cloud 74.28 196.1 20.88 -0.06 1.0 -0.25 0.062 0 normal
particle minecraft:trail{target:[80.7917d,198.3231d,-17.9121d],color:9405544,duration:48} 80.8784 198.3048 -17.8308 0 0 0 0 1 normal
particle minecraft:trail{target:[80.1342d,197.9894d,-9.9396d],color:9405544,duration:8} 79.8694 198.1423 -9.7588 0 0 0 0 1 normal
