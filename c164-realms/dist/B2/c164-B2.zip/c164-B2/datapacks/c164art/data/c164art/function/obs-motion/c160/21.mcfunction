schedule function c164art:obs-motion/c160/22 4t replace
particle minecraft:trail{target:[81.213d,198.3813d,-17.9064d],color:9405544,duration:8} 80.9647 198.3965 -17.703 0 0 0 0 1 normal
particle minecraft:trail{target:[73.8555d,201.4455d,-9.3514d],color:9405544,duration:8} 72.9884 201.2902 -9.6726 0 0 0 0 1 normal
particle minecraft:trail{target:[73.5009d,201.4377d,9.9476d],color:9405544,duration:8} 73.7945 201.526 10.0107 0 0 0 0 1 normal
