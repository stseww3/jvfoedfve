particle minecraft:end_rod ~-2.7029 ~12.7159 ~1.5 0.0978 0.0208 0 1 0 force @s
particle minecraft:end_rod ~-2.7029 ~12.7159 ~-0.2 0.0978 0.0208 0 1 0 force @s
particle minecraft:end_rod ~-3.0348 ~12.6408 ~-1.6 0.0972 0.0233 0 1 0 force @s
