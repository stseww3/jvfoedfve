particle minecraft:end_rod ~-4.125 ~12.3282 ~0.7 0.0948 0.0317 0 1 0 force @s
particle minecraft:end_rod ~-4.8699 ~12.0534 ~-1 0.0927 0.0375 0 1 0 force @s
particle minecraft:end_rod ~-3.8008 ~12.432 ~1.7 0.0956 0.0292 0 1 0 force @s
