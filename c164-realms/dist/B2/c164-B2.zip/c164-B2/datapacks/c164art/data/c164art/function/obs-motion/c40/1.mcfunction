schedule function c164art:obs-motion/c40/2 1t replace
data merge entity @e[type=minecraft:item_display,x=9.1875,y=208.5938,z=-23.1875,distance=..0.05,tag=m.mach_rec_pen,limit=1] {start_interpolation:0,interpolation_duration:2,transformation:{left_rotation:[0.0f,0.0f,0.0f,1.0f],right_rotation:[0.0f,0.0f,0.0f,1.0f],scale:[1.0f,1.0f,1.0f],translation:[0.0f,0.037722f,0.069013f]}}
