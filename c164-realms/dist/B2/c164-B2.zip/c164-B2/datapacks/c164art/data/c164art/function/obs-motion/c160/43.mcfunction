schedule function c164art:obs-motion/c160/44 4t replace
particle minecraft:trail{target:[80.4132d,197.8724d,-18.374d],color:9405544,duration:8} 79.6051 198.3721 -18.1894 0 0 0 0 1 normal
particle minecraft:trail{target:[80.0691d,198.6558d,-8.612d],color:9405544,duration:8} 80.0946 198.6257 -9.3999 0 0 0 0 1 normal
particle minecraft:trail{target:[72.5883d,201.4134d,9.7058d],color:9405544,duration:64} 72.531 201.4159 9.8105 0 0 0 0 1 normal
