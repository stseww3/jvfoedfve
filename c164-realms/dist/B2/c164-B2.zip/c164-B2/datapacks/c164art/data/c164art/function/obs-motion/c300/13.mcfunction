schedule function c164art:obs-motion/c300/14 2t replace
particle minecraft:electric_spark 24.875 202.5 -38.125 0.03 0.05 0.03 0.15 3 normal
