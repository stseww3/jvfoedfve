schedule function c164art:obs-motion/c160/0 2t replace
particle minecraft:cloud 16.7812 202.4363 13.2 0.0 1.0 0.3249 0.034 0 normal
