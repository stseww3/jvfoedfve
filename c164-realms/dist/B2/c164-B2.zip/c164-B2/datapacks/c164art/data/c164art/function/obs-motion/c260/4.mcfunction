schedule function c164art:obs-motion/c260/5 33t replace
data merge entity @e[type=minecraft:item_display,x=8.0,y=203.375,z=-24.1406,distance=..0.05,tag=m.bboard_needle_main,limit=1] {start_interpolation:0,interpolation_duration:35,transformation:{left_rotation:[0.046972f,0.0f,0.0f,0.998896f],right_rotation:[0.0f,0.0f,0.0f,1.0f],scale:[1.0f,1.0f,1.0f],translation:[-0.023438f,0.124448f,0.01173f]}}
