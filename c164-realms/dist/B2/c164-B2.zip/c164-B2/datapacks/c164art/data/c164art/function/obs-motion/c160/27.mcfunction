schedule function c164art:obs-motion/c160/28 4t replace
particle minecraft:cloud 74.56 196.1 20.88 -0.08 1.0 -0.28 0.07 0 normal
particle minecraft:trail{target:[80.4467d,198.6445d,-17.9267d],color:9405544,duration:8} 80.3225 198.9257 -18.4262 0 0 0 0 1 normal
particle minecraft:trail{target:[73.8369d,200.6653d,10.122d],color:9405544,duration:8} 73.3738 201.0488 10.1067 0 0 0 0 1 normal
