particle minecraft:end_rod ~-12.2289 ~4.4107 ~-1.4 0.0339 0.0941 0 1 0 force @s
particle minecraft:end_rod ~-12.443 ~3.7647 ~1.1 0.029 0.0957 0 1 0 force @s
particle minecraft:end_rod ~-12.1092 ~4.7293 ~-0.3 0.0364 0.0931 0 1 0 force @s
