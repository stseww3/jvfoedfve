schedule function c164art:obs-motion/c160/3 4t replace
particle minecraft:trail{target:[78.6478d,198.8712d,-9.3038d],color:9405544,duration:8} 79.4229 198.5204 -8.8258 0 0 0 0 1 normal
particle minecraft:trail{target:[72.2385d,201.1935d,-8.7271d],color:9405544,duration:8} 72.9892 201.9131 -8.1586 0 0 0 0 1 normal
