schedule function c164art:obs-motion/c160/37 1t replace
particle minecraft:trail{target:[79.8949d,197.7951d,-16.8212d],color:9405544,duration:8} 79.6498 198.8313 -17.6769 0 0 0 0 1 normal
particle minecraft:trail{target:[78.8702d,198.6902d,-9.1466d],color:9405544,duration:8} 78.8774 197.9743 -9.9723 0 0 0 0 1 normal
particle minecraft:trail{target:[72.3924d,201.0608d,9.9837d],color:9405544,duration:8} 72.5739 201.0082 9.2198 0 0 0 0 1 normal
