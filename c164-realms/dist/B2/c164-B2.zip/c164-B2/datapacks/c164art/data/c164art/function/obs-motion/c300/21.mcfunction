schedule function c164art:obs-motion/c300/22 2t replace
data merge entity @e[type=minecraft:item_display,x=19.1663,y=205.8406,z=6.1813,distance=..0.05,tag=m.prop_bell_hammer,limit=1] {start_interpolation:0,interpolation_duration:2,transformation:{left_rotation:[0.0f,0.0f,0.0f,1.0f],right_rotation:[0.0f,0.0f,0.0f,1.0f],scale:[1.0f,1.0f,1.0f],translation:[0.101562f,-0.276563f,0.0f]}}
