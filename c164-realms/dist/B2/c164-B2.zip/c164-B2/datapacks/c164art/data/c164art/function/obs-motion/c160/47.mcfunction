schedule function c164art:obs-motion/c160/48 3t replace
particle minecraft:trail{target:[80.4765d,198.1168d,-18.4831d],color:9405544,duration:8} 79.6714 198.8252 -18.044 0 0 0 0 1 normal
particle minecraft:trail{target:[79.9384d,198.5357d,-8.9332d],color:9405544,duration:8} 79.1142 197.7736 -8.8658 0 0 0 0 1 normal
