schedule function c164art:obs-motion/c160/5 1t replace
particle minecraft:small_flame 78.7 195.4688 28.2 -1.6 1.0 -0.4 0.022 0 normal
particle minecraft:electric_spark 71.0625 196.5938 32.4375 0.01 0.03 0.02 0.2 2 normal
