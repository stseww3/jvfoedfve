schedule function c164art:obs-motion/c160/6 2t replace
particle minecraft:cloud 19.4062 200.6238 33.5 0.0 1.0 0.2493 0.03 0 normal
