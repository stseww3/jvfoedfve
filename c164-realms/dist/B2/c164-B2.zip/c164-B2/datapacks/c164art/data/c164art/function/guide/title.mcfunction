# the map's name, once, to whoever is new and is there
title @a[tag=c164.new] times 20 80 30
title @a[tag=c164.new] subtitle {"text":"OBSERVATORY","color":"#f2ead6"}
title @a[tag=c164.new] title {"text":"BLUE HOUR","color":"#f2ead6"}
tag @a[tag=c164.new] remove c164.new
