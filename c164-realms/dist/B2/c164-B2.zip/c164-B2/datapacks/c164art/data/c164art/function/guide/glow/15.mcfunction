particle minecraft:end_rod ~-8.0334 ~10.2208 ~-1.4 0.0786 0.0618 0 1 0 force @s
particle minecraft:end_rod ~-8.5573 ~9.7864 ~1.1 0.0753 0.0658 0 1 0 force @s
particle minecraft:end_rod ~-7.7631 ~10.4276 ~-0.3 0.0802 0.0597 0 1 0 force @s
