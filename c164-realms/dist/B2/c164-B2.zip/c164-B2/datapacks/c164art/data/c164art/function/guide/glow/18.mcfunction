particle minecraft:end_rod ~-6.3356 ~11.3517 ~0.7 0.0873 0.0487 0 1 0 force @s
particle minecraft:end_rod ~-7.0168 ~10.9437 ~-1 0.0842 0.054 0 1 0 force @s
particle minecraft:end_rod ~-6.0362 ~11.5136 ~1.7 0.0886 0.0464 0 1 0 force @s
