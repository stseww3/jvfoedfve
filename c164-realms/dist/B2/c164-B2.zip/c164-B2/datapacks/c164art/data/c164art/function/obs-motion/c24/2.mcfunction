schedule function c164art:obs-motion/c24/3 2t replace
data merge entity @e[type=minecraft:item_display,x=84.55,y=195.375,z=35.875,distance=..0.05,tag=m.mach_engine_governor,limit=1] {start_interpolation:0,interpolation_duration:8,transformation:{left_rotation:[0.0f,0.965926f,0.0f,-0.258819f],right_rotation:[0.0f,0.0f,0.0f,1.0f],scale:[1.0f,1.0f,1.0f],translation:[0.0f,1.5f,0.0f]}}
