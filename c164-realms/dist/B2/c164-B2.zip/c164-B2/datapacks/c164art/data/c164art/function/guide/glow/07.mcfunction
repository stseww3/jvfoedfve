particle minecraft:end_rod ~-11.2012 ~6.598 ~-1.4 0.0508 0.0862 0 1 0 force @s
particle minecraft:end_rod ~-11.5311 ~6.0027 ~1.1 0.0462 0.0887 0 1 0 force @s
particle minecraft:end_rod ~-11.0246 ~6.889 ~-0.3 0.053 0.0848 0 1 0 force @s
