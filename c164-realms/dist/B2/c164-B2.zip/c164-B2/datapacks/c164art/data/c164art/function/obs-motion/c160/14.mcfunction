schedule function c164art:obs-motion/c160/15 3t replace
particle minecraft:trail{target:[79.6217d,198.3671d,-9.9926d],color:9405544,duration:48} 79.7335 198.3988 -9.95 0 0 0 0 1 normal
particle minecraft:trail{target:[73.4438d,201.1459d,10.0899d],color:9405544,duration:8} 73.7824 200.8372 10.1358 0 0 0 0 1 normal
