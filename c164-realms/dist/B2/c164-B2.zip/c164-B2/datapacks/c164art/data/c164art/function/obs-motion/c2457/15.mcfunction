schedule function c164art:obs-motion/c2457/16 56t replace
data merge entity @e[type=minecraft:item_display,x=11.5,y=207.5,z=0.5,distance=..0.05,tag=m.mach_orrery_a_arm_mars,limit=1] {start_interpolation:0,interpolation_duration:191,transformation:{left_rotation:[0.0f,0.993014f,0.0f,0.117998f],right_rotation:[0.0f,0.0f,0.0f,1.0f],scale:[2.0f,2.0f,2.0f],translation:[0.454182f,1.429375f,0.107311f]}}
