schedule function c164art:obs-motion/c300/6 2t replace
data merge entity @e[type=minecraft:item_display,x=6.8906,y=208.5969,z=-23.4688,distance=..0.05,tag=m.mach_rec_telegraph_sounder,limit=1] {start_interpolation:0,interpolation_duration:1,transformation:{left_rotation:[0.0f,0.0f,0.0f,1.0f],right_rotation:[0.0f,0.0f,0.0f,1.0f],scale:[1.0f,1.0f,1.0f],translation:[0.29375f,-0.085938f,0.1125f]}}
data merge entity @e[type=minecraft:item_display,x=19.1663,y=205.8406,z=6.1813,distance=..0.05,tag=m.prop_bell_hammer,limit=1] {start_interpolation:0,interpolation_duration:4,transformation:{left_rotation:[0.0f,0.0f,0.0f,1.0f],right_rotation:[0.0f,0.0f,0.0f,1.0f],scale:[1.0f,1.0f,1.0f],translation:[0.007812f,-0.276563f,0.0f]}}
particle minecraft:electric_spark 24.875 202.5 -38.125 0.03 0.05 0.03 0.15 3 normal
playsound minecraft:block.note_block.bell block @a[x=19.1875,y=205.3094,z=6.3281,distance=..12.0] 19.1875 205.3094 6.3281 0.35 1.6
playsound c164:telegraph block @a[x=6.5,y=208.5,z=-23.5,distance=..6.0] 6.5 208.5 -23.5 1.0 1.0
