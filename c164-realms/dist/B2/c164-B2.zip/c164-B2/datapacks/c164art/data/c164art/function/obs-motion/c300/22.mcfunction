schedule function c164art:obs-motion/c300/23 8t replace
data merge entity @e[type=minecraft:item_display,x=19.1663,y=205.8406,z=6.1813,distance=..0.05,tag=m.prop_bell_hammer,limit=1] {start_interpolation:0,interpolation_duration:4,transformation:{left_rotation:[0.0f,0.0f,0.0f,1.0f],right_rotation:[0.0f,0.0f,0.0f,1.0f],scale:[1.0f,1.0f,1.0f],translation:[0.007812f,-0.276563f,0.0f]}}
playsound minecraft:block.note_block.bell block @a[x=19.1875,y=205.3094,z=6.3281,distance=..12.0] 19.1875 205.3094 6.3281 0.35 1.6
