schedule function c164art:obs-motion/c160/7 4t replace
particle minecraft:trail{target:[79.0154d,198.3722d,-10.1097d],color:9405544,duration:8} 78.6478 198.8712 -9.3038 0 0 0 0 1 normal
particle minecraft:trail{target:[72.2339d,201.6499d,-9.5223d],color:9405544,duration:8} 72.2385 201.1935 -8.7271 0 0 0 0 1 normal
