schedule function c164art:obs-motion/c40/8 1t replace
data merge entity @e[type=minecraft:item_display,x=6.4006,y=203.3125,z=0.5,distance=..0.05,tag=m.mach_clock_pendulum,limit=1] {start_interpolation:0,interpolation_duration:7,transformation:{left_rotation:[0.0f,0.0f,0.043181f,0.999067f],right_rotation:[0.0f,0.0f,0.0f,1.0f],scale:[1.0f,1.0f,1.0f],translation:[0.060667f,-0.700503f,0.0f]}}
data merge entity @e[type=minecraft:item_display,x=8.0,y=212.0312,z=25.5212,distance=..0.05,tag=m.prop_inst_regulator_pendulum,limit=1] {start_interpolation:0,interpolation_duration:7,transformation:{left_rotation:[0.0f,0.0f,0.025914f,0.999664f],right_rotation:[0.0f,0.0f,0.0f,1.0f],scale:[1.0f,1.0f,1.0f],translation:[0.032786f,-0.631963f,0.0f]}}
data merge entity @e[type=minecraft:item_display,x=9.1875,y=208.5938,z=-23.1875,distance=..0.05,tag=m.mach_rec_pen,limit=1] {start_interpolation:0,interpolation_duration:1,transformation:{left_rotation:[0.0f,0.0f,0.0f,1.0f],right_rotation:[0.0f,0.0f,0.0f,1.0f],scale:[1.0f,1.0f,1.0f],translation:[-0.0625f,0.037722f,0.069013f]}}
data merge entity @e[type=minecraft:item_display,x=2.5,y=209.5312,z=-24.74,distance=..0.05,tag=m.prop_inst_regulator_pendulum,limit=1] {start_interpolation:0,interpolation_duration:7,transformation:{left_rotation:[0.0f,0.0f,0.025914f,0.999664f],right_rotation:[0.0f,0.0f,0.0f,1.0f],scale:[1.0f,1.0f,1.0f],translation:[0.032786f,-0.631963f,0.0f]}}
data merge entity @e[type=minecraft:item_display,x=13.5,y=209.5312,z=-24.74,distance=..0.05,tag=m.prop_inst_regulator_pendulum,limit=1] {start_interpolation:0,interpolation_duration:7,transformation:{left_rotation:[0.0f,0.0f,0.025914f,0.999664f],right_rotation:[0.0f,0.0f,0.0f,1.0f],scale:[1.0f,1.0f,1.0f],translation:[0.032786f,-0.631963f,0.0f]}}
data merge entity @e[type=minecraft:item_display,x=4.5,y=220.7812,z=10.8338,distance=..0.05,tag=m.prop_inst_regulator_pendulum,limit=1] {start_interpolation:0,interpolation_duration:7,transformation:{left_rotation:[0.0f,0.0f,0.025914f,0.999664f],right_rotation:[0.0f,0.0f,0.0f,1.0f],scale:[1.0f,1.0f,1.0f],translation:[0.032786f,-0.631963f,0.0f]}}
particle minecraft:campfire_signal_smoke 86.45 223.5 23.03 -0.007 1.0 0.1512 0.0728 0 force
particle minecraft:campfire_signal_smoke 87.25 223.77 22.71 -0.014 1.0 0.2016 0.0693 0 force
playsound c164:tock block @a[x=6.3906,y=203.3125,z=0.5,distance=..10.0] 6.3906 203.3125 0.5 1.0 1.0
playsound c164:tock block @a[x=8.0,y=212.0312,z=25.5212,distance=..8.0] 8.0 212.0312 25.5212 1.0 1.0
playsound c164:tock block @a[x=2.5,y=209.5312,z=-24.74,distance=..8.0] 2.5 209.5312 -24.74 1.0 1.0
playsound c164:tock block @a[x=13.5,y=209.5312,z=-24.74,distance=..8.0] 13.5 209.5312 -24.74 1.0 1.0
playsound c164:tock block @a[x=4.5,y=220.7812,z=10.8338,distance=..8.0] 4.5 220.7812 10.8338 1.0 1.0
