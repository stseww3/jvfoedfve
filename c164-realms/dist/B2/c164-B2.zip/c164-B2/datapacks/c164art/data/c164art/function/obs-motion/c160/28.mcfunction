schedule function c164art:obs-motion/c160/29 2t replace
particle minecraft:trail{target:[80.0087d,197.8693d,-17.0034d],color:9405544,duration:8} 80.6187 198.9519 -16.5538 0 0 0 0 1 normal
particle minecraft:trail{target:[72.7072d,201.8882d,10.8889d],color:9405544,duration:8} 73.4543 201.0639 10.5827 0 0 0 0 1 normal
particle minecraft:cloud 79.75 198.2375 28.5 0.0875 1.0 0.1228 0.075 0 normal
particle minecraft:electric_spark 71.0625 196.5938 32.4375 0.01 0.03 0.02 0.2 2 normal
