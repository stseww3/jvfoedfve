schedule function c164art:obs-motion/c1617/9 21t replace
data merge entity @e[type=minecraft:item_display,x=11.5,y=207.5,z=0.5,distance=..0.05,tag=m.mach_orrery_a_arm_venus,limit=1] {start_interpolation:0,interpolation_duration:149,transformation:{left_rotation:[0.0f,0.911239f,0.0f,0.411877f],right_rotation:[0.0f,0.0f,0.0f,1.0f],scale:[2.0f,2.0f,2.0f],translation:[0.168283f,1.616875f,0.203354f]}}
