schedule function c164art:obs-motion/c2400/10 200t replace
data merge entity @e[type=minecraft:item_display,x=9.0938,y=208.5625,z=-23.5625,distance=..0.05,tag=m.mach_rec_drum,limit=1] {start_interpolation:0,interpolation_duration:202,transformation:{left_rotation:[-0.497731f,0.0f,0.0f,-0.867331f],right_rotation:[0.0f,0.0f,0.0f,1.0f],scale:[1.0f,1.0f,1.0f],translation:[0.0f,0.023987f,0.041049f]}}
