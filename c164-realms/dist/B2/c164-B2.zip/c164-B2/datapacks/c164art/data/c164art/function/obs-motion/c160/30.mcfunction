schedule function c164art:obs-motion/c160/31 2t replace
particle minecraft:cloud 74.36 196.1 20.88 0.05 1.0 -0.16 0.046 0 normal
particle minecraft:trail{target:[80.3729d,198.7506d,-18.0622d],color:9405544,duration:8} 80.4467 198.6445 -17.9267 0 0 0 0 1 normal
particle minecraft:trail{target:[79.5977d,198.347d,-10.3081d],color:9405544,duration:8} 79.6217 198.3671 -9.9926 0 0 0 0 1 normal
particle minecraft:trail{target:[73.6257d,201.4635d,9.1898d],color:9405544,duration:8} 73.8369 200.6653 10.122 0 0 0 0 1 normal
