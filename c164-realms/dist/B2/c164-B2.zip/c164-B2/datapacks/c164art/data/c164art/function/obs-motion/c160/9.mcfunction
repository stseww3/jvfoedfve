schedule function c164art:obs-motion/c160/10 4t replace
particle minecraft:cloud 74.45 196.1 20.88 0.02 1.0 -0.3 0.045 0 normal
particle minecraft:trail{target:[79.4409d,197.8786d,-10.444d],color:9405544,duration:8} 80.0083 197.8328 -9.9051 0 0 0 0 1 normal
particle minecraft:trail{target:[73.2316d,200.9207d,10.7202d],color:9405544,duration:8} 72.6105 201.7406 10.444 0 0 0 0 1 normal
