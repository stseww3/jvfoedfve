schedule function c164art:obs-motion/c160/33 3t replace
particle minecraft:trail{target:[79.8475d,198.5495d,-17.8294d],color:9405544,duration:8} 80.0087 197.8693 -17.0034 0 0 0 0 1 normal
particle minecraft:trail{target:[72.2495d,201.1249d,10.2196d],color:9405544,duration:8} 72.7072 201.8882 10.8889 0 0 0 0 1 normal
particle minecraft:cloud 79.75 198.2375 28.5 0.0 1.0 0.2309 0.06 0 normal
particle minecraft:electric_spark 72.0 194.75 38.2812 0.03 0.01 0.06 0.2 2 normal
