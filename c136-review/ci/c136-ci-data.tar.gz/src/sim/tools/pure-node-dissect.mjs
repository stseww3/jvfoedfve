import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { Game, loadMap, NEUTRAL, P_INNER, P_BORDER, iV } from '../sim/index.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const SIM_ROOT = path.resolve(__dirname, '..');

export function decodeReplay(raw) {
  let ga = raw.trim();
  const eq = ga.indexOf('=');
  if (eq >= 0) ga = ga.substring(eq + 1);
  ga = ga.replace(/[^a-zA-Z0-9_\-]/g, '-');
  const abv = new Uint8Array(78);
  abv[50] = 37;
  for (let i = 0; i < 10; i++) abv[i + 3] = i + 1;
  for (let i = 0; i < 26; i++) { abv[i + 20] = i + 11; abv[i + 52] = i + 38; }
  const aCT = new Uint8Array(ga.length);
  for (let i = 0; i < ga.length; i++) aCT[i] = abv[ga.charCodeAt(i) - 45];
  const mH = new Uint8Array((6 * aCT.length + 7) >> 3);
  let wp = 0;
  for (let i = 0; i < aCT.length; i++) {
    const v = aCT[i];
    for (let b = 5; b >= 0; b--, wp++) mH[wp >> 3] |= ((v >> b) & 1) << (7 - (wp & 7));
  }
  let a9 = 0;
  const i2 = (size) => {
    let h2 = 0;
    const bz = a9 + size - 1;
    for (let a1 = a9; a1 <= bz; a1++) h2 = (h2 << 1) | ((mH[a1 >> 3] >> (7 - (a1 & 7))) & 1);
    a9 += size;
    return h2 >>> 0;
  };
  const aHl = (aEd) => {
    const len = i2(aEd);
    let s = '';
    for (let i = 0; i < len; i++) s += String.fromCharCode(i2(16));
    return s;
  };
  const aHn = (aEd, aY3, aZd) => {
    const fe = i2(aEd);
    if (!fe) return null;
    const len = Math.max(fe, aZd);
    const dC = new (aY3 <= 8 ? Uint8Array : aY3 <= 16 ? Uint16Array : Uint32Array)(len);
    for (let i = 0; i < fe; i++) dC[i] = i2(aY3);
    if (dC[fe - 1]) dC.fill(dC[fe - 1], fe);
    return dC;
  };
  const aHo = (aEd, aY6, aZd) => {
    const fe = i2(aEd);
    if (!fe) return null;
    const len = Math.max(fe, aZd);
    const dC = new Array(len);
    for (let i = 0; i < fe; i++) dC[i] = aHl(aY6);
    dC.fill(dC[fe - 1], fe);
    return dC;
  };
  const rVersion = i2(12), vs = i2(12), statedSize = i2(31);
  const vu = {};
  vu.mapType = i2(2);
  vu.mapProceduralIndex = i2(8);
  vu.mapRealisticIndex = i2(8);
  vu.mapSeed = i2(14);
  vu.mapName = aHl(5);
  if (vu.mapType === 2) { const aDc = i2(30); a9 += 6 * aDc; }
  vu.passableWater = i2(1);
  vu.passableMountains = i2(1);
  vu.playerCount = i2(10);
  vu.humanCount = i2(10);
  vu.selectedPlayer = i2(9);
  vu.gameMode = i2(1);
  vu.playerMode = i2(2);
  vu.battleRoyaleMode = i2(2);
  vu.numberTeams = i2(4);
  vu.isZombieMode = i2(1);
  vu.isContest = i2(1);
  vu.isReplay = i2(1);
  vu.elo = aHn(2, 14, 2);
  vu.colorsType = i2(1);
  vu.colorsPersonalized = i2(1);
  vu.colorsData = aHn(10, 18, 512);
  vu.selectableColor = i2(1);
  vu.teamPlayerCount = aHn(4, 10, 9);
  vu.neutralBots = i2(1);
  vu.botDifficultyType = i2(2);
  vu.botDifficultyValue = i2(4);
  vu.botDifficultyTeam = aHn(4, 4, 9);
  vu.botDifficultyData = aHn(10, 4, 512);
  vu.spawningType = i2(2);
  vu.spawningSeed = i2(14);
  vu.spawningData = aHn(11, 12, 1024);
  vu.selectableSpawn = i2(1);
  vu.playerNamesType = i2(2);
  vu.playerNamesData = aHo(10, 5, 512);
  vu.selectableName = i2(1);
  vu.aIncomeType = i2(2); vu.aIncomeValue = i2(8); vu.aIncomeData = aHn(10, 8, 512);
  vu.tIncomeType = i2(2); vu.tIncomeValue = i2(8); vu.tIncomeData = aHn(10, 8, 512);
  vu.iIncomeType = i2(2); vu.iIncomeValue = i2(8); vu.iIncomeData = aHn(10, 8, 512);
  vu.sResourcesType = i2(2); vu.sResourcesValue = i2(11); vu.sResourcesData = aHn(10, 11, 512);
  vu.nA = aHn(10, 30, 0);
  const ek = i2(5), aHp = i2(30), aHq = i2(30);
  const cmds = [];
  for (let i = 0; i < aHp; i++) {
    const id = i2(4), player = i2(9);
    let dX = 0, dZ = 0;
    if (id === 0) dX = i2(22);
    else if (id === 1) { dX = i2(10); dZ = i2(10); }
    else if (id === 2) { dX = i2(10); dZ = i2(9); }
    else if (id === 3) { dX = i2(10); dZ = i2(27); }
    else if (id === 4) { dX = i2(10); dZ = i2(16); }
    else if (id === 5 || id === 6) dX = i2(10);
    else if (id === 7) dX = i2(1);
    else if (id === 10) { dX = i2(20); dZ = i2(22); }
    cmds.push({ id, player, dX, dZ });
  }
  const jY = new Uint8Array(aHq), ja = new Uint32Array(aHq);
  for (let i = 0; i < aHq; i++) { jY[i] = i2(1); ja[i] = i2(ek); }
  return { vu, cmds, jY, ja };
}

function getContactMap(g, p) {
  const B = g.border[p];
  const m = new Map();
  if (!B || !g.alive[p]) return m;
  const seen = new Set();
  const d4 = g.dir4, px = g.px, own = g.own;
  for (let i = B.length - 1; i >= 0; i--) {
    const b = B[i];
    for (let k = 0; k < 4; k++) {
      const c = b + d4[k];
      if (seen.has(c)) continue;
      if (px[c] >= P_INNER && own[c] !== p) {
        seen.add(c);
        m.set(own[c], (m.get(own[c]) || 0) + 1);
      }
    }
  }
  return m;
}

const weight = (t) =>
  t < 1500 ? 0.002 * t : t < 2000 ? 3 - (0.15 * (t - 1500)) / 500 : t < 2500 ? 2.85 - (1.05 * (t - 2000)) / 500 : 1.8;

export function simulateAndDissect(gameId, replayPath, stratTag = 'file:v33') {
  const d = decodeReplay(fs.readFileSync(replayPath, 'utf8'));
  const vu = d.vu;
  const mapIdx = vu.mapType === 1
    ? (vu.mapRealisticIndex <= 9 ? 10 + vu.mapRealisticIndex : 12 + vu.mapRealisticIndex)
    : (vu.mapProceduralIndex <= 9 ? vu.mapProceduralIndex : 10 + vu.mapProceduralIndex);
  const mapSeed = vu.mapType === 1 ? 0 : vu.mapSeed;
  const map = loadMap(mapIdx, mapSeed);
  const H = vu.humanCount;
  const g = new Game({
    map,
    humans: H,
    players: vu.playerCount,
    difficulty: H > 1 ? 0 : vu.botDifficultyValue,
    spawnSeed: vu.spawningSeed,
    selectableSpawn: !!vu.selectableSpawn,
    battleRoyaleMode: vu.battleRoyaleMode,
    humanColors: vu.colorsData ? Array.from(vu.colorsData.subarray(0, H)) : [0],
  });
  const me = vu.selectedPlayer;
  g.me = me;

  const jJ = H <= 2 ? 30 : H <= 50 ? 40 : 50;
  let iv = 0, iw = 0, ix = 0, iy = 0;

  const actionLog = [];
  const snapshots = new Map();
  const deathT = new Int32Array(H).fill(-1);
  const leftT = new Int32Array(H).fill(-1);

  const execCmd = (c) => {
    const { id, player, dX, dZ } = c;
    if (id === 0) {
      g.chooseSpawn(dX % g.W, Math.floor(dX / g.W), player, false);
    } else if (id === 1) {
      const pct = dX, target = dZ;
      const B_before = g.bal[player], L_before = g.terr[player];
      const box_p = [g.x0[player], g.y0[player], g.x1[player], g.y1[player]];
      const Lq = target < 512 ? g.terr[target] : 0;
      const Bq = target < 512 ? g.bal[target] : 0;
      const peakQ = target < 512 ? g.peak[target] : 0;
      const box_q = target < 512 ? [g.x0[target], g.y0[target], g.x1[target], g.y1[target]] : [0, 0, 0, 0];
      const inAtk = target < 512 ? g.attackTroopsOn(target, player) : 0;
      const myAtkBefore = target < 512 ? g.attackTroopsOn(player, target) : 0;
      let otherAtkOnTarget = 0;
      if (target < 512) {
        for (const a of g.attackersOf(target)) if (a !== player) otherAtkOnTarget += g.attackTroopsOn(a, target);
      }
      let outOtherTarget = 0;
      if (target < H) {
        const b = g.slotBase(target);
        for (let i = 0; i < g.atkCount[target]; i++) if (g.atkTarget[b + i] !== player) outOtherTarget += g.atkTroops[b + i];
      }
      const nbMap = player < H ? getContactMap(g, player) : new Map();
      const cnt = nbMap.get(target) ?? 0;
      const humanNbs = [...nbMap.keys()].filter(k => k < H && g.alive[k] && !g.isBot(k));
      const ok = g.attack(pct, target, player);
      if (ok && player < H) {
        const sent = g.attackTroopsTmp;
        const fee = g.attackFeeTmp;
        const ds = [];
        for (let p = 0; p < H; p++) if (p !== player && g.isAlive(p) && g.terr[p] >= 100) ds.push(g.bal[p] / g.terr[p]);
        ds.sort((a, b) => a - b);
        const dMed = ds.length ? ds[ds.length >> 1] : B_before / Math.max(1, L_before);
        const d_p = B_before / Math.max(1, L_before);
        const d_q = Lq > 0 ? Bq / Lq : 0;
        const worth = +(0.5 * weight(g.t) * (g.t >= 2500 ? Math.max(d_p, 0.85 * dMed) : d_p)).toFixed(1);
        const collapseLine = target < H ? Math.floor(peakQ / 4) : Math.floor(Lq / 4);
        const xRatio = Lq > 0 ? Math.min(1, collapseLine / Math.max(1, Lq)) : 0.25;
        const elim = Lq > 0 ? Math.round(2 * Bq * (1 - Math.pow(xRatio, 1.6)) + 2 * Math.max(0, Lq - collapseLine)) : 0;
        const cEst = Lq > 0 ? +((elim + inAtk - myAtkBefore + fee) / Math.max(1, Lq - collapseLine + 0.25 * collapseLine)).toFixed(1) : 2.0;
        const ring1Def = Lq > 0 ? iV(cnt * Bq, 1 + iV(10 * Lq, 16)) : 0;
        const ring1Cost = cnt * 2 + 2 * ring1Def + inAtk;
        const expectedPx = d_q > 0 ? Math.max(0, Math.round((sent - inAtk) / (2 + 3.2 * d_q))) : Math.round(sent / 2);
        actionLog.push({
          t: g.t, type: 'attack', actor: player, target,
          targetKind: target >= 512 ? 'NEUTRAL' : target >= H ? `bot#${target}` : `HUMAN#${target}`,
          pct, sharePct: +((sent / Math.max(1, B_before)) * 100).toFixed(2),
          sent, fee,
          L: L_before, B: B_before, d: +d_p.toFixed(1), dAfter: +((B_before - sent - fee) / Math.max(1, L_before)).toFixed(1),
          dMed: +dMed.toFixed(1), box: box_p,
          Lq, Bq, dq: +d_q.toFixed(1), peakQ, boxQ: box_q,
          cnt, steps: Lq > 0 && cnt > 0 ? Math.round((0.75 * Lq) / cnt) : 0,
          humanNbCount: humanNbs.length, humanNbs,
          inAtk, myAtkBefore, otherAtkOnTarget, outOtherTarget,
          cEst, worth, ring1Cost, expectedPx
        });
      }
    } else if (id === 3) {
      const pct = dX, water = dZ >> 3, dir = dZ & 7;
      const B_before = g.bal[player], L_before = g.terr[player];
      const box_p = [g.x0[player], g.y0[player], g.x1[player], g.y1[player]];
      const landPix = water + g.dir4[dir];
      const targetOwner = g.px[landPix] >= P_INNER ? g.own[landPix] : NEUTRAL;
      const ok = g.boat(pct, water, dir, player);
      if (ok && player < H) {
        const sent = g.attackTroopsTmp;
        const fee = g.attackFeeTmp;
        const bIdx = g.boatN - 1;
        const route = g.bRoute[bIdx];
        const destPix = route ? route[route.length - 1] + g.dir4[dir] : landPix;
        const destOwner = destPix >= 0 && destPix < g.N ? (g.px[destPix] >= P_INNER ? g.own[destPix] : NEUTRAL) : NEUTRAL;
        actionLog.push({
          t: g.t, type: 'boat', actor: player, target: destOwner,
          targetKind: destOwner >= 512 ? 'NEUTRAL' : destOwner >= H ? `bot#${destOwner}` : `HUMAN#${destOwner}`,
          pct, sharePct: +((sent / Math.max(1, B_before)) * 100).toFixed(2),
          sent, fee,
          L: L_before, B: B_before, d: +(B_before / Math.max(1, L_before)).toFixed(1),
          dAfter: +((B_before - sent - fee) / Math.max(1, L_before)).toFixed(1),
          box: box_p,
          Lq: destOwner < 512 ? g.terr[destOwner] : 0,
          Bq: destOwner < 512 ? g.bal[destOwner] : 0,
          dq: destOwner < 512 && g.terr[destOwner] > 0 ? +(g.bal[destOwner] / g.terr[destOwner]).toFixed(1) : 0,
          routeLen: route ? route.length : 0,
          destCoords: [destPix % g.W, Math.floor(destPix / g.W)]
        });
      }
    } else if (id === 4) {
      if (dX === 849) g.recall(dZ, player);
      else g.chase(dX, dZ, player);
    } else if (id === 5) {
      if (dX !== 513) {
        const ok = g.retreat(dX, player);
        if (ok && player < H) {
          actionLog.push({ t: g.t, type: 'retreat', actor: player, target: dX, L: g.terr[player], B: g.bal[player] });
        }
      }
    } else if (id === 8 || id === 9) {
      if (g.spawnPhase) {
        g.eliminate(player);
        let n = g.aliveCount;
        for (let i = n - 1; i >= 0; i--) if (g.alive[g.aliveList[i]] === 0) g.aliveList[i] = g.aliveList[--n];
        g.aliveCount = n;
        if (player < H) deathT[player] = 0;
      } else {
        if (player < H && leftT[player] < 0) leftT[player] = g.t;
        g.leave(player);
      }
    }
  };

  const jH = () => {
    if (iv >= d.ja.length) return false;
    const jZ = d.ja[iv];
    if (d.jY[iv]) {
      for (let a1 = iw; a1 < iw + jZ; a1++) execCmd(d.cmds[a1]);
      iw += jZ;
      iv++;
    } else {
      if (++ix >= jZ) { iv++; ix = 0; }
    }
    return true;
  };

  if (vu.selectableSpawn) {
    while (iy <= jJ) {
      if (!jH()) break;
      if (iy === jJ) g.endSpawnPhase();
      iy++;
    }
  }

  const recordSnap = () => {
    const arr = new Array(H);
    for (let p = 0; p < H; p++) {
      arr[p] = [g.terr[p], g.bal[p], g.alive[p], [g.x0[p], g.y0[p], g.x1[p], g.y1[p]]];
    }
    snapshots.set(g.t, arr);
  };
  recordSnap();

  while (!g.over && jH()) {
    g.tick();
    for (let p = 0; p < H; p++) {
      if (deathT[p] < 0 && g.alive[p] === 0) deathT[p] = g.t;
    }
    if (g.t % 10 === 0) recordSnap();
  }
  recordSnap();

  for (const act of actionLog) {
    if (act.type === 'retreat') continue;
    const t50 = Math.min(g.t, Math.ceil((act.t + 50) / 10) * 10);
    const t200 = Math.min(g.t, Math.ceil((act.t + 200) / 10) * 10);
    const s50 = snapshots.get(t50) || snapshots.get(g.t);
    const s200 = snapshots.get(t200) || snapshots.get(g.t);
    if (s50 && s50[act.actor]) {
      act.dL50 = s50[act.actor][0] - act.L;
      act.dB50 = s50[act.actor][1] - act.B;
    }
    if (s200 && s200[act.actor]) {
      act.dL200 = s200[act.actor][0] - act.L;
      act.dB200 = s200[act.actor][1] - act.B;
    }
    if (act.target < H && s50 && s50[act.target]) {
      act.targetDL50 = s50[act.target][0] - act.Lq;
    }
    if (act.target < H && s200 && s200[act.target]) {
      act.targetDL200 = s200[act.target][0] - act.Lq;
    }
  }

  const order = [...Array(H).keys()].sort((a, b) => {
    const da = deathT[a] < 0 ? 1e9 + g.terr[a] : deathT[a];
    const db = deathT[b] < 0 ? 1e9 + g.terr[b] : deathT[b];
    return db - da;
  });
  const winner = order[0];
  const myPlace = order.indexOf(me) + 1;

  return {
    game: gameId,
    strategy: stratTag,
    map: `${mapIdx}_${mapSeed}`,
    mapDim: `${g.W}x${g.H}`,
    land: g.land,
    humans: H,
    battleRoyaleMode: vu.battleRoyaleMode,
    endTick: g.t,
    me,
    myPlace,
    myPeak: g.peak[me],
    myEndTerr: g.terr[me],
    myDeathT: deathT[me],
    myLeftT: leftT[me],
    winner,
    winnerPeak: g.peak[winner],
    winnerEndTerr: g.terr[winner],
    top3: order.slice(0, 3),
    order,
    deathT: Array.from(deathT),
    leftT: Array.from(leftT),
    peak: Array.from(g.peak.subarray(0, H)),
    actionCount: actionLog.length,
    myActions: actionLog.filter(a => a.actor === me),
    winnerActions: actionLog.filter(a => a.actor === winner),
    actionsOnMe: actionLog.filter(a => a.target === me),
    actionsOnWinner: actionLog.filter(a => a.target === winner),
    allHumanVsHumanActions: actionLog.filter(a => a.target < H && a.t >= 1200),
  };
}

if (import.meta.url === `file://${process.argv[1]}`) {
  const args = process.argv.slice(2);
  let outPath = null;
  const games = [];
  for (let i = 0; i < args.length; i++) {
    if (args[i] === '--out' && args[i + 1]) {
      outPath = args[++i];
    } else {
      games.push(args[i]);
    }
  }
  const results = {};
  for (const id of games) {
    const cleanId = id.replace(/\.txt$/, '');
    const p = fs.existsSync(id) ? id : path.join(SIM_ROOT, 'results/tsb/replays', `${cleanId}.txt`);
    if (!fs.existsSync(p)) {
      console.error(`Replay not found: ${p}`);
      continue;
    }
    const t0 = Date.now();
    const res = simulateAndDissect(cleanId, p, 'file:v33');
    results[cleanId] = res;
    console.log(`${cleanId}: H=${res.humans}, me=#${res.me} humanPlace=${res.myPlace}/${res.humans} peak=${res.myPeak} endTerr=${res.myEndTerr} deathT=${res.myDeathT}, winner=#${res.winner} peak=${res.winnerPeak} endTerr=${res.winnerEndTerr}, myActs=${res.myActions.length}, onMe=${res.actionsOnMe.length} (${Date.now() - t0}ms)`);
  }
  if (outPath) {
    fs.writeFileSync(outPath, JSON.stringify(results, null, 2));
  }
}
