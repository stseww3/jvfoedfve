// c102 shared pieces for pure-JS live-replay tools (no headless Chrome): the replay-string decoder
// of the live game's share links, a Game builder for a decoded replay, a stepper that applies the
// recorded commands tick by tick, and small helpers. Used by c102-replay-dissect.mjs and
// c102-shadow-attrib.mjs.
import { Game, loadMap, NEUTRAL, P_INNER } from '../sim/index.js';

// --- replay string decoder (format of the live game's share links) ---
export function decodeReplay(raw) {
  let ga = raw.trim();
  const eq = ga.indexOf('=');
  if (eq >= 0) ga = ga.substring(eq + 1);
  ga = ga.replace(/[^a-zA-Z0-9_\-]/g, '-');
  const abv = new Uint8Array(78);
  abv[50] = 37;
  for (let i = 0; i < 10; i++) abv[i + 3] = i + 1;
  for (let i = 0; i < 26; i++) {
    abv[i + 20] = i + 11;
    abv[i + 52] = i + 38;
  }
  const aCT = new Uint8Array(ga.length);
  for (let i = 0; i < ga.length; i++) aCT[i] = abv[ga.charCodeAt(i) - 45];
  const mH = new Uint8Array((6 * aCT.length + 7) >> 3);
  let wp = 0;
  for (let i = 0; i < aCT.length; i++) {
    const v = aCT[i];
    for (let b = 5; b >= 0; b--, wp++) mH[wp >> 3] |= ((v >> b) & 1) << (7 - (wp & 7));
  }
  let a9 = 0;
  const i2 = (size) => {
    let h2 = 0;
    const bz = a9 + size - 1;
    for (let a1 = a9; a1 <= bz; a1++) h2 = (h2 << 1) | ((mH[a1 >> 3] >> (7 - (a1 & 7))) & 1);
    a9 += size;
    return h2 >>> 0;
  };
  const aHl = (aEd) => {
    const len = i2(aEd);
    let s = '';
    for (let i = 0; i < len; i++) s += String.fromCharCode(i2(16));
    return s;
  };
  const aHn = (aEd, aY3, aZd) => {
    const fe = i2(aEd);
    if (!fe) return null;
    const len = Math.max(fe, aZd);
    const dC = new (aY3 <= 8 ? Uint8Array : aY3 <= 16 ? Uint16Array : Uint32Array)(len);
    for (let i = 0; i < fe; i++) dC[i] = i2(aY3);
    if (dC[fe - 1]) dC.fill(dC[fe - 1], fe);
    return dC;
  };
  const aHo = (aEd, aY6, aZd) => {
    const fe = i2(aEd);
    if (!fe) return null;
    const len = Math.max(fe, aZd);
    const dC = new Array(len);
    for (let i = 0; i < fe; i++) dC[i] = aHl(aY6);
    dC.fill(dC[fe - 1], fe);
    return dC;
  };
  i2(12); i2(12); i2(31); // version, vs, stated size
  const vu = {};
  vu.mapType = i2(2);
  vu.mapProceduralIndex = i2(8);
  vu.mapRealisticIndex = i2(8);
  vu.mapSeed = i2(14);
  vu.mapName = aHl(5);
  if (vu.mapType === 2) {
    const aDc = i2(30);
    a9 += 6 * aDc;
  }
  vu.passableWater = i2(1);
  vu.passableMountains = i2(1);
  vu.playerCount = i2(10);
  vu.humanCount = i2(10);
  vu.selectedPlayer = i2(9);
  vu.gameMode = i2(1);
  vu.playerMode = i2(2);
  vu.battleRoyaleMode = i2(2);
  vu.numberTeams = i2(4);
  vu.isZombieMode = i2(1);
  vu.isContest = i2(1);
  vu.isReplay = i2(1);
  vu.elo = aHn(2, 14, 2);
  vu.colorsType = i2(1);
  vu.colorsPersonalized = i2(1);
  vu.colorsData = aHn(10, 18, 512);
  vu.selectableColor = i2(1);
  vu.teamPlayerCount = aHn(4, 10, 9);
  vu.neutralBots = i2(1);
  vu.botDifficultyType = i2(2);
  vu.botDifficultyValue = i2(4);
  vu.botDifficultyTeam = aHn(4, 4, 9);
  vu.botDifficultyData = aHn(10, 4, 512);
  vu.spawningType = i2(2);
  vu.spawningSeed = i2(14);
  vu.spawningData = aHn(11, 12, 1024);
  vu.selectableSpawn = i2(1);
  vu.playerNamesType = i2(2);
  vu.playerNamesData = aHo(10, 5, 512);
  vu.selectableName = i2(1);
  vu.aIncomeType = i2(2); vu.aIncomeValue = i2(8); vu.aIncomeData = aHn(10, 8, 512);
  vu.tIncomeType = i2(2); vu.tIncomeValue = i2(8); vu.tIncomeData = aHn(10, 8, 512);
  vu.iIncomeType = i2(2); vu.iIncomeValue = i2(8); vu.iIncomeData = aHn(10, 8, 512);
  vu.sResourcesType = i2(2); vu.sResourcesValue = i2(11); vu.sResourcesData = aHn(10, 11, 512);
  vu.nA = aHn(10, 30, 0);
  const ek = i2(5), aHp = i2(30), aHq = i2(30);
  const cmds = [];
  for (let i = 0; i < aHp; i++) {
    const id = i2(4), player = i2(9);
    let dX = 0, dZ = 0;
    if (id === 0) dX = i2(22);
    else if (id === 1) { dX = i2(10); dZ = i2(10); }
    else if (id === 2) { dX = i2(10); dZ = i2(9); }
    else if (id === 3) { dX = i2(10); dZ = i2(27); }
    else if (id === 4) { dX = i2(10); dZ = i2(16); }
    else if (id === 5 || id === 6) dX = i2(10);
    else if (id === 7) dX = i2(1);
    else if (id === 10) { dX = i2(20); dZ = i2(22); }
    cmds.push({ id, player, dX, dZ });
  }
  const jY = new Uint8Array(aHq), ja = new Uint32Array(aHq);
  for (let i = 0; i < aHq; i++) {
    jY[i] = i2(1);
    ja[i] = i2(ek);
  }
  return { vu, cmds, jY, ja };
}

// Map index / seed of a decoded replay as the sim's loadMap wants them.
export function mapOf(vu) {
  const mapIdx = vu.mapType === 1
    ? (vu.mapRealisticIndex <= 9 ? 10 + vu.mapRealisticIndex : 12 + vu.mapRealisticIndex)
    : (vu.mapProceduralIndex <= 9 ? vu.mapProceduralIndex : 10 + vu.mapProceduralIndex);
  const mapSeed = vu.mapType === 1 ? 0 : vu.mapSeed;
  return { mapIdx, mapSeed };
}

export function buildGame(vu) {
  const { mapIdx, mapSeed } = mapOf(vu);
  const map = loadMap(mapIdx, mapSeed);
  const H = vu.humanCount;
  const g = new Game({
    map,
    humans: H,
    players: vu.playerCount,
    difficulty: H > 1 ? 0 : vu.botDifficultyValue,
    spawnSeed: vu.spawningSeed,
    selectableSpawn: !!vu.selectableSpawn,
    battleRoyaleMode: vu.battleRoyaleMode,
    humanColors: vu.colorsData ? Array.from(vu.colorsData.subarray(0, H)) : [0],
  });
  g.me = vu.selectedPlayer;
  return { g, H, mapIdx, mapSeed };
}

// Owners of the enemy pixels touching p's border, with the number of touching border pixels each.
export function contactMap(g, p) {
  const m = new Map();
  const B = g.border[p];
  if (!B || !g.alive[p]) return m;
  const seen = new Set();
  const d4 = g.dir4, px = g.px, own = g.own;
  for (let i = B.length - 1; i >= 0; i--) {
    const b = B[i];
    for (let k = 0; k < 4; k++) {
      const c = b + d4[k];
      if (seen.has(c)) continue;
      if (px[c] >= P_INNER && own[c] !== p) {
        seen.add(c);
        m.set(own[c], (m.get(own[c]) || 0) + 1);
      }
    }
  }
  return m;
}

export const kind = (H, q) => (q >= 512 ? 'NEUTRAL' : q >= H ? `bot#${q}` : `H#${q}`);

// A stepper that applies the recorded commands of one replay to g, tick by tick.
// `opts.skipPlayer`: do not apply the commands of that player (counterfactual runs; may be set later);
// `opts.onCmd(c, ok, info)`: called for every applied attack/boat of a human with the
// pre-command balance/land and the engine's troops/fee.
export function makeStepper(d, g, H, opts = {}) {
  const deathT = new Int32Array(H).fill(-1);
  let iv = 0, iw = 0, ix = 0, iy = 0;
  // `opts.skipPlayer` is read per command so a caller may switch it on mid-game (counterfactual runs)
  const execCmd = (c) => {
    const { id, player, dX, dZ } = c;
    if (player === (opts.skipPlayer ?? -1) && id !== 0 && id !== 8 && id !== 9) return;
    if (id === 0) {
      g.chooseSpawn(dX % g.W, Math.floor(dX / g.W), player, false);
    } else if (id === 1) {
      const target = dZ;
      const B0 = g.bal[player], L0 = g.terr[player];
      const inAtk = target < 512 ? g.attackTroopsOn(target, player) : 0;
      const cnt = player < H && opts.onCmd ? (contactMap(g, player).get(target) ?? 0) : -1;
      const ok = g.attack(dX, target, player);
      if (opts.onCmd && player < H) opts.onCmd(c, ok, { t: g.t, type: 'attack', actor: player, target, pct: dX, B0, L0, cnt, inAtk,
        sent: ok ? g.attackTroopsTmp : 0, fee: ok ? g.attackFeeTmp : 0 });
    } else if (id === 3) {
      const B0 = g.bal[player], L0 = g.terr[player];
      const water = dZ >> 3, dir = dZ & 7;
      const ok = g.boat(dX, water, dir, player);
      if (opts.onCmd && player < H) {
        const route = ok ? g.bRoute[g.boatN - 1] : null;
        const dest = route ? route[route.length - 1] + g.dir4[dir] : water + g.dir4[dir];
        const owner = dest >= 0 && dest < g.N ? (g.px[dest] >= P_INNER ? g.own[dest] : NEUTRAL) : NEUTRAL;
        opts.onCmd(c, ok, { t: g.t, type: 'boat', actor: player, target: owner, pct: dX, B0, L0, water, dir, routeLen: route ? route.length : 0,
          sent: ok ? g.attackTroopsTmp : 0, fee: ok ? g.attackFeeTmp : 0 });
      }
    } else if (id === 4) {
      if (dX === 849) g.recall(dZ, player);
      else g.chase(dX, dZ, player);
    } else if (id === 5) {
      if (dX !== 513) g.retreat(dX, player);
    } else if (id === 8 || id === 9) {
      if (g.spawnPhase) {
        g.eliminate(player);
        let n = g.aliveCount;
        for (let i = n - 1; i >= 0; i--) if (g.alive[g.aliveList[i]] === 0) g.aliveList[i] = g.aliveList[--n];
        g.aliveCount = n;
        if (player < H) deathT[player] = 0;
      } else g.leave(player);
    }
  };

  // applies the commands of the current tick; false once the recording is exhausted
  const step = () => {
    if (iv >= d.ja.length) return false;
    const jZ = d.ja[iv];
    if (d.jY[iv]) {
      for (let a1 = iw; a1 < iw + jZ; a1++) execCmd(d.cmds[a1]);
      iw += jZ;
      iv++;
    } else if (++ix >= jZ) {
      iv++;
      ix = 0;
    }
    return true;
  };

  const runSpawnPhase = () => {
    if (!d.vu.selectableSpawn) return;
    const jJ = H <= 2 ? 30 : H <= 50 ? 40 : 50;
    while (iy <= jJ) {
      if (!step()) break;
      if (iy === jJ) g.endSpawnPhase();
      iy++;
    }
  };

  const noteDeaths = () => {
    for (let p = 0; p < H; p++) if (deathT[p] < 0 && g.alive[p] === 0) deathT[p] = g.t;
  };

  return { step, runSpawnPhase, noteDeaths, deathT };
}
