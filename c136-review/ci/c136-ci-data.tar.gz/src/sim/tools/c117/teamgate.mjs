#!/usr/bin/env node
// Team-game gate: a squad of our bots on one team against other teams of
// people (model strategies) and the room's AI bots, on the simulator's team
// mode (sim/game.js setupTeams/donate, bots.js botAttackTeam).
//
// Every game: humans = squad + (teams - 1) x per; the squad holds seats
// 0..size-1 on team 1, the other people are dealt to teams 2..teams in
// blocks; the AI bots join teams round robin as in the live game. All people
// pick a spawn in seat order (the squad with its own chooseSpawn), then the
// game runs to a team victory or --ticks.
//
// Reported per game: whether the squad's team won (team victory, or 96% of
// the land at the end), the team's land share at t700/1500/3000/4500/6000
// and its peak, the team's rank among the teams, squad bots alive at the end
// and when they died, hollow snapshots (a squad bot with >= 1000 land and
// under 15 troops per pixel, sampled every 50 ticks: the c116 V7 frontline
// density failure), the squad's donations (count, troops received, fee
// burnt), boats and commands.
//
// node tools/c117/teamgate.mjs [--squad FILE | --squad-policy v27] [--squad-params JSON]
//   [--squad-size 8] [--teams 6] [--per 8] [--others v27] [--diff 0]
//   [--maps 10_0,11_0,...] [--seeds 1-4] [--ticks 8000] [--workers N]
//   [--json OUT.jsonl] [--label NAME] [--quiet]
// A FILE is a live strategy file (strategy/pool/vN-live.js or the squad's
// tsb/squad/v27-team-live.js): compiled as the page does (its imports of
// ../../sim/index.js and ../../sim/map.js become the simulator's exports),
// with a bare `window` object so its guarded browser hooks stay off.
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { Worker, isMainThread, parentPort, workerData } from 'node:worker_threads';
import * as SIM from '../../sim/index.js';
import * as MAP from '../../sim/map.js';
import { getMap, makePolicy } from '../../strategy/run.js';

const { Game, NEUTRAL } = SIM;
const WIN_SHARE = 0.96;
const CHECKPOINTS = [700, 1500, 3000, 4500, 6000];
const HOLLOW_EVERY = 50;
const HOLLOW_MIN_LAND = 1000;
const HOLLOW_DENSITY = 15;

// ---- CLI ---------------------------------------------------------------------

export function parseArgs(argv) {
  const opt = (k, d) => (argv.includes(`--${k}`) ? argv[argv.indexOf(`--${k}`) + 1] : d);
  const has = (k) => argv.includes(`--${k}`);
  const range = (s) => {
    const out = [];
    for (const part of String(s).split(',')) {
      const m = part.match(/^(\d+)-(\d+)$/);
      if (m) for (let i = +m[1]; i <= +m[2]; i++) out.push(i);
      else if (part !== '') out.push(+part);
    }
    return out;
  };
  const squad = opt('squad', null);
  const squadPolicy = opt('squad-policy', squad ? null : 'v27');
  return {
    squad: squad ? path.resolve(squad) : null,
    squadPolicy,
    squadParams: JSON.parse(opt('squad-params', '{}')),
    squadSize: +opt('squad-size', 8),
    teams: +opt('teams', 6),
    per: +opt('per', 8),
    others: opt('others', 'v27').split(','),
    diff: +opt('diff', 0),
    maps: opt('maps', '10_0,11_0,12_0,13_0,16_0,18_0,22_0,23_0,24_0').split(','),
    seeds: range(opt('seeds', '1-4')),
    ticks: +opt('ticks', 8000),
    workers: +opt('workers', Math.max(1, Math.min(os.cpus().length - 1, 8))),
    json: opt('json', null),
    label: opt('label', squad ? path.basename(squad, '.js') : squadPolicy),
    quiet: has('quiet'),
  };
}

// ---- the squad's strategy -------------------------------------------------------

const compiled = new Map();

// A live strategy file compiled like the page's compileStrategy (see
// tools/c50/precheck.mjs), returning its Policy class.
export function compileStrategy(file) {
  if (compiled.has(file)) return compiled.get(file);
  const body = fs.readFileSync(file, 'utf8')
    .replace(/^import\s*\{([^}]*)\}\s*from\s*['"]\.\.\/\.\.\/sim\/(index|map)\.js['"];?/gm,
      (_, names, which) => `const {${names}} = ${which === 'index' ? '__tsbSim' : '__tsbMap'};`)
    .replace(/^export\s+(?=(const|let|class|function)\s)/gm, '');
  if (/^\s*(import|export)\b/m.test(body)) throw new Error(`${file}: imports or exports something besides ../../sim/index.js and ../../sim/map.js`);
  if (!/^class Policy\b/m.test(body)) throw new Error(`${file}: no class Policy`);
  if (typeof globalThis.window === 'undefined') globalThis.window = {};
  // eslint-disable-next-line no-new-func
  const Policy = new Function('__tsbSim', '__tsbMap', `${body}\nreturn Policy;`)({ ...SIM }, { ...MAP });
  compiled.set(file, Policy);
  return Policy;
}

function squadPolicyOf(job, me) {
  const params = { spawnRoll: 0, planEvery: 0, ...job.squadParams };
  if (job.squad) return new (compileStrategy(job.squad))(params, me);
  return makePolicy({ policy: job.squadPolicy, ...params }, me);
}

// ---- one game --------------------------------------------------------------------

export function playGame(job) {
  const [mi, ms] = job.mapKey.split('_').map(Number);
  const map = getMap(mi, ms);
  const size = job.squadSize, nTeams = job.teams, per = job.per;
  const humans = size + (nTeams - 1) * per;
  const teams = new Array(humans);
  for (let h = 0; h < humans; h++) teams[h] = h < size ? 1 : 2 + Math.floor((h - size) / per);
  const g = new Game({ map, difficulty: job.diff, spawnSeed: job.seed, selectableSpawn: true, humans, teams, nTeams });
  const pols = new Array(humans);
  for (let h = 0; h < humans; h++) {
    pols[h] = h < size ? squadPolicyOf(job, h) : makePolicy({ policy: job.others[(h - size) % job.others.length], spawnRoll: 0, planEvery: 0 }, h);
  }
  const t0 = Date.now();
  if (g.spawnPhase) {
    for (let h = 0; h < humans; h++) {
      let s = null;
      try {
        s = pols[h].chooseSpawn ? pols[h].chooseSpawn(g, true) : null;
      } catch (e) {
        s = null;
      }
      if (s) g.chooseSpawn(s.x, s.y, h, false);
    }
    g.endSpawnPhase();
  }
  const squadLand = () => {
    let s = 0;
    for (let h = 0; h < size; h++) if (g.alive[h]) s += g.terr[h];
    return s;
  };
  const teamRank = () => {
    const lands = g.teamLands();
    let r = 1;
    for (let t = 2; t <= nTeams; t++) if (lands[t] > lands[1]) r++;
    return r;
  };
  const at = {};
  let peak = 0, peakAt = 0, hollow = 0, win = false, winT = -1;
  const died = new Array(size).fill(-1);
  const errors = [];
  const stopped = new Array(size).fill(false);
  const cmdsBefore = pols.slice(0, size).map((p) => p.cmds | 0);
  let boats = 0, lastBoats = 0;
  while (!g.over && g.t < job.ticks) {
    for (let h = 0; h < humans; h++) {
      if (!g.isAlive(h)) continue;
      if (h < size && stopped[h]) continue;
      try {
        pols[h].act(g);
      } catch (e) {
        // the page stops a bot that throws (StrategyBot.fail); the others
        // play on
        if (h < size) {
          stopped[h] = true;
          errors.push({ t: g.t, bot: h, message: String(e.message || e).slice(0, 200) });
        }
      }
    }
    g.tick();
    const L = squadLand();
    const share = L / g.land;
    if (share > peak) {
      peak = share;
      peakAt = g.t;
    }
    if (CHECKPOINTS.includes(g.t)) at[g.t] = { share: +share.toFixed(4), rank: teamRank(), alive: g.aliveCount };
    if (g.t % HOLLOW_EVERY === 0) {
      for (let h = 0; h < size; h++) {
        if (g.alive[h] && g.terr[h] >= HOLLOW_MIN_LAND && g.bal[h] < HOLLOW_DENSITY * g.terr[h]) hollow++;
      }
    }
    for (let h = 0; h < size; h++) if (died[h] < 0 && !g.alive[h]) died[h] = g.t;
    let nb = 0;
    for (let h = 0; h < size; h++) nb += g.boatCount[h];
    if (nb > lastBoats) boats += nb - lastBoats;
    lastBoats = nb;
    if (share >= WIN_SHARE) {
      win = true;
      winT = g.t;
      break;
    }
  }
  if (!win && g.over && g.winnerTeam === 1) {
    win = true;
    winT = g.t;
  }
  let totalDon = 0, given = 0, fee = 0;
  for (let h = 0; h < size; h++) {
    totalDon += g.donations[h];
    given += g.donGiven[h];
    fee += g.donFee[h];
  }
  const lands = g.teamLands();
  let bestOther = 0;
  for (let t = 2; t <= nTeams; t++) if (lands[t] > bestOther) bestOther = lands[t];
  return {
    label: job.label,
    map: job.mapKey,
    seed: job.seed,
    teams: nTeams,
    humans,
    diff: job.diff,
    win,
    winT,
    t: g.t,
    share: +(squadLand() / g.land).toFixed(4),
    bestOther: +(bestOther / g.land).toFixed(4),
    rank: teamRank(),
    peak: +peak.toFixed(4),
    peakAt,
    at,
    alive: died.filter((d) => d < 0).length,
    died,
    hollow,
    donations: totalDon,
    donGiven: Math.round(given),
    donFee: Math.round(fee),
    boats,
    cmds: pols.slice(0, size).reduce((s, p, i) => s + ((p.cmds | 0) - cmdsBefore[i]), 0),
    errors,
    ms: Date.now() - t0,
  };
}

// ---- report ------------------------------------------------------------------------

const mean = (a) => (a.length ? a.reduce((s, x) => s + x, 0) / a.length : 0);
const pct = (x) => `${(100 * x).toFixed(1)}%`;

// Wilson 95% interval of k wins in n games.
function wilson(k, n) {
  if (!n) return [0, 0];
  const z = 1.96, p = k / n, d = 1 + (z * z) / n;
  const c = (p + (z * z) / (2 * n)) / d;
  const h = (z * Math.sqrt((p * (1 - p)) / n + (z * z) / (4 * n * n))) / d;
  return [Math.max(0, c - h), Math.min(1, c + h)];
}

export function report(results, opts) {
  const ok = results.filter((r) => !r.harnessError);
  const wins = ok.filter((r) => r.win).length;
  const [lo, hi] = wilson(wins, ok.length);
  const lines = [];
  lines.push(`teamgate ${opts.label}: ${ok.length} games (${opts.maps.length} maps x ${opts.seeds.length} seeds), ${opts.teams} teams, squad ${opts.squadSize} vs ${opts.per} ${opts.others.join('/')} per team, bots diff ${opts.diff}, t <= ${opts.ticks}`);
  lines.push(`  team wins: ${wins}/${ok.length} = ${pct(wins / Math.max(ok.length, 1))} (95% ${pct(lo)}..${pct(hi)})`);
  lines.push(`  team share: ${CHECKPOINTS.map((t) => `t${t} ${pct(mean(ok.filter((r) => r.at[t]).map((r) => r.at[t].share)))}`).join(', ')}, peak ${pct(mean(ok.map((r) => r.peak)))} @t${Math.round(mean(ok.map((r) => r.peakAt)))}, end ${pct(mean(ok.map((r) => r.share)))}`);
  lines.push(`  team rank: ${CHECKPOINTS.map((t) => `t${t} ${mean(ok.filter((r) => r.at[t]).map((r) => r.at[t].rank)).toFixed(2)}`).join(', ')}, end ${mean(ok.map((r) => r.rank)).toFixed(2)}; #1 at t3000 then lost: ${ok.filter((r) => r.at[3000] && r.at[3000].rank === 1 && !r.win).length}`);
  lines.push(`  squad alive at the end: ${mean(ok.map((r) => r.alive)).toFixed(2)}/${opts.squadSize}; hollow snapshots (>= ${HOLLOW_MIN_LAND} land, < ${HOLLOW_DENSITY}/px, every ${HOLLOW_EVERY}t): ${mean(ok.map((r) => r.hollow)).toFixed(1)} per game`);
  const given = mean(ok.map((r) => r.donGiven)), fee = mean(ok.map((r) => r.donFee));
  lines.push(`  donations ${mean(ok.map((r) => r.donations)).toFixed(1)} per game (${Math.round(given)} troops handed over, ${Math.round(fee)} burnt as fee = ${given + fee > 0 ? pct(fee / (given + fee)) : '-'} loss), boats ${mean(ok.map((r) => r.boats)).toFixed(1)}, commands ${mean(ok.map((r) => r.cmds)).toFixed(0)}; ${mean(ok.map((r) => r.ms / 1000)).toFixed(1)} s per game`);
  const errs = ok.flatMap((r) => r.errors.map((e) => `${r.map}/${r.seed} t${e.t} bot ${e.bot}: ${e.message}`));
  if (errs.length) {
    lines.push(`  strategy exceptions (the bot stops for the game): ${errs.length}`);
    for (const e of errs.slice(0, 8)) lines.push(`    ${e}`);
  }
  const bad = results.filter((r) => r.harnessError);
  if (bad.length) {
    lines.push(`  harness errors: ${bad.length}`);
    for (const r of bad.slice(0, 5)) lines.push(`    ${r.map}/${r.seed}: ${r.harnessError}`);
  }
  lines.push('  per game: ' + ok.map((r) => `${r.map}/${r.seed} ${r.win ? 'W' : 'L'}${r.rank} ${pct(r.share)}`).join(' | '));
  return lines.join('\n');
}

// ---- main / workers -----------------------------------------------------------------

async function main() {
  const opts = parseArgs(process.argv.slice(2));
  if (opts.squad) compileStrategy(opts.squad);
  const jobs = [];
  for (const mapKey of opts.maps) for (const seed of opts.seeds) {
    jobs.push({ squad: opts.squad, squadPolicy: opts.squadPolicy, squadParams: opts.squadParams, squadSize: opts.squadSize, teams: opts.teams, per: opts.per, others: opts.others, diff: opts.diff, mapKey, seed, ticks: opts.ticks, label: opts.label });
  }
  const results = new Array(jobs.length);
  let next = 0;
  const self = fileURLToPath(import.meta.url);
  const started = Date.now();
  await Promise.all(Array.from({ length: Math.max(1, Math.min(opts.workers, jobs.length)) }, () => new Promise((resolve, reject) => {
    const w = new Worker(self, { workerData: { worker: true } });
    const feed = () => {
      if (next >= jobs.length) {
        w.terminate().then(resolve);
        return;
      }
      const i = next++;
      w.postMessage({ i, job: jobs[i] });
    };
    w.on('message', (m) => {
      results[m.i] = m.res;
      const r = m.res;
      if (!opts.quiet) process.stderr.write(`  ${r.map} seed ${r.seed}: ${r.harnessError ? `HARNESS ${r.harnessError}` : `${r.win ? 'WIN' : 'loss'} rank ${r.rank} share ${pct(r.share)} peak ${pct(r.peak)}@${r.peakAt} alive ${r.alive} hollow ${r.hollow} don ${r.donations}${r.errors.length ? ` EXC ${r.errors.length}` : ''}`} (${(r.ms / 1000).toFixed(1)} s)\n`);
      feed();
    });
    w.on('error', reject);
    feed();
  })));
  const text = report(results, opts);
  console.log(text);
  console.log(`  wall ${((Date.now() - started) / 1000).toFixed(0)} s with ${opts.workers} workers`);
  if (opts.json) {
    fs.mkdirSync(path.dirname(path.resolve(opts.json)), { recursive: true });
    fs.writeFileSync(opts.json, results.map((r) => JSON.stringify(r)).join('\n') + '\n');
  }
}

if (isMainThread) {
  main().catch((e) => {
    console.error(e);
    process.exit(1);
  });
} else if (workerData && workerData.worker) {
  parentPort.on('message', ({ i, job }) => {
    let res;
    try {
      res = playGame(job);
    } catch (e) {
      res = { label: job.label, map: job.mapKey, seed: job.seed, win: false, rank: -1, share: 0, peak: 0, peakAt: 0, at: {}, alive: 0, died: [], hollow: 0, donations: 0, boats: 0, cmds: 0, errors: [], ms: 0, harnessError: `${e.message} ${String(e.stack).split('\n')[1] || ''}`.trim() };
    }
    parentPort.postMessage({ i, res });
  });
}
