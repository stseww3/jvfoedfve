const SQUAD_POOL_SET = new Set(["404 not found", "abbasid", "abyssinia", "aceh", "achaemenid", "admin", "afk", "afsharid", "ainz", "aizen", "akbar", "aksum", "akuma", "alaska", "alexander", "algiers", "almohad", "almoravid", "alonso", "alpha", "alphazero", "altf4", "alucard", "amogus", "andalusia", "angkor", "anon_42", "anya", "aragon", "archdukecharles", "area51", "argentina", "armenia", "arthurmorgan", "ashanti", "ashikaga", "ashoka", "askeladd", "assyria", "astrakhan", "augustus", "aurangzeb", "aurelian", "austria-hungary", "ayutthaya", "ayyubid", "aztec", "babylon", "baden", "baekje", "bagrationi", "baguette", "banana", "barbary", "based", "batman", "bavaria", "belgium", "belisarius", "bellingham", "bengal", "benin", "bhutan", "bigbrain", "bigsmoke", "bismarck", "bitcoin", "blackrock", "blucher", "bluescreen", "boer", "bohemia", "bolivar", "bongcloud", "boomer", "borsch", "bosnia", "bourbon", "bowser", "brabant", "brandenburg", "brazil", "british empire", "brittany", "broly", "bruh", "brunei", "bukhara", "bulgar", "burgerking", "burgundy", "byzantium", "caesar", "california", "cao cao", "capablanca", "carinthia", "carolus rex", "carthage", "cascadia", "castile", "casualplayer", "catalonia", "cataphract", "celtic", "centurion", "ceylon", "chad", "chagatai", "chainsawman", "champa", "charizard", "charlemagne", "cheems", "cheese", "chicago", "chile", "chola", "chosokabe", "chunli", "cia", "cj", "clausewitz", "cleopatra", "cloud", "cnut", "cocacola", "conde", "conquistador", "constantine", "corsica", "cossack", "courland", "creeper", "crimea", "cringe", "cristiano", "croatia", "croissant", "csa", "ctrlaltdel", "cuba", "cuirassier", "cumania", "curry", "cyberninja", "cyrenaica", "cyrus", "dahomey", "dai viet", "darius", "darkknight", "darthvader", "date masamune", "davout", "deadpool", "deepblue", "demonhunter", "denji", "denmark", "deruyter", "desertfox", "diamondhands", "diobrando", "ditto", "dixie", "doge", "dogecoin", "don", "doncic", "donitz", "donjuan", "doomer", "doomslayer", "dragonslayer", "dragoon", "dream", "drpepper", "dusan", "dutch republic", "dzungar", "east india co", "eisenhower", "enderman", "enpassant", "erenyeager", "error404", "erwin", "estonia", "ethereum", "ethiopia", "eugene", "ez_clap", "ezo", "farnese", "fatimid", "fbi_openup", "fedreserve", "fern", "ff15", "finland", "firelord", "first bulgarian", "first empire", "fischer", "flanders", "florence", "florida man", "frankia", "frederick", "freemason", "frieren", "frieza", "frisia", "galaxybrain", "ganondorf", "garibaldi", "garlicbread", "garou", "gaul", "gengar", "genoa", "genos", "georgia", "geralt", "german empire", "gg_wp", "ghana", "ghostrider", "giga_chad", "giorno", "gitgud", "gladiator", "goguryeo", "gojo", "goku", "golden horde", "gordonfreeman", "goryeo", "gran colombia", "greenland", "griffith", "guderian", "guest_104", "gupta", "gurkha", "gustavofring", "gustavus", "guts", "haaland", "habsburg", "hafsid", "halsey", "hamilton", "han", "hannibal", "hanover", "harald", "hashashin", "heian", "heihachi", "heisenberg", "helvetia", "herobrine", "hesse", "hetmanate", "highlander", "highping", "hikaru", "himmel", "hittite", "hodl", "hojo", "holy roman", "homelander", "hospitalier", "hungary", "hussite", "iberia", "iceking", "iceland", "ichigo", "illuminati", "impostor", "inca", "inosuke", "interpol", "ireland", "ironman", "irs", "ishowspeed", "itachi", "janissary", "jessepinkman", "jin", "jinkazama", "johnmarston", "joker", "jokic", "jordan", "joseon", "jotaro", "jurchen", "justinian", "kaicenat", "kaido", "kaiser", "kakashi", "kalmar union", "kamakura", "kamchatka", "kandy", "kanem-bornu", "kasparov", "kazakh", "kazan", "kazuya", "kebabremover", "ken", "kfc", "kgb", "khazar", "khiva", "khmer", "khosrow", "kievan rus", "kilwa", "king", "kirayoshikage", "kirby", "kobe", "kokand", "konbaung", "konev", "kongo", "kratos", "kuban", "kublai", "kuku", "kutuzov", "l_lawliet", "lagswitch", "lan xang", "landsknecht", "lannes", "latvia", "lebron", "leclerc", "legionnaire", "leif erikson", "lelouch", "leonidas", "levi", "lewandowski", "liao", "lightyagami", "link", "lithuania", "liu bei", "liukang", "livonian", "llxrscorpio", "loid", "lombardy", "londonsystem", "lowfps", "lu bu", "lucario", "luffy", "luigi", "lukeskywalker", "lusitania", "luxembourg", "lydia", "macarthur", "macedon", "madagascar", "madara", "magikarp", "magnuscarlsen", "magyar", "majapahit", "makima", "malacca", "mali", "mamluk", "mamlukguard", "manchu", "mandalorian", "mansa musa", "manstein", "maple leaf", "maradona", "maratha", "mario", "markiplier", "marlborough", "massena", "masterchief", "mataram", "matthias", "maurice", "maurya", "maxverstappen", "maya", "mbappe", "mcdonalds", "medici", "meiji", "merina", "messi", "mewtwo", "mexican", "mi6", "mikasa", "mindaugas", "ming", "mithridates", "mobileplayer", "modric", "moldavia", "moltke", "mongol horde", "monsterenergy", "montgomery", "moravia", "mori", "morocco", "morphy", "mossad", "mrbeast", "mughal", "murat", "musashi", "muscovy", "musketeer", "mutapa", "muzan", "mysore", "nader shah", "napol\u00e9on", "naruto", "nelson", "nepal", "netherlands", "new england", "new york", "ney", "neymar", "nightstalker", "nimitz", "nogai", "nolife", "noobslayer", "normandy", "north sea", "norway", "novgorod", "nullpointer", "obiwan", "oda nobunaga", "ohio", "oirat", "oldguard", "omniman", "orange", "oranje", "ottoman", "oyo", "pagan", "palatinate", "palmyra", "panama", "panzergrenadier", "papal states", "parthia", "pastalover", "patagonia", "patton", "pcmasterrace", "pecheneg", "pele", "pepe", "pepsi", "peru", "pewdiepie", "pharaoh", "phoenicia", "pikachu", "pineapple", "ping999", "pizzatime", "player_007", "polish-lithuanian", "polska gurom", "pomerania", "pontus", "portugal", "potato", "praetorian", "progamer99", "prussia", "ptolemy", "pyrrhus", "qin", "qing dynasty", "quebec", "raeder", "ragnar", "raiden", "rajput", "ramen", "ranjit singh", "rashidun", "rayquaza", "reconquista", "red army", "redbull", "redcoat", "rengoku", "rhineland", "rimuru", "rizzler", "rokossovsky", "roman empire", "rommel", "ronaldinho", "ronin", "root", "rossi", "rule britannia", "rum", "russian empire", "ryu", "ryuk", "ryukyu", "safavid", "saitama", "saladin", "salah", "salzburg", "samurai", "san marino", "sanada", "sanji", "sardinia", "sassanid", "sasuke", "satoshi", "saulgoodman", "savoy", "saxony", "schumacher", "scipio", "scorpion", "scotland", "segfault", "seljuk", "sengoku", "senna", "sephiroth", "serbia", "sever (rus)", "shadowhunter", "shaka", "shanks", "shaq", "shimazu", "shinobi", "shivaji", "shogunate", "siam", "siberia", "sicilian", "sigma", "sikh empire", "silentassassin", "silesia", "silla", "simeon", "simo hayha", "skibidi", "skillissue", "smurfaccount", "sniperwolf", "snorlax", "sokoto", "song", "songhai", "sonheungmin", "soviet union", "spanish empire", "sparta", "spartan", "spiderman", "spike", "spqr", "spruance", "srivijaya", "stackoverflow", "starbucks", "stark", "starlord", "steve", "stockfish", "stonks", "stormbringer", "streltsy", "styria", "subway", "subzero", "sudo_rm_rf", "sukuna", "sulu", "sumer", "sun quan", "suomi", "sus", "sushi", "suvorov", "swabia", "sweaty", "sweden", "swiss guard", "switzerland", "syntaxerror", "system32", "tacobell", "takeda", "tal", "tang", "tanjiro", "taxcollector", "teadrinker", "team destroyer", "technoblade", "templar", "tercios", "teutonic order", "texas", "thanos", "thorfinn", "three kingdoms", "thundergod", "tibet", "tifa", "tigranes", "tilly", "timurid", "tipu sultan", "tito", "togo", "toji", "tokugawa", "tokyoghoul", "tomato", "tondo", "touchgrass", "toungoo", "toyotomi", "trajan", "transvaal", "transylvania", "trevor", "tripoli", "tromp", "tryhard", "tsardom", "tunis", "turenne", "tuscany", "two sicilies", "tyrol", "uesugi", "ulan", "umayyad", "umbreon", "user_8821", "ussr", "uzbek", "vanguard", "varangian", "vasa", "vatican city", "vegeta", "venice", "venom", "vichy", "vijayanagara", "viking", "vinicius", "vinland", "vlad tepes", "voc", "vodka", "voidwalker", "vytautas", "wales", "wallachia", "wallenstein", "wallonia", "wallstreet", "walterwhite", "watermelon", "weimar", "wellington", "wembanyama", "wendy", "westphalia", "white death", "winged hussar", "wojak", "wolverine", "world empire", "wurttemberg", "xerxes", "xia", "xqc", "xx_killer_xx", "xx_shadow_xx", "yamamoto", "yamato", "yi sun-sin", "yisunsin", "yor", "yoshi", "yuan", "yugoslavia", "zanzibar", "zelda", "zenitsu", "zenobia", "zhuge liang", "zhukov", "zidane", "zizka", "zoomer", "zoro", "zouave", "zulu"]);
try {
  if (typeof window === "object") {
    if (window.__bossLobbyWatcher) {
      clearInterval(window.__bossLobbyWatcher);
      window.__bossLobbyWatcher = null;
    }
    if (window.bq?.sH?.__origSelect) {
      window.bq.sH.select = window.bq.sH.__origSelect;
      delete window.bq.sH.__origSelect;
    }
    if (typeof window.be === "object" && window.be) {
      window.be.render = function() {};
      window.be.a7W = function() {};
      window.be.a3K = function() {};
    }
    if (typeof window.nF === "function") window.nF = function() {};
    if (typeof window.a1C === "function") window.a1C = function() {};
    const sb = window.__fx?.strategyBot;
    if (sb && typeof sb.afterTick === "function" && !sb.__fixedInflight450) {
      sb.__fixedInflight450 = true;
      const prevAfterTick = sb.afterTick.bind(sb);
      sb.afterTick = function() {
        const curT = typeof window.bi === "object" && window.bi?.kr ? window.bi.kr() : -1;
        if (this.inflight !== null && performance.now() - this.inflight < 450 && curT >= 0 && curT - (this.inflightTick ?? 0) < 8) {
          this.afterQueued = false;
          return;
        }
        return prevAfterTick();
      };
    }
    if (sb && !sb.__hookedReplayLog) {
      sb.__hookedReplayLog = true;
      const origReplay = sb.replay ? sb.replay.bind(sb) : null;
      sb.replay = function(text) {
        try {
          if (typeof text === "string" && text.length > 100 && window.__tsbReportResult) {
            const cut = text.indexOf("=");
            const pure = (cut >= 0 ? text.slice(cut + 1) : text).trim();
            window.__tsbReportResult(JSON.stringify({ type: "raw_replay", replay: pure }));
          }
        } catch {}
        if (origReplay) return origReplay(text);
      };
    }
  }
} catch {}
// Self-contained strategy v27 (Unified Synthesis of c81 A07 + c80 A06 Safety Clauses over v24, by c58).
// Inlines v17.js (V13 + V17), sea.js (trip/troopsFor), sea-core.js, and v24+A06 fixes into a single file
// with zero external strategy imports, ready for live browser deployment.
import { NEUTRAL, P_INNER, P_BORDER, MAX_PLAYERS, iV } from "../../sim/index.js";
import { T_LAND, T_WATER } from "../../sim/map.js";

// Frozen v17: the core of strategy/pool/v15.js (v13 until coreFrom) with
// {"hold":0.9,"maxW":0.5,"growth":1,"post":1,"seaFree":1}
// v16 with seaFree: a pocket of unowned land counts at its current size for boats when no other player borders it, else not at all; three backtests agree on alive (echo +1.4 +- 0.5, adaptive pool +0.4 +- 0.3, calibrated stand-in +1.4 +- 0.6), first unchanged
// generated by tools/c22/freeze15.mjs. Do not edit; freeze a new version.
//
// The core: v13 until tick coreFrom (early phase by the rent-cycle DP,
// bots by the win value); from then on one rule buys all land, free, bot or
// person, every 5 ticks:
//
//   buy the land with the fewest troops per pixel while that price c is
//   below what a pixel is worth for winning, w = winRatio(t) x B / L (the
//   conditional logit of the winner on log land and log troops in the
//   recorded games, tools/c22/review/winvalue.py; B our troops, L our land),
//   down to the balance at which the two meet (B = c L / winRatio) or the
//   safety floor, whichever is higher.
//
// The price is per pixel to collapse the target: elimCost plus its troops on
// us minus ours on it plus the fee (12/1024 of our balance), over the land
// that falls before the collapse and a contact share of the quarter left
// neutral; free land costs 2.
//
// Safety floor, the highest of: no neighbouring bot finds us its weakest
// neighbour (safeFinite); killW x the balance at which the strongest
// neighbour person could not collapse us with all its troops (dpKeep), or
// with killF > 0 the balance at which no neighbour person collapses us with
// killF x its troops (in the recorded games a person sends at one target in
// 150 ticks, about the length of the wars that kill us, at most 0.61 / 0.43
// of its troops 9 times out of 10 before / after t3000, the median 0.17);
// safeW x the balance at which no neighbour person would find us its weakest
// neighbour person while holding 2.5 x our troops or sitting at its cap
// (peopleSafe; for an attack on person q the people around q count, as they
// border us once q is gone).
//
// Surplus (surplus > 0): from the soft cap (100 x land) on a troop earns
// nothing more (Game.interestRate cuts the rate by 2 (B - cap) / cap) while
// a pixel raises the cap by 100, so the balance above hold x the cap (and
// the safety floor) buys the cheapest land whatever its price.
//
// Growth (growth > 0): land at c per pixel pays its rent (0.1 per 10 ticks)
// faster than the c troops it costs earn interest (r per 10 ticks below the
// cap) when c r < 0.1. Holding b troops a pixel and spending the rest of the
// income on land, land grows by (b r + 0.1) / (b + c) per 10 ticks, whose
// derivative in b has the sign of c r - 0.1: below that price the fewest
// troops grow fastest, so such land is bought down to the safety floor.
//
// Exact log value (post > 0): the win logit is a log L + b log B, so a buy of
// x troops at c is worth a log(1 + x / (c L)) + b log(1 - x / B); its best x
// is (m B - c L) / (1 + m) with m = a / b (= maxW x winRatio), the land
// bought counted. The first-order rule above (B = c L / m) spends
// (1 + m) / m times that on one big buy.
//
// Of the levels the rules allow for an offer (growth: the floor; win value;
// surplus: hold x the cap) the lowest is kept, never under the floor.
//
// floorCap > 0: the floor is at most floorCap x the soft cap. Troops above
// the cap earn less the more there are (to nothing at 1.5 x, the hard cap),
// and a floor above 1.5 x cannot be reached at all.
//
// A send that does not collapse its target carries at least chunk x the
// balance (its fee then at most 6% of it); with pplKill > 0, sends at people
// only when they collapse them. With peerMax > 0 no new attack opens on a
// person holding peerMax x our troops or more unless it collapses them: in
// the recorded games from t2500 a person's first strike at a person with
// 0.6 x its troops or more collapsed the target 28% of the time, a third
// person opened on the attacker within 300 ticks 38% of the time, and the
// attacker's share of the land 1000 ticks later was 12% below that of the
// people its size who opened nothing (16% when the target stood), against
// +12-15% at targets with less (tools/c22/review/peerwar.mjs).
//
// Boats (v13's food over water and idle boats) price unowned land by the
// land a boat can take there. v13 counts the whole land mass the pixel
// belongs to (compSize, the map's terrain), right while no one owns it but
// not once it is taken: in a recorded game at t2750 a boat carried 47% of
// our troops at a 51 pixel pocket because its land mass is 300k pixels,
// found bot8 there 170 ticks later and left us to bot68. With seaFree > 0,
// from coreFrom on a component of unowned land counts at its current size
// when no other player borders it, else not at all (a player bordering it
// takes it by land long before a boat crosses). With seaSafe > 0 boats keep
// the safety floor above too (troops at sea cannot come back to defend).

// main plays without lookahead (spawnRoll 0, planEvery 0)
const spawnByRollout = () => null;
const chooseMode = () => 0;

// Closed-loop single-player strategy. Every decision reads the current game
// state only (no plan carried between steps besides cheap caches), so manual
// interference such as retreats or misdirected attacks is simply absorbed.

const DEFAULT_PARAMS = {
  period: 3,
  spawnRadius: 48,
  spawnSlack: 1,
  spawnCoast: 0.0,
  // neutral expansion: troops held for the next ring, top-up in batches
  nLow: 1,
  nHigh: 4,
  nGrow: 6,
  refN: 1.0,
  // balance floor = max(reserve * soft cap, ref * neighbour balance, safeK * threat-safe balance)
  earlyEnd: 600,
  reserveEarly: 0.0,
  reserve: 1.0,
  refEarly: 1.0,
  ref: 0.0,
  safeK: 0.0,
  keepCap: 1.0,
  // player attacks
  minSend: 0.04,
  maxTargets: 3,
  sendFrac: 1.0,
  elimW: 1.0,
  shareW: 0.5,
  maxCost: 400,
  snipeK: 0.0,
  snipeF: 0.5,
  // grudges: a neighbour that attacked us stays a preferred target (target
  // score x grudgeW) for grudgeT ticks; a leader above leaderShare of the
  // land gets score x leaderW (ganging up); a neighbour someone else is
  // attacking gets score x pileW (piling on whoever is being beaten)
  grudgeW: 1,
  grudgeT: 0,
  leaderW: 1,
  leaderShare: 0.3,
  pileW: 1,
  // every command costs a fee of 12/1024 of the whole balance (boats 32/1024)
  // whatever it sends: a command sends at least feeK x its fee or is skipped
  feeK: 4,
};

// Copy of the game (spawn phase) with player p's spawn taken off the map.
function withoutPlayer(g, p) {
  const px = g.px.slice(), own = g.own.slice(), terr = g.terr.slice();
  const W = g.W, x0 = g.x0[p], x1 = g.x1[p], y0 = g.y0[p], y1 = g.y1[p];
  for (let x = x1; x >= x0; x--) {
    for (let y = y1; y >= y0; y--) {
      const i = y * W + x;
      if (px[i] >= P_INNER && own[i] === p) {
        px[i] = T_LAND;
        own[i] = NEUTRAL;
        terr[p]--;
      }
    }
  }
  terr[p] = 0;
  return {
    W, H: g.H, N: g.N, t: g.t, land: g.land, humans: g.humans, players: g.players,
    dir4: g.dir4, map: g.map, px, own, terr, alive: g.alive,
    x0: g.x0, y0: g.y0, x1: g.x1, y1: g.y1,
    isBot: (o) => o >= g.humans,
    ownedBy: (o, i) => px[i] >= P_INNER && own[i] === o,
  };
}

// Scratch buffers of the spawn search, per map size; dd is kept at -1.
const scratchBufs = new Map();
function scratch(N) {
  let s = scratchBufs.get(N);
  if (!s) {
    s = { dist: new Int32Array(N), q: new Int32Array(N), dd: new Int32Array(N).fill(-1) };
    scratchBufs.set(N, s);
  }
  return s;
}

// The n land pixels of the 2-pixel sampling grid farthest (and at least 4)
// from any player, farthest first, ties in scan order: the head of a stable
// sort of the whole grid, in linear time.
function farthest(dist, W, H, px, n) {
  let maxD = 0;
  for (let y = 5; y < H - 6; y += 2) {
    for (let x = 5; x < W - 6; x += 2) {
      const c = y * W + x;
      if (px[c] === T_LAND && dist[c] > maxD) maxD = dist[c];
    }
  }
  if (maxD < 4) return [];
  const hist = new Int32Array(maxD + 1);
  for (let y = 5; y < H - 6; y += 2) {
    for (let x = 5; x < W - 6; x += 2) {
      const c = y * W + x;
      if (px[c] === T_LAND && dist[c] >= 4) hist[dist[c]]++;
    }
  }
  let cut = maxD, above = 0;
  while (cut > 4 && above + hist[cut] < n) above += hist[cut--];
  let ties = n - above;
  const out = [];
  for (let y = 5; y < H - 6; y += 2) {
    for (let x = 5; x < W - 6; x += 2) {
      const c = y * W + x;
      if (px[c] !== T_LAND) continue;
      const v = dist[c];
      if (v > cut) out.push(c);
      else if (v === cut && ties > 0) {
        out.push(c);
        ties--;
      }
    }
  }
  return out.sort((a, b) => dist[b] - dist[a]);
}

class Strategy {
  constructor(params = {}, me = 0) {
    this.p = { ...DEFAULT_PARAMS, ...params };
    this.me = me;
    this.stamp = 0;
    this.mark = null;
    this.cnt = new Uint32Array(MAX_PLAYERS + 1);
    this.oseen = new Uint32Array(MAX_PLAYERS + 1);
    this.ostamp = 0;
    this.nb = [];
    this.neutral = 0;
    this.threats = 0;
    this.cmds = 0;
    this.grudge = new Map();
  }

  // Decision memory, saved and restored around lookahead rollouts.
  saveMemory() {
    return { grudge: new Map(this.grudge), cmds: this.cmds };
  }

  loadMemory(m) {
    this.grudge = new Map(m.grudge);
    this.cmds = m.cmds;
  }

  // Remember neighbours attacking us (call after analyze).
  updateGrudges(g) {
    if (!this.p.grudgeT) return;
    for (const q of this.nb) if (g.attackTroopsOn(q, this.me) > 0) this.grudge.set(q, g.t + this.p.grudgeT);
  }

  // Multiplier on the target score of q (lower is more attractive).
  targetBias(g, q) {
    const P = this.p;
    let k = 1;
    if (P.grudgeT && (this.grudge.get(q) ?? -1) >= g.t) k *= P.grudgeW;
    if (P.leaderW !== 1 && q === g.rank[0] && g.terr[q] > P.leaderShare * g.land) k *= P.leaderW;
    if (P.pileW !== 1 && this.attackedByOthers(g, q)) k *= P.pileW;
    return k;
  }

  // Whether a person other than us attacks q (per-tick table of all their
  // attacks; bots attack all the time and draw no attention).
  attackedByOthers(g, q) {
    if (this.uaG !== g || this.uaT !== g.t) {
      if (!this.ua) this.ua = new Uint8Array(MAX_PLAYERS + 1);
      const ua = this.ua.fill(0), L = g.aliveList;
      for (let i = g.aliveCount - 1; i >= 0; i--) {
        const p = L[i];
        if (p === this.me || g.isBot(p)) continue;
        const b = g.slotBase(p);
        for (let k = g.atkCount[p] - 1; k >= 0; k--) ua[g.atkTarget[b + k]] = 1;
      }
      this.uaG = g;
      this.uaT = g.t;
    }
    return this.ua[q] === 1;
  }

  // ---- spawn ----------------------------------------------------------------

  // Pick the spawn whose Voronoi region (pixels reached before any bot,
  // by 4-neighbour land distance) is largest.
  chooseSpawn(g) {
    const c = this.spawnCandidates(g, 1);
    return c.length ? c[0] : null;
  }

  // Up to k spawn candidates at least 12 pixels apart, best Voronoi score
  // first. The spawn can be re-picked until the countdown ends: when we
  // already hold one, spots are scored as if we were not on the map, ours
  // among them.
  spawnCandidates(g, k) {
    const me = this.me;
    if (g.terr[me] === 0) return this.scoreSpawns(g, k, null);
    const x = (g.x0[me] + g.x1[me]) >> 1, y = (g.y0[me] + g.y1[me]) >> 1;
    return this.scoreSpawns(withoutPlayer(g, me), k, y * g.W + x);
  }

  // Land distance (4-neighbour) of every pixel to the nearest player whose
  // owner passes keep(o), -1 where none is reachable.
  spawnDist(g, dist, keep = null) {
    const N = g.N, px = g.px, own = g.own, d = g.dir4;
    const { q } = scratch(N);
    dist.fill(-1);
    let qh = 0, qt = 0;
    for (let c = 0; c < N; c++) {
      if (px[c] >= P_INNER && (!keep || keep(own[c]))) {
        dist[c] = 0;
        q[qt++] = c;
      }
    }
    while (qh < qt) {
      const c = q[qh++];
      for (let k = 0; k < 4; k++) {
        const n = c + d[k];
        if (dist[n] < 0 && px[n] === T_LAND) {
          dist[n] = dist[c] + 1;
          q[qt++] = n;
        }
      }
    }
    return dist;
  }

  scoreSpawns(g, k, extra) {
    const W = g.W, H = g.H, N = g.N, px = g.px, d = g.dir4;
    const { q, dd } = scratch(N);
    const dist = this.spawnDist(g, scratch(N).dist);
    const top = farthest(dist, W, H, px, 60);
    if (extra !== null && px[extra] === T_LAND && !top.includes(extra)) top.push(extra);
    const R = this.p.spawnRadius, slack = this.p.spawnSlack, wc = this.p.spawnCoast;
    const scored = [];
    for (const s of top) {
      let h = 0, t = 0, score = 0;
      const seen = [];
      dd[s] = 0;
      q[t++] = s;
      seen.push(s);
      while (h < t) {
        const c = q[h++];
        const dc = dd[c];
        score += 1;
        if (wc) {
          for (let k = 0; k < 4; k++) if (px[c + d[k]] === T_WATER) {
            score += wc;
            break;
          }
        }
        if (dc >= R) continue;
        for (let k = 0; k < 4; k++) {
          const n = c + d[k];
          if (dd[n] < 0 && px[n] === T_LAND && dc + 1 < dist[n] + slack) {
            dd[n] = dc + 1;
            q[t++] = n;
            seen.push(n);
          }
        }
      }
      for (const c of seen) dd[c] = -1;
      scored.push({ x: s % W, y: iV(s, W), score: score * this.spawnWeight(g, s), stay: s === extra });
    }
    const stay = scored.find((s) => s.stay);
    scored.sort((a, b) => b.score - a.score);
    const out = [];
    for (const s of scored) {
      if (out.some((o) => Math.abs(o.x - s.x) + Math.abs(o.y - s.y) < 12)) continue;
      out.push(s);
      if (out.length >= k) break;
    }
    // staying put is always among the options of a re-pick
    if (stay && k > 1 && !out.includes(stay)) out.push(stay);
    return out;
  }

  spawnWeight() {
    return 1;
  }

  // ---- analysis ---------------------------------------------------------------

  // Neighbours (with the number of their pixels touching us) and the number
  // of neutral pixels touching us.
  analyze(g) {
    const me = this.me, px = g.px, own = g.own, d = g.dir4;
    if (!this.mark || this.mark.length !== g.N) this.mark = new Uint32Array(g.N);
    const mark = this.mark, cnt = this.cnt;
    const st = ++this.stamp;
    for (const o of this.nb) cnt[o] = 0;
    this.nb.length = 0;
    let neutral = 0;
    const B = g.border[me];
    for (let i = B.length - 1; i >= 0; i--) {
      const b = B[i];
      for (let k = 0; k < 4; k++) {
        const c = b + d[k];
        if (mark[c] === st) continue;
        const v = px[c];
        if (v === T_LAND) {
          mark[c] = st;
          neutral++;
        } else if (v >= P_INNER) {
          const o = own[c];
          if (o !== me && !this.isProtectedSquadMate(g, o)) {
            mark[c] = st;
            if (cnt[o]++ === 0) this.nb.push(o);
          }
        }
      }
    }
    this.neutral = neutral;
  }

  avgBotBalance(g) {
    const L = g.aliveList, me = this.me;
    let s = 0, n = 0;
    for (let i = g.aliveCount - 1; i >= 0; i--) {
      if (L[i] === me) continue;
      s += g.bal[L[i]];
      n++;
    }
    return n ? s / n : 0;
  }

  // What bot q would consider at its next decision: neutral land wins unless
  // q already attacks neutral land; otherwise the weakest neighbour (balance
  // plus troops attacking q) other than us.
  threatOf(g, q) {
    const B = g.border[q], px = g.px, own = g.own, d = g.dir4, me = this.me;
    const seen = this.oseen;
    const st = ++this.ostamp;
    const busyNeutral = g.hasAttack(q, NEUTRAL);
    let minOther = Infinity;
    const n = B.length;
    const step = n > 1024 ? Math.ceil(n / 1024) : 1;
    for (let i = n - 1; i >= 0; i -= step) {
      const b = B[i];
      for (let k = 0; k < 4; k++) {
        const c = b + d[k];
        const v = px[c];
        if (v === T_LAND) {
          if (!busyNeutral) return { neutral: true, minOther: 0 };
          continue;
        }
        if (v < P_INNER) continue;
        const o = own[c];
        if (o === q || o === me || seen[o] === st) continue;
        seen[o] = st;
        if (g.hasAttack(q, o)) continue;
        const s = g.bal[o] + g.attackTroopsOn(o, q);
        if (s < minOther) minOther = s;
      }
    }
    return { neutral: false, minOther };
  }

  // Balance we need so that no neighbouring bot prefers us as its target.
  safeBalance(g) {
    const me = this.me;
    let safe = 0;
    this.threats = 0;
    for (const q of this.nb) {
      if (g.alive[q] === 0 || !g.isBot(q) || !g.hasFreeSlot(q) || g.hasAttack(q, me)) continue;
      const th = this.threatOf(g, q);
      if (th.neutral) continue;
      this.threats++;
      const need = th.minOther - g.attackTroopsOn(me, q);
      if (need > safe) safe = need;
    }
    return safe;
  }

  // Estimated troops to push target q from its current size down to the
  // elimination threshold (its balance shrinks as it loses land).
  elimCost(g, q) {
    const T = g.terr[q], B = g.bal[q];
    const left = iV(g.peak[q], 4);
    const x = Math.min(1, left / Math.max(T, 1));
    return 2 * B * (1 - Math.pow(x, 1.6)) + 2 * T * (1 - x);
  }

  // ---- commands -----------------------------------------------------------------

  // Smallest command worth its fee (feeK x the fee of a land attack).
  minCmd(g) {
    return this.p.feeK * iV(12 * g.bal[this.me], 1024);
  }

  // Send about `troops` on target; returns true when the command was accepted.
  send(g, target, troops) {
    const bal = g.bal[this.me];
    if (bal <= 0 || troops <= 0) return false;
    if (g.online && target !== NEUTRAL) {
      if (!this._lastTargetSendTick) this._lastTargetSendTick = new Map();
      if (g.t - (this._lastTargetSendTick.get(target) ?? -999) < 15) return false;
      this._lastTargetSendTick.set(target, g.t);
    }
    let pct = Math.ceil((troops * 1024) / bal) - 1;
    pct = Math.max(0, Math.min(1023, pct));
    const ok = g.attack(pct, target, this.me);
    if (ok) this.cmds++;
    return ok;
  }

  act(g) {
    const me = this.me;
    if (!g.canAct(me)) return;
    const P = this.p;
    if (g.t % P.period !== 0) return;
    this.analyze(g);
    this.updateGrudges(g);
    const T = g.terr[me];
    const cap = 100 * T;
    const early = g.t < P.earlyEnd;
    let ref = 0;
    if (this.nb.length) {
      for (const o of this.nb) ref += g.bal[o];
      ref /= this.nb.length;
    } else ref = this.avgBotBalance(g);

    let floor = Math.max((early ? P.reserveEarly : P.reserve) * cap, (early ? P.refEarly : P.ref) * ref);
    if (P.safeK > 0) floor = Math.max(floor, P.safeK * this.safeBalance(g));
    floor = Math.min(floor, P.keepCap * cap);

    // Neutral land: hold enough troops for the next ring, topping up a few
    // rings at a time to save fees.
    if (this.neutral > 0) {
      const spendN = g.bal[me] - Math.min(floor, P.refN * ref);
      const ring = this.neutral;
      const have = g.attackTroopsOn(me, NEUTRAL);
      if (spendN >= this.minCmd(g) && have < 3 * (ring + P.nGrow) + 2 * ring * P.nLow) {
        const want = Math.min(Math.max(3 * ring + 2 * P.nHigh * (ring + P.nGrow * P.nHigh / 2) - have, this.minCmd(g)), spendN);
        if (want > 0) this.send(g, NEUTRAL, want);
      }
    }

    // Players: spend the balance above the floor on the cheapest targets.
    const bal = g.bal[me];
    const dMe = bal / Math.max(T, 1);
    let active = 0;
    const base = g.slotBase(me);
    for (let i = g.atkCount[me] - 1; i >= 0; i--) if (g.atkTarget[base + i] !== NEUTRAL) active++;
    let best = -1, bestS = Infinity, bestSnipe = false;
    for (const q of this.nb) {
      if (g.alive[q] === 0) continue;
      const Tq = g.terr[q];
      if (Tq === 0) continue;
      const already = g.hasAttack(me, q);
      if (!already && (active >= P.maxTargets || !g.hasFreeSlot(me))) continue;
      const perPx = 2 + 2 * g.bal[q] / (1 + iV(10 * Tq, 16));
      if (perPx > P.maxCost) continue;
      const snipe = g.bal[q] / Tq <= P.snipeK * dMe;
      const avail = bal - (snipe ? P.snipeF * floor : floor);
      if (avail <= P.minSend * bal) continue;
      const left = iV(g.peak[q], 4);
      const share = Math.min(1, this.cnt[q] / Math.max(1, g.border[q].length));
      const gain = (Tq - left) + left * (P.shareW * share);
      const ec = this.elimCost(g, q) + g.attackTroopsOn(q, me) - g.attackTroopsOn(me, q);
      let s = P.elimW * (ec / Math.max(gain, 1)) + (1 - P.elimW) * perPx;
      if (s > 0) s *= this.targetBias(g, q);
      if (s < bestS) {
        bestS = s;
        best = q;
        bestSnipe = snipe;
      }
    }
    if (best < 0) return;
    const avail = bal - (bestSnipe ? P.snipeF * floor : floor);
    if (P.sendFrac * avail >= this.minCmd(g)) this.send(g, best, P.sendFrac * avail);
  }
}

// General strategy: hand-written rules that read only what the game state
// shows (territories, balances, running attacks, boats) and assume nothing
// about how any opponent decides, so built-in bots, other people's scripts and
// humans are handled alike. Every decision is recomputed from the current
// state, so manual interference (retreats, troops sent elsewhere) is absorbed.
//
// Economy: interest is the main income and peaks with the balance at the soft
// cap (100 per pixel), so the balance is kept near the cap and the surplus
// buys land where it is cheapest per pixel. Neutral land costs 2 per pixel, a
// player's land 2 + 3.2 x its troop density, and a player pushed below a
// quarter of its peak collapses and leaves its land neutral. The reserve is
// relaxed when the land on offer is cheap and no neighbour is strong enough
// to punish a low balance. Land that can only be reached over water is taken
// by boat.

const BASE = {"period":5,"spawnRadius":45,"spawnSlack":2,"spawnCoast":0,"nLow":2.0404,"nHigh":2.2523,"nGrow":1.7099,"refN":1.2124,"earlyEnd":513,"reserveEarly":0.882,"reserve":0.9351,"refEarly":1.3295,"ref":0,"safeK":0.632,"keepCap":0.873,"minSend":0.2141,"maxTargets":4,"sendFrac":0.746,"elimW":0.8998,"shareW":0.1055,"maxCost":338.1478,"snipeK":0.1014,"snipeF":0.9773};

const GENERAL_PARAMS = {
  ...BASE,
  safeK: 0,
  snipeK: 0,
  // economic reserve: full reserve for land costing cRef per pixel or more,
  // proportionally less for cheaper land
  cRef: 60,
  // defence: keep kDef x the balance at which a neighbour holding at least
  // capMin x our balance would find us its weakest or cheapest neighbour;
  // a neighbour bordering no other player can only turn on us: keep aloneK x
  // its balance
  kDef: 4,
  capMin: 0.1,
  aloneK: 1,
  // weight of the price-per-pixel comparison, cap of the defence floor (x soft cap)
  denW: 1,
  defCap: 1,
  // while a person attacks us, the defence floor is defPile x higher (the
  // others see it and pile on)
  defPile: 1,
  // an attack on us by a person is answered at once with counterK x the
  // troops they still have on the way, if we can at least match them while
  // keeping counterFloor x the floor: our attack wipes theirs out first and
  // ends the fight the others would join (0 = off)
  counterK: 0,
  counterFloor: 0.5,
  // a person is attacked only when the troops we can send reach killK x what
  // it takes to collapse them, and then with 1.25 x that (0 = any time); a
  // half-beaten person holds a grudge and draws the others in
  killK: 0,
  // with no neighbour yet, reference balance = lonely x average balance of all players
  lonely: 1,
  // balance (x soft cap) from which spare troops are spent even on costly targets
  idleCap: 1.3,
  // send at most overshoot x the troops needed to collapse the target
  overshoot: 1e9,
  // spawn: land components smaller than minComp x all land are discounted;
  // spots within humanR x the mean spacing of the people in the game from
  // one already placed are discounted in proportion to the distance
  minComp: 0.05,
  humanR: 0.5,
  // spawn by lookahead (see rollout.js): the best of spawnRoll candidates
  // after spawnH ticks played out, by our land minus rivalW x the land of the
  // strongest other person (0 = off)
  spawnRoll: 8,
  spawnH: 2000,
  rivalW: 0.5,
  // in-game lookahead until planEnd: every planEvery ticks, each multiplier of
  // the balance floor in planModes is played out for planH ticks and the best
  // is kept for the next planEvery ticks (value as above plus balW x balance;
  // 0 = off)
  planEvery: 0,
  planH: 1200,
  planEnd: 6000,
  planModes: [1, 0.5, 2],
  balW: 0.05,
  // boats: ticks between launches, share of the free balance per boat,
  // search radius over water in pixels, troop loss rate per pixel of water,
  // boats at sea at once; with no affordable land target, boats also go out
  // when land over water costs (distance-grown) at most boxRatio x the
  // cheapest land neighbour
  boatEvery: 60,
  boatFrac: 0.5,
  boatRange: 200,
  boatDecay: 0.004,
  maxBoats: 2,
  boxRatio: 0,
  // boats count their fee (32 / 1024 of the whole balance, whatever they
  // carry) over the pixels they can take: a patch of neutral land, or 3/4
  // of a player that collapses; idle troops go by boat only while that
  // comes to at most boatFee x the price of our cheapest land neighbour,
  // and a boat to neutral land carries what the land costs (more only
  // decays at sea). Without it idle boats took the nearest islet with
  // 4 x the fee every boatEvery ticks (0 = off)
  boatFee: 0,
  // wars (a neighbour attacked us or we attacked it within warT ticks):
  // target score x retW for neighbours that attacked us, x warW for opening a
  // war with a player of density >= denseD while at war with another
  warT: 1500,
  retW: 1,
  warW: 1,
  denseD: 20,
};

const compCache = new WeakMap();

class General extends Strategy {
  constructor(params = {}, me = 0) {
    super({ ...GENERAL_PARAMS, ...params }, me);
    this.lastBoat = -1e9;
    this.boats = 0;
    this.wdist = null;
    this.wq = null;
    this.hitBy = new Map();
    this.hitTo = new Map();
    this.floorK = 1;
  }

  saveMemory() {
    return { ...super.saveMemory(), lastBoat: this.lastBoat, boats: this.boats, hitBy: new Map(this.hitBy), hitTo: new Map(this.hitTo) };
  }

  loadMemory(m) {
    super.loadMemory(m);
    this.lastBoat = m.lastBoat;
    this.boats = m.boats;
    this.hitBy = new Map(m.hitBy);
    this.hitTo = new Map(m.hitTo);
  }

  // ---- map structure ------------------------------------------------------------

  // Size of the land component (4-neighbour, terrain only) of every pixel.
  compSize(g) {
    let c = compCache.get(g.map);
    if (c) return c;
    const N = g.N, type = g.map.type, d = g.dir4;
    const lab = new Int32Array(N).fill(-1);
    const size = [];
    const q = new Int32Array(N);
    for (let s = 0; s < N; s++) {
      if (type[s] !== T_LAND || lab[s] >= 0) continue;
      const id = size.length;
      let h = 0, t = 0;
      q[t++] = s;
      lab[s] = id;
      while (h < t) {
        const a = q[h++];
        for (let k = 0; k < 4; k++) {
          const n = a + d[k];
          if (n >= 0 && n < N && type[n] === T_LAND && lab[n] < 0) {
            lab[n] = id;
            q[t++] = n;
          }
        }
      }
      size.push(t);
    }
    c = new Int32Array(N);
    for (let p = 0; p < N; p++) c[p] = lab[p] >= 0 ? size[lab[p]] : 0;
    compCache.set(g.map, c);
    return c;
  }

  // A pick that will be revised (final false) only claims the most open spot,
  // which people placing later keep away from; the lookahead decides at the
  // final pick.
  chooseSpawn(g, final = true) {
    const P = this.p;
    if (P.spawnRoll > 1 && final) {
      const s = spawnByRollout(this, g, P.spawnRoll, P.spawnH, P.rivalW, (me) => new General({ ...P, spawnRoll: 0 }, me));
      if (s) return s;
    }
    return super.chooseSpawn(g);
  }

  // Small land components are discounted; with other people in the game,
  // spots close to those already placed are too (they compete for the same
  // land and are far stronger than bots).
  spawnWeight(g, s) {
    const P = this.p;
    const comp = this.compSize(g)[s];
    const min = P.minComp * g.land;
    let w = comp >= min ? 1 : (comp / min) ** 2;
    if (P.humanR > 0 && g.humans > 1) {
      const R = P.humanR * Math.sqrt(g.land / g.humans);
      const x = s % g.W, y = iV(s, g.W);
      for (let h = 0; h < g.humans; h++) {
        if (h === this.me || g.terr[h] === 0) continue;
        const d = Math.hypot(x - (g.x0[h] + g.x1[h]) / 2, y - (g.y0[h] + g.y1[h]) / 2);
        if (d < R) w *= d / R;
      }
    }
    return w;
  }

  // ---- decisions ----------------------------------------------------------------

  act(g) {
    const me = this.me;
    if (!g.canAct(me)) return;
    const P = this.p;
    if (g.t % P.period !== 0) return;
    if (P.planEvery > 0 && g.t % P.planEvery === 0 && g.t < P.planEnd) {
      const copy = (m) => new General({ ...P, spawnRoll: 0, planEvery: 0 }, m);
      this.floorK = P.planModes[chooseMode(this, g, P.planModes, P.planEvery, P.planH, P.rivalW, P.balW, copy)];
    } else if (g.t >= P.planEnd) this.floorK = 1;
    this.analyze(g);
    if (typeof window !== "undefined" && window.__hlLog && g.t > 0 && g.t % 90 === 0 && this._lastTickLog !== g.t) {
      this._lastTickLog = g.t;
      const pf = window.__hlPerf;
      const pfStr = pf && pf.ticks > 0 ? ` avgMs=${(pf.totalMs / pf.ticks).toFixed(2)} maxMs=${pf.maxMs.toFixed(1)} skip=${pf.skippedTicks}` : "";
      window.__hlLog(`[HL-TICK] t=${g.t} terr=${g.terr[me]}(${(100 * g.terr[me] / Math.max(1, g.land)).toFixed(1)}%) bal=${g.bal[me]} dens=${(g.bal[me] / Math.max(1, g.terr[me])).toFixed(1)} nb=${this.nb.length} neut=${this.neutral} cmds=${this.cmds} boats=${this.boats}${pfStr}`);
    }
    this.tryPeaceVote(g);
    if (this.tryEmergencyBossRescue(g) && g.online) return;
    this.updateGrudges(g);
    this.updateWars(g);
    const { cap, avgNb, floorAt } = this.floors(g);
    if (P.counterK > 0 && this.counterAttack(g, floorAt)) return;
    if (this.warAct(g, floorAt)) return;

    if (this.neutral > 0) this.expandNeutral(g, g.bal[me] - Math.min(floorAt(2), P.refN * avgNb));

    let target = this.pickTarget(g, floorAt, P.maxCost);
    if (target) {
      this.send(g, target.q, target.amount);
      return;
    }
    if (this.neutral > 0) return;
    // Troops beyond the soft cap earn nothing, and land neighbours that are
    // all dense leave nothing cheap to take: look over water first, then
    // take the cheapest neighbour anyway.
    const idle = g.bal[me] >= P.idleCap * cap;
    if (g.t - this.lastBoat >= P.boatEvery) {
      if (this.nb.length === 0 || idle) {
        if (this.boatOut(g, floorAt, P.boatFee > 0 && this.nb.length ? P.boatFee * this.minNbPrice(g) : Infinity)) return;
      } else if (P.boxRatio > 0 && this.boatOut(g, floorAt, P.boxRatio * this.minNbPrice(g))) return;
    }
    if (idle && (target = this.pickTarget(g, floorAt, Infinity))) this.send(g, target.q, target.amount);
  }

  // Hook before the usual spending: true when this step is spent.
  warAct() {
    return false;
  }

  // Soft cap, average neighbour balance and the balance floor kept back
  // when buying land at a given price per pixel (call after analyze).
  floors(g) {
    const P = this.p, T = g.terr[this.me];
    const cap = 100 * T;
    const early = g.t < P.earlyEnd;
    let avgNb = 0;
    for (const o of this.nb) avgNb += g.bal[o];
    if (this.nb.length) avgNb /= this.nb.length;
    else avgNb = P.lonely * this.avgBotBalance(g);
    const reserve = (early ? P.reserveEarly : P.reserve) * cap;
    const refFloor = Math.max((early ? P.refEarly : P.ref) * avgNb, this.defenseNeed(g));
    const floorAt = (price) => this.floorK * Math.min(P.keepCap * cap, Math.max(reserve * Math.min(1, price / P.cRef), refFloor));
    return { cap, avgNb, floorAt };
  }

  // Answer the person with the most troops on the way to us (beyond what our
  // own attack on them already matches). Returns true on a command.
  counterAttack(g, floorAt) {
    const P = this.p, me = this.me;
    let q = -1, most = 0;
    for (const o of this.nb) {
      if (g.alive[o] === 0 || g.isBot(o)) continue;
      const x = g.attackTroopsOn(o, me) - g.attackTroopsOn(me, o);
      if (x > most) {
        most = x;
        q = o;
      }
    }
    if (q < 0) return false;
    const perPx = 2 + (2 * g.bal[q]) / (1 + iV(10 * g.terr[q], 16));
    const send = Math.min(g.bal[me] - P.counterFloor * floorAt(perPx), P.counterK * most);
    if (send < most || send < this.minCmd(g)) return false;
    return this.send(g, q, send);
  }

  minNbPrice(g) {
    let m = Infinity;
    for (const q of this.nb) {
      if (g.alive[q] === 0 || g.terr[q] === 0) continue;
      m = Math.min(m, 2 + (2 * g.bal[q]) / (1 + iV(10 * g.terr[q], 16)));
    }
    return m;
  }

  // Track who attacks us and whom we attack (call after analyze).
  updateWars(g) {
    const me = this.me, t = g.t;
    for (const q of this.nb) {
      if (g.attackTroopsOn(q, me) > 0) this.hitBy.set(q, t);
      if (g.attackTroopsOn(me, q) > 0) this.hitTo.set(q, t);
    }
  }

  atWar(g, q) {
    const t0 = g.t - this.p.warT;
    return (this.hitBy.get(q) ?? -1e9) >= t0 || (this.hitTo.get(q) ?? -1e9) >= t0;
  }

  // Target score multiplier: neighbours that attacked us recently are hit
  // back (they are at war with us anyway and have spent troops); opening a
  // war with another dense player while one is running is avoided.
  warBias(g, q) {
    const P = this.p;
    let k = 1;
    if (P.retW !== 1 && (this.hitBy.get(q) ?? -1e9) >= g.t - P.warT) k *= P.retW;
    if (P.warW !== 1 && !this.atWar(g, q) && g.bal[q] >= P.denseD * g.terr[q]) {
      for (const o of this.nb) {
        if (o !== q && g.alive[o] && g.bal[o] >= P.denseD * g.terr[o] && this.atWar(g, o)) {
          k *= P.warW;
          break;
        }
      }
    }
    return k;
  }

  // Defence floor: kDef x the balance below which a neighbour able to hurt us
  // (holding at least capMin x our balance) would find us its weakest
  // neighbour by balance or its cheapest by price per pixel, compared with
  // the other players it borders; aloneK x the balance of a neighbour that
  // borders no other player.
  defenseNeed(g) {
    const P = this.p, me = this.me;
    const bal = g.bal[me];
    const k = 1 + iV(10 * g.terr[me], 16);
    let need = 0;
    for (const q of this.nb) {
      if (g.alive[q] === 0 || g.bal[q] < P.capMin * bal) continue;
      const a = this.altOf(g, q);
      const sent = g.attackTroopsOn(me, q);
      if (a.minBal === Infinity) need = Math.max(need, g.bal[q] > 0 ? P.aloneK * g.bal[q] - sent : 0);
      else need = Math.max(need, P.kDef * Math.max(a.minBal - sent, (P.denW * (a.minPrice - 2) * k) / 2));
    }
    if (P.defPile !== 1 && this.attackedByOthers(g, me)) need *= P.defPile;
    return Math.min(need, P.defCap * 100 * g.terr[me]);
  }

  // Weakest balance (plus troops already attacking q) and lowest price per
  // pixel among the players other than us that q borders; long borders are
  // sampled.
  altOf(g, q) {
    const B = g.border[q], px = g.px, own = g.own, d = g.dir4, me = this.me;
    const seen = this.oseen;
    const st = ++this.ostamp;
    let minBal = Infinity, minPrice = Infinity;
    const n = B.length;
    const step = n > 1024 ? Math.ceil(n / 1024) : 1;
    for (let i = n - 1; i >= 0; i -= step) {
      const b = B[i];
      for (let k = 0; k < 4; k++) {
        const c = b + d[k];
        if (px[c] < P_INNER) continue;
        const o = own[c];
        if (o === q || o === me || seen[o] === st) continue;
        seen[o] = st;
        const v = g.bal[o] + g.attackTroopsOn(o, q);
        if (v < minBal) minBal = v;
        const price = 2 + (2 * g.bal[o]) / (1 + iV(10 * g.terr[o], 16));
        if (price < minPrice) minPrice = price;
      }
    }
    return { minBal, minPrice };
  }

  // Keep enough troops on the neutral front for the next rings, topping up a
  // few rings at a time to save fees.
  expandNeutral(g, spend) {
    const P = this.p;
    const min = this.minCmd(g);
    if (spend < min) return;
    const ring = this.neutral;
    const have = g.attackTroopsOn(this.me, NEUTRAL);
    if (have >= 3 * (ring + P.nGrow) + 2 * ring * P.nLow) return;
    const want = Math.min(Math.max(3 * ring + 2 * P.nHigh * (ring + P.nGrow * P.nHigh / 2) - have, min), spend);
    this.send(g, NEUTRAL, want);
  }

  // Cheapest neighbour to push towards collapse, with the troops to send.
  pickTarget(g, floorAt, maxCost) {
    const P = this.p, me = this.me;
    const bal = g.bal[me];
    let active = 0;
    const base = g.slotBase(me);
    for (let i = g.atkCount[me] - 1; i >= 0; i--) if (g.atkTarget[base + i] !== NEUTRAL) active++;
    const dMe = bal / Math.max(g.terr[me], 1);
    const min = this.minCmd(g);
    let best = null, bestS = Infinity;
    for (const q of this.nb) {
      if (g.alive[q] === 0) continue;
      const Tq = g.terr[q];
      if (Tq === 0) continue;
      if (!g.hasAttack(me, q) && (active >= P.maxTargets || !g.hasFreeSlot(me))) continue;
      const perPx = 2 + (2 * g.bal[q]) / (1 + iV(10 * Tq, 16));
      if (perPx > maxCost) continue;
      // a target much thinner than us is bought down to snipeF x the floor
      const thin = g.bal[q] / Tq <= P.snipeK * dMe;
      const avail = bal - (thin ? P.snipeF : 1) * floorAt(perPx);
      if (avail <= P.minSend * bal || P.sendFrac * avail < min) continue;
      const need = this.elimCost(g, q) + g.attackTroopsOn(q, me) - g.attackTroopsOn(me, q);
      // the running attack already carries enough: no top-up worth a fee
      if (need <= 0) continue;
      const kill = P.killK > 0 && !g.isBot(q);
      if (kill && P.sendFrac * avail < P.killK * need) continue;
      const left = iV(g.peak[q], 4);
      const share = Math.min(1, this.cnt[q] / Math.max(1, g.border[q].length));
      const gain = Tq - left + left * P.shareW * share;
      let s = P.elimW * (need / Math.max(gain, 1)) + (1 - P.elimW) * perPx;
      if (s > 0) s *= this.targetBias(g, q) * this.warBias(g, q);
      if (s < bestS) {
        bestS = s;
        best = { q, amount: Math.min(P.sendFrac * avail, Math.max((kill ? 1.25 : P.overshoot) * need + 3 * this.cnt[q], min)) };
      }
    }
    return best;
  }

  // ---- boats --------------------------------------------------------------------

  // Boat to the best land over water (see searchWater) if its distance-grown
  // price is at most maxEff, spending boatFrac of the balance above the
  // floor for its price. Returns true on launch.
  boatOut(g, floorAt, maxEff) {
    const P = this.p, me = this.me;
    if (!g.boatsAllowed(me) || g.boatCount[me] >= P.maxBoats) return false;
    this.lastBoat = g.t;
    const hit = this.searchWater(g);
    if (!hit || hit.eff > maxEff) return false;
    const bal = g.bal[me];
    const max = P.boatFrac * (bal - floorAt(hit.price));
    const min = P.boatFee > 0 && hit.neutral ? 60 : Math.max(60, P.feeK * iV(32 * bal, 1024));
    if (max < min) return false;
    const amount = hit.neutral ? Math.min(max, Math.max(3 * hit.size + 300, min)) : max;
    const pct = Math.max(0, Math.min(1023, Math.ceil((amount * 1024) / bal) - 1));
    if (!g.boatTo(pct, hit.land, me)) return false;
    this.boats++;
    this.cmds++;
    return true;
  }

  // Breadth-first search over water from our shores for neutral land or land
  // of a player that is not a land neighbour, cheapest by price per pixel
  // grown by exp(boatDecay x distance) for the troops boats lose on the way.
  searchWater(g) {
    const N = g.N, px = g.px, own = g.own, d = g.dir4, me = this.me;
    const decay = this.p.boatDecay;
    if (!this.wdist || this.wdist.length !== N) {
      this.wdist = new Int32Array(N);
      this.wq = new Int32Array(N);
    }
    const dist = this.wdist.fill(-1), q = this.wq;
    let h = 0, t = 0;
    const seed = (list) => {
      for (let i = list.length - 1; i >= 0; i--) {
        for (let k = 0; k < 4; k++) {
          const c = list[i] + d[k];
          if (px[c] === T_WATER && dist[c] < 0) {
            dist[c] = 0;
            q[t++] = c;
          }
        }
      }
    };
    seed(g.coast[me]);
    seed(g.border[me]);
    const comp = this.compSize(g);
    const fee = this.p.boatFee > 0 ? iV(32 * g.bal[me], 1024) : 0;
    const noBots = this.botOk && g.bal[me] < this.p.idleCap * 100 * g.terr[me];
    let best = null, bestEff = Infinity;
    const range = this.p.boatRange;
    while (h < t) {
      const c = q[h++];
      const dc = dist[c];
      const grow = Math.exp(decay * dc);
      if (dc > range || 2 * grow >= bestEff) break;
      for (let k = 0; k < 4; k++) {
        const n = c + d[k];
        const v = px[n];
        if (v === T_WATER) {
          if (dist[n] < 0) {
            dist[n] = dc + 1;
            q[t++] = n;
          }
        } else if (v === T_LAND) {
          const eff = 2 * grow + fee / Math.max(1, comp[n]);
          if (eff < bestEff) {
            bestEff = eff;
            best = { land: n, neutral: true, size: comp[n], price: 2, eff };
          }
        } else if (v >= P_INNER) {
          const o = own[n];
          if (o === me || this.isProtectedSquadMate(g, o) || this.cnt[o] > 0 || (noBots && g.isBot(o) && !this.botOk(g, o))) continue;
          const price = 2 + (2 * g.bal[o]) / (1 + iV(10 * g.terr[o], 16));
          const eff = price * grow + fee / Math.max(1, 0.75 * g.terr[o]);
          if (eff < bestEff) {
            bestEff = eff;
            best = { land: n, neutral: false, size: 0, price, eff };
          }
        }
      }
    }
    return best;
  }
}

// Style bots: players with one pronounced way of playing, each pushed as far
// as it goes, used as varied opponents in the league and as a source of
// ideas for the general strategy. They share the General machinery (map
// analysis, neutral expansion, defence floor, boats, fees) and what most
// people do: whoever attacks them becomes their preferred target for a
// while (a grudge, held against people only), and whoever someone else is
// beating is a preferred target too (piling on). A style changes which
// neighbours it attacks, with how many troops, how much it keeps back, and
// where it spawns, through the hooks of pickTarget below.

const STYLE_PARAMS = {
  spawnRoll: 0,
  planEvery: 0,
  grudgeT: 3000,
  grudgeW: 0.25,
  pileW: 0.5,
};

class Style extends General {
  constructor(params = {}, me = 0) {
    super({ ...STYLE_PARAMS, ...params }, me);
  }

  price(g, q) {
    return 2 + (2 * g.bal[q]) / (1 + iV(10 * g.terr[q], 16));
  }

  person(g, q) {
    return !g.isBot(q);
  }

  grudgeOn(g, q) {
    return (this.grudge.get(q) ?? -1) >= g.t;
  }

  updateGrudges(g) {
    if (!this.p.grudgeT) return;
    for (const q of this.nb) if (this.person(g, q) && g.attackTroopsOn(q, this.me) > 0) this.grudge.set(q, g.t + this.p.grudgeT);
  }

  // Whether q may be attacked at all.
  allow() {
    return true;
  }

  // Balance kept back when attacking q (f: the general floor for its price).
  floorFor(g, q, f) {
    return f;
  }

  // Least share of the balance worth a send on q (a command costs 12/1024
  // of the whole balance).
  minShare(g, q) {
    return this.p.minSend;
  }

  // Troops to send on q (0: not now).
  amount(g, q, avail, need, min) {
    const P = this.p;
    return Math.min(P.sendFrac * avail, Math.max(P.overshoot * need + 3 * this.cnt[q], min));
  }

  pickTarget(g, floorAt, maxCost) {
    const P = this.p, me = this.me;
    const bal = g.bal[me];
    let active = 0;
    const base = g.slotBase(me);
    for (let i = g.atkCount[me] - 1; i >= 0; i--) if (g.atkTarget[base + i] !== NEUTRAL) active++;
    const min = this.minCmd(g);
    let best = null, bestS = Infinity;
    for (const q of this.nb) {
      if (g.alive[q] === 0) continue;
      const Tq = g.terr[q];
      if (Tq === 0) continue;
      if (!g.hasAttack(me, q) && (active >= P.maxTargets || !g.hasFreeSlot(me))) continue;
      if (!this.allow(g, q)) continue;
      const perPx = this.price(g, q);
      if (perPx > maxCost) continue;
      const avail = bal - this.floorFor(g, q, floorAt(perPx));
      if (avail <= this.minShare(g, q) * bal || avail < min) continue;
      const need = this.elimCost(g, q) + g.attackTroopsOn(q, me) - g.attackTroopsOn(me, q);
      if (need <= 0) continue;
      if (!this.person(g, q) && g.hasAttack(me, q) && (!g.hasAttack(q, me) || g.attackTroopsOn(me, q) >= 0.35 * need)) continue;
      const send = this.amount(g, q, avail, need, min);
      if (!(send >= min)) continue;
      const left = iV(g.peak[q], 4);
      const share = Math.min(1, this.cnt[q] / Math.max(1, g.border[q].length));
      const gain = Tq - left + left * P.shareW * share;
      let s = P.elimW * (need / Math.max(gain, 1)) + (1 - P.elimW) * perPx;
      if (s > 0) s *= this.targetBias(g, q) * this.warBias(g, q);
      if (s < bestS) {
        bestS = s;
        best = { q, amount: send };
      }
    }
    return best;
  }
}

// What a player reaches over water: the water bodies its coast touches and
// the shore land of every body (land 4-next to its water, per map), sampled
// for boat targets. A boat crosses one water body only, from our coast
// nearest the target (Game.boatTo finds the landing spot). Without the
// terrain and water bodies (g.map.type, g.map.id, g.wid) nothing is reached.

const shoreCache = new WeakMap();

// Shore land pixels of every water body: Map body id -> Int32Array.
function shores(g) {
  if (!g.map?.type || !g.map.id) return null;
  let s = shoreCache.get(g.map);
  if (s) return s;
  const N = g.N, type = g.map.type, id = g.map.id, d = g.dir4;
  const lists = new Map();
  for (let c = 0; c < N; c++) {
    if (type[c] !== T_LAND) continue;
    let last = -1;
    for (let k = 0; k < 4; k++) {
      const n = c + d[k];
      if (n < 0 || n >= N || type[n] !== T_WATER) continue;
      const b = id[n];
      if (b === last) continue;
      last = b;
      let l = lists.get(b);
      if (!l) lists.set(b, (l = []));
      if (l[l.length - 1] !== c) l.push(c);
    }
  }
  s = new Map([...lists].map(([b, l]) => [b, Int32Array.from(l)]));
  shoreCache.set(g.map, s);
  return s;
}

// Water bodies along p's coast (long coasts are sampled).
function bodiesOf(g, p) {
  const C = g.coast?.[p];
  if (!C || !C.length || !g.wid) return [];
  const out = [], d = g.dir4, px = g.px, wid = g.wid;
  const step = C.length > 256 ? Math.ceil(C.length / 256) : 1;
  for (let i = C.length - 1; i >= 0; i -= step) {
    for (let k = 0; k < 4; k++) {
      const n = C[i] + d[k];
      if (px[n] === T_WATER && !out.includes(wid[n])) out.push(wid[n]);
    }
  }
  return out;
}

// n shore pixels of p's water bodies, each body by its share of the shore,
// as { c, o, d }: o = -1 for free land, else the owner (p's own skipped);
// d = distance in pixels to the nearest of up to 32 of p's coast pixels.
function seaSample(g, p, n, rnd) {
  const S = shores(g);
  if (!S) return [];
  const bodies = bodiesOf(g, p).map((b) => S.get(b)).filter((l) => l && l.length);
  if (!bodies.length) return [];
  const total = bodies.reduce((s, l) => s + l.length, 0);
  const C = g.coast[p], W = g.W;
  const cs = [];
  const step = Math.max(1, Math.floor(C.length / 32));
  for (let i = 0; i < C.length; i += step) cs.push(C[i]);
  const px = g.px, own = g.own, out = [];
  for (let k = 0; k < n; k++) {
    let r = Math.floor(rnd() * total), l = bodies[0];
    for (const b of bodies) {
      if (r < b.length) {
        l = b;
        break;
      }
      r -= b.length;
    }
    const c = l[Math.min(r, l.length - 1)];
    const v = px[c];
    let o;
    if (v === T_LAND) o = -1;
    else if (v >= P_INNER) o = own[c];
    else continue;
    if (o === p) continue;
    const x = c % W, y = (c - x) / W;
    let dd = Infinity;
    for (const e of cs) {
      const ex = e % W, ey = (e - ex) / W;
      const q = (x - ex) * (x - ex) + (y - ey) * (y - ey);
      if (q < dd) dd = q;
    }
    out.push({ c, o, d: Math.sqrt(dd) });
  }
  return out;
}

// Main strategy: the strongest bot so far, built on the General machinery
// (map analysis, neutral expansion, defence floor, boats, fees) and the
// style hooks. What it does by default, each rule kept because it won a
// same-seed A/B test on the league:
//  - people are not attacked unless they attacked us (a grudge) or our
//    troops pile up beyond what earns interest; neutral land and bots are
//    the food. Land costing less than 0.1 / r per pixel (r: our interest
//    per 10 ticks) is bought with all we have, as its land income beats
//    the interest on the troops, and a bot gets only the troops that
//    collapse it, as troops on the way earn nothing. Otherwise the balance
//    is kept at the interest cap, which makes our land the most expensive
//    around (attackers pick someone else);
//  - once neutral land is gone, people as cheap per pixel as a bot we
//    would eat are bought before our troops reach the cap, while their
//    land costs less than what a troop held will buy at the cap (hoardBuy:
//    480 seeds, +0.6 +- 0.9, not a clear win, kept for the land: first at
//    tick 3000 in 28.1% of the games instead of 26.2%);
//  - the spawn is claimed first at the most open spot (people placing
//    later keep away from it) and picked again last, with everyone placed,
//    staying put among the options; land near bots counts as reachable
//    (bots are food, not rivals: 480 seeds, +5.6 +- 2.2 points).
// Rules under test are parameters that are off by default. The spawn
// lookahead (spawnRoll > 1) is off: it did not win more games for this
// strategy (192 seeds) and makes a game ten times slower. Leaving people
// with more land alone (idleRatio 1, grudgeRatio 1) lost 9.0 +- 1.4 points
// (480 seeds): troops kept back stop earning interest at 1.5 x the cap. Not
// hitting back at people with more land lost 3.1 +- 0.9 with v3 in the
// league: we lose half the troops of an attack on us, so its author finds
// us cheaper afterwards, grudge or not.

const PARAMS13 = {
  // full reserve for any land costing cRef per pixel or more, defence floor
  // kDef x what would make us a neighbour's weakest or cheapest target
  cRef: 60,
  reserve: 1,
  keepCap: 1,
  kDef: 4,
  // bots only while cheaper than this per pixel; from idleCap x the soft
  // cap, spare troops go to people and costly bots too
  botMax: 60,
  idleCap: 1.25,
  humanR: 1.5,
  spawnRoll: 0,
  spawnH: 2000,
  rivalW: 0.5,
  // unprovoked attacks on a person only if its land is at most idleRatio x
  // ours and the troops we can send reach idleKill x what collapses it
  // (0 = any); grudge attacks only if its land is at most grudgeRatio x ours.
  // Land, not balance: income goes with land, so it decides who can keep a
  // war going, and a person we attack holds a grudge and comes back at us
  idleRatio: 1e9,
  idleKill: 0,
  grudgeRatio: 1e9,
  // no attack on a person while its attack on us runs (the defender pays
  // half of what the attacker does; we hit back once it has spent itself)
  waitEnd: 0,
  // neutral expansion keeps at least nFloor x the soft cap (troops at home
  // earn up to 7% per 10 ticks early on: 960 seeds, +3.2 +- 1.6 points)
  nFloor: 0.1,
  // the nFloor reserve is kept only for land costing more per pixel than
  // 0.1 / r (r: our interest per 10 ticks below the cap). Holding c x the
  // cap and spending the rest of the income on land at p per pixel, land
  // grows by (100 c r + 0.1) / (100 c + p) per 10 ticks (0.1: the land
  // income of a pixel), which falls as c rises when r p < 0.1: neutral land
  // after tick ~640, bots at 5 per pixel after ~1600 (0 = off; 480 seeds
  // with v3 in the league, 44.0% vs 21.7%, +22.3 +- 2.3; first in land at
  // tick 2000 in 69% of the games instead of 16%)
  byRate: 1,
  // a bot whose next dump we expect (it attacks with 98% of its balance
  // every ~104 ticks, timed from the last drop of its balance we saw) is
  // bought after it while breaking 98% of its balance B (~1.75 B) costs
  // more than the land income of its land T over the w ticks to wait (T w
  // / 100): a bot is cheapest in the first third of its cycle. Not while
  // another person attacks it (it would take the land) or our balance is
  // at the cap (troops held there lower our interest) (0 = off)
  botWait: 0,
  // what collapses a bot counts botRegen x the land income it earns while
  // we take it: an attack takes one ring per expansion step (every 4, 3, 2
  // or 1 ticks at our land < 1k, < 10k, < 60k, more), so 3/4 of its land T
  // falls in D = ticks per step x 0.75 T / ring width, rings as wide as our
  // contact or as a blob of T pixels; meanwhile it earns ~0.625 T D / 100
  // (its land shrinks to T / 4) and every troop it holds costs us two to
  // break. Without it bot attacks ran dry and took 2 to 7 commands (12 /
  // 1024 of our balance each), using 1.4 to 3 x the collapse cost seen at
  // the first send (0 = off)
  botRegen: 0,
  // with no neutral land and no bot to buy by land, boats go for the
  // cheapest neutral land or bot over water by troops per pixel (troops lost
  // at sea and the boat fee counted) up to botMax: the beachhead makes the
  // rest of it land we border (0 = off; boats otherwise go out only from
  // idleCap x the soft cap, to the land cheapest per pixel whatever its size)
  boatFood: 1,
  // with no neutral land on our border and our troops short of idleCap x the
  // soft cap, a person whose land costs at most 338 c / idleCap per pixel
  // (c: our balance / soft cap) is food: a troop held grows with interest
  // to that threshold and then buys land of people kept near the cap at
  // ~338 per pixel (1.05 x the cap). Meanwhile nobody attacks a person
  // unprovoked before its own troops reach the threshold, and a victim
  // cannot hit back from below its floor. Only up to botMax: near the
  // threshold the saving vanishes while the troops spent leave us the
  // cheapest of neighbours about to reach theirs (without that cap, 480
  // seeds: 17.3% vs 23.8%, -6.5 +- 1.5, half the balance sent at 333 per
  // pixel) (0 = off)
  hoardBuy: 0,
  // bots costing at most botMax per pixel are bought like neutral land, with
  // the floor of the neutral front instead of the defence floor, and sent
  // only foodK x what collapses them: an attack takes one ring per step
  // however many troops it carries, and troops on the way earn no interest
  // (up to 7% per 10 ticks early on) until they come back at its end (0 =
  // off; 480 seeds, 52.3% vs 30.6%, +21.7 +- 2.5). Keeping only nFloor x
  // the soft cap for them instead did worse (-2.3 +- 0.8)
  foodK: 1.25,
  // target score x contestW for bots that another person borders too (if
  // we do not take them, they will). Replays of 25 v10 games (exact owner
  // changes): of a bot we first touch in t1000-1500 that another person
  // borders too, other people take 17% of its land within 50 ticks, 26%
  // within 100, 42% within 300; of a bot only we border, 0%, 3%, 6%. When
  // both of us hit it, we got 44% of the people's take hitting first, 27%
  // hitting second. Taking the contested one first loses ~26% less of it
  // per 100 ticks the other waits, so it wins at up to 1 / 0.74 x the cost
  contestW: 0.7,
  // a person we have no other reason to attack is struck when the troops we
  // can send, keeping preyFloor x the usual floor, reach preyKill x what
  // collapses it, and then with 1.25 x that: a dead person holds no grudge
  // (0 = off)
  preyKill: 1,
  preyFloor: 0.5,
  // spawn: land near bots counts as if the bots were botOff pixels farther
  // away (Very Easy bots grow slowly and their land is food; 0 = off)
  botOff: 16,
  // people as thin as a bot we would eat (at most personMax per pixel) are
  // food too (0 = off)
  personMax: 0,
  // people as thin as a bot we would eat (at most botMax per pixel) are
  // bought like bots, but only when we can send preyK x what collapses them,
  // counting the troops they have out (which come back to their balance): a
  // dead person holds no grudge, a live one hits back (0 = off)
  preyK: 0,
  // spare troops (from idleCap x the soft cap) are sent in one command down
  // to idleLo x the soft cap: interest is highest at the cap and falls off
  // twice as fast above it, and every command costs 12/1024 of the balance,
  // so few large sends swinging around the cap waste the least (0 = keep
  // the usual floor and send sendFrac of what is above it)
  idleLo: 0,
  // spare troops are sent only as far as leaves idleSafe x the soft cap
  // once the fee, the first ring of a fresh attack (taken from the balance
  // when the troops sent fall short) and the cap raised by the land bought
  // are counted: most people attack only land costing at most ~338 per
  // pixel, which is what a balance of 1.05 x the cap costs (0 = off)
  idleSafe: 0,
  // while a person's attack on us runs, our attacks on people come home and
  // none is started (0 = off): against that attack, troops at home lose one
  // for every two it spends while troops attacking it cancel one for one,
  // and a balance back above 1.05 x the cap (338 per pixel) is out of reach
  // for most people, so the others cannot pile on
  holdOn: 0,
  // spawn against the people (see spawnVsPeople; 0 = off): distance scale,
  // candidates farthest from the people, search radius; a pixel only
  // spawnM pixels nearer to us than to the nearest person counts that share
  // of a pixel (it is fought over; 0 = off)
  spawnP: 1000000000,
  spawnK: 400,
  spawnGap: 24,
  spawnMaxD: 600,
  spawnM: 200,
  // the spot's score less spawnB per pixel of its land touching land a
  // person reaches first (the front we hold), divided by 1 + spawnN per
  // neighbour person beyond the first: the people who win sit in corners
  // and peninsulas with one or two people next to them and eat those one
  // at a time, while the open middle has five to nine (0 = off)
  spawnB: 0,
  spawnN: 0,
  // war on thin people (0 = off): people growing fast keep almost no troops
  // (a person of 23k pixels may hold 9k troops at tick 1250), so collapsing
  // one costs about as much per pixel as neutral land and bots, takes all
  // its land at once and removes a rival for the rest. A neighbour person
  // whose collapse costs at most warPx per pixel of its land, with land at
  // least warMin x ours, is struck with warK x that cost (its attack on us
  // counted) once we can send it keeping warKeep x the soft cap, and the
  // attack is topped up to warK x the cost until it collapses
  warK: 0,
  warPx: 8,
  warMin: 0.3,
  warKeep: 0,
  // buying neutral land and food keeps our troop density at least pplK x
  // that of the densest neighbour person: people with no neutral land left
  // buy the thinnest person next to them (a v5 buys a person whose land
  // costs at most 2.7 x its own density), and growing fast leaves us at a
  // fifth of a troop per pixel (0 = off); hungryK: the same only against
  // neighbour people with no neutral land, at hungryK x the density below
  // which a v5 there would buy our land (0 = off); hungryAll: against every
  // neighbour person (a neighbour runs out of neutral land faster than our
  // troops grow back), until tick hungryEnd
  pplK: 0,
  hungryK: 0,
  hungryAll: 0,
  hungryEnd: 1e9,
  // duel (0 = off): a person we may attack (grudge, idle troops) is attacked
  // only while its density (its troops on us counted) is at most duelK x
  // ours, or once our balance reaches duelCap x the soft cap (troops there
  // earn nothing). An attack costs the attacker twice what the defender
  // loses, so a strike on a person as dense as us leaves us the thinner and
  // the cheaper to hit back. The troops sent collapse it if we can, else are
  // the most that leave our density at least duelM x its own once the land
  // has changed hands. Only while at most duelN people (us included) are
  // alive (0 = any number): earlier, troops held back earn nothing above
  // the cap while the people around grow
  duelK: 0,
  duelCap: 1.45,
  duelM: 1,
  duelN: 0,
  // target score x reachW for a person whose collapse costs more than
  // reachK x our balance (see outOfReach; 1 = off); reachBan: such a person
  // is not attacked at all, our troops wait above the cap instead (0 = off)
  reachW: 1,
  reachK: 1,
  reachBan: 0,
  // one front at a time (1 = off): the person we have the most troops on
  // (else the one we hit last, within focusT ticks) gets its target score x
  // focusW, every other person (food aside) x focusX. A person we attack
  // holds a grudge and sends us its spare troops for thousands of ticks, so
  // hitting a different neighbour every few hundred ticks turns all of them
  // against us, while the winners fight one neighbour at a time
  focusW: 1,
  focusX: 1,
  focusT: 600,
  // safety from the people (0 = off): the people of the real battle royale
  // attack the neighbour person with the fewest troops, once they hold
  // safeRatio x its troops or sit near the cap (safeCapD troops per pixel,
  // where they hit their weakest whatever the ratio), and leave the others
  // alone. Every spending keeps safeP x the balance below which a neighbour
  // person (or, for an attack on person q, a person bordering q, who borders
  // us once q is gone) would find us its weakest, up to safeMax x the hard
  // cap (150 per pixel)
  safeP: 0,
  safeRatio: 2.5,
  safeCapD: 100,
  safeMax: 1,
  // the people who reach our coast over water count as neighbours too: in
  // the real games half of their boats at people went where no land path
  // led, up to 125 pixels across, at the weakest they reached (0 = off)
  safeSea: 0,
  // attacks on people other than food only when the troops we can send reach
  // pKill x what collapses them, sending that (0 = off): drip attacks pay the
  // fee (12/1024 of the balance) every time, leave the land to whoever
  // finishes the kill and the victim's troops to the others
  pKill: 0,
  // second front (0 = off): an attack on a neighbour q that would take over
  // frontT ticks to take 3/4 of its land (an attack takes one ring of our
  // contact per step) sends front2 of its troops by boat to q's shore at
  // most frontD pixels from our coast and at least frontGap pixels from our
  // front with q, if that comes to frontFee x the boat fee (32/1024 of the
  // balance): the attack goes on from the beachhead too (the troops of both
  // fronts are one pool), so q falls sooner and others take less of it. One
  // beachhead per target every frontEvery ticks
  front2: 0,
  frontT: 200,
  frontD: 80,
  frontGap: 40,
  frontEvery: 300,
  frontFee: 4,
  // boat bank (0 = off): interest is highest at the soft cap and falls to
  // nothing at 1.5 x, while a boat loses 1/128 of its troops every 5 ticks.
  // Troops beyond what keeps us at bankTo x the soft cap and nobody's
  // weakest neighbour (see peopleSafe, bank x that) sail off once they come
  // to bankFee x the boat fee (32/1024 of the balance), towards the shore,
  // bankMin to boatRange pixels away, of the cheapest land per pixel we
  // reach; home earns the full rate meanwhile. Within bankNear pixels of its
  // landing a boat lands if it takes free land, a bot we would buy, or a
  // person we may attack with bankKill x what collapses it; else it turns
  // back (Game.recall) and its troops join the balance at home (up to the
  // hard cap). All turn back, and none sails, while people attack us with
  // bankThreat x our balance. Needs Game.recall and the boat arrays
  // (bRoute, ...); without them nothing happens
  bank: 0,
  bankThreat: 0.2,
  bankTo: 1,
  bankFee: 8,
  bankMin: 30,
  bankNear: 4,
  bankKill: 1.25,
  // race (0 = off): until tick raceEnd every balance floor (defence, the
  // reserve for land, nFloor, the food floor) is raceK x the usual. In the real games the
  // people race for bots and free land until ~2500 and seldom attack people
  // meanwhile; the fastest growers sent 0.6-1 x their balance at bots while
  // holding 4-7% of the soft cap, and the war-game deaths were mostly at
  // the hands of a neighbour 4-5 x our land that found us its weakest
  raceEnd: 0,
  raceK: 0.25,
  // least share of the balance for a send on food (bots and people we buy
  // like them), instead of minSend (-1 = minSend). With minSend (21%) and
  // the food floor at refN x the neighbours' mean balance, a seat whose
  // neighbour people were richer than its bots never bought the bots: at
  // tick 2000 of mvxgsaz5 three bots (32k pixels, 127k troops to collapse)
  // stayed next to 213k troops of ours for 500 ticks, 36k above the floor
  foodMin: 0,
  // the food floor is foodRef x the mean balance of our neighbours, bots
  // counted (-1 = refN): the people around hold 0.1-0.2 x the soft cap from
  // tick ~2000 while racing, which held ours above its balance and left
  // the bots next to us to them
  foodRef: 0.3,
  // foodMin and foodRef also cover the people we buy like food (0 = bots
  // only): on hoardBuy, small sends at people under the lower floor left
  // the seat the weakest person around by troops (-3 points of survival)
  foodPpl: 0,
  // foodMin covers those people too, whatever foodPpl
  foodMinPpl: 0,
  // foodMin and foodRef only from this tick on: before it, sprayed at the
  // bots, they left a seat first by land with a fifth of its neighbours'
  // troops, eaten by the first that went for its weakest (brm15x seed 117)
  foodT: 2000,
  // early phase (0 = off): until tick dpEnd, free land is bought with one
  // command per rent cycle instead of top-ups above the nFloor reserve.
  // Rent (+ our land) comes at tick 99 of every 100 and interest every 10
  // ticks on the troops at home only (up to 7% early on), so the command
  // goes at the latest act tick from which its rings all land by tick 98:
  // the first 7 ticks after the command, the next every 4 / 3 / 2 / 1 ticks
  // at land < 1k / 10k / 60k / more. Rings are the breadth-first layers of
  // free land from our border (an attack takes every free pixel next to its
  // front), at 2 per pixel plus one more for the last ring (it needs 3 and
  // the rest comes back). As many rings as fit in dpSpend x the balance
  // with the fee counted, keeping what the strongest neighbour person would
  // need to collapse us with its whole balance (1.5 x land + 1.78 x troops).
  // On the 15 v10 games this rule (bots from tick 1200) reaches 96% of the
  // DP optimum of troops + 17 x land at tick 1500, 1.78 x what v10 did
  dpEnd: 1500,
  dpSpend: 0.5,
  // bots are not attacked, by land or boat, before tick aiFrom unless our
  // troops are idle (0 = any time): troops at home earn the interest floor
  // (13440 - 6 t) / 1920 % per 10 ticks, early on more than bot land pays
  // back at 2 + 1.78 x its troop density per pixel (a collapse, the quarter
  // left neutral taken at 2; 4.4 at ticks 500-1000 in the v10 games). From
  // aiFrom to dpEnd bots keep no nFloor reserve and get at most dpSpend of
  // the balance per send. dpLand > 0: before dpEnd a bot is also bought
  // only while its land costs at most what a pixel bought now is worth at
  // dpEnd in troops held from now: dpLand plus the rents until dpEnd, each
  // grown by the interest floor, over what a troop held grows to (2.96 at
  // tick 700, 4.59 at 900, 5.80 at 1000, 9.25 at 1200). V = troops + 17 x
  // land at tick 1500 over v10's in the simulator (8 seeds of brm15x /
  // brmw4): bots at any time 0.71 / -, from tick 900 1.07 / 1.01, from 1000
  // 1.14 / 1.08, from 1200 0.88 / 0.86 (the DP's pick under the land cap
  // of the real games, 96% of its optimum against 90% from 900), dpLand 17
  // alone 1.03 / 0.93, with aiFrom 900 1.06 / 1.01
  aiFrom: 0,
  dpLand: 0,
  // winR > 0: before dpEnd a bot is bought only while its land costs at
  // most winR x tick x our troops per pixel of ours, and down to that troop
  // density at most (with dpKeep and the balance at which no neighbouring
  // bot prefers us as its target). What a pixel is worth in troops for
  // winning, from the 33 recorded games with a winner (conditional logit of
  // the winner on log land and log troops among the people alive at a
  // tick): land / troops weight 0.71 at tick 500, 1.50 at 700, 2.33 at 850,
  // 1.92 at 1000, 2.24 at 1200, 3.00 at 1500 (fit 0.04 + 0.002 t), times
  // troops / land. Bots cost 3.6-4.5 per pixel at ticks 700-1200 against
  // 10-18 that a pixel was worth at our median state; the winners held 2.5
  // troops per pixel at tick 700, we held 11.4
  winR: 0.002,
  // set for this version over the general machinery's default
  boatFee: 1,
};

class V13 extends Style {
  constructor(params = {}, me = 0) {
    super({ ...PARAMS13, ...params }, me);
  }

  chooseSpawn(g, final = true) {
    const P = this.p;
    const roll = P.spawnRoll > 1 && final;
    const make = (me) => new Policy({ ...P, spawnRoll: 0 }, me);
    if (P.spawnP > 0) {
      const list = this.spawnVsPeople(g, roll ? P.spawnRoll : 1);
      if (list.length > 1) return spawnByRollout(this, g, list.length, P.spawnH, P.rivalW, make, list);
      if (list.length) return list[0];
    }
    if (roll) {
      const s = spawnByRollout(this, g, P.spawnRoll, P.spawnH, P.rivalW, make);
      if (s) return s;
    }
    return this.spawnCandidates(g, 1)[0] ?? null;
  }

  // The spot with the most land we reach before any other person (land
  // distance, 4-neighbour; a pixel d steps away counts spawnP / (spawnP +
  // d), as far land is reached late and fought over): bots are food, the
  // people are the rivals for it. Candidates: the grid spots farthest from
  // the people and the usual candidates against everyone. The best k spots
  // at least spawnGap x 2 apart, best first, the first refined by a local
  // search (none before any other person has picked). The live game asks
  // every second during the spawn countdown: the answer is kept while the
  // other people stay where they are.
  spawnVsPeople(g, k = 1) {
    const me = this.me;
    const key = [k, g.W, g.H, g.land];
    for (let o = 0; o < g.humans; o++) if (o !== me && g.terr[o] > 0) key.push(o, g.x0[o], g.y0[o], g.x1[o], g.y1[o]);
    const ks = key.join();
    if (this.spawnKey !== ks) {
      this.spawnOut = this.spawnVsPeople0(g, k);
      this.spawnKey = ks;
    }
    return this.spawnOut;
  }

  spawnVsPeople0(g, k) {
    const P = this.p, me = this.me;
    const h = g.terr[me] > 0 ? withoutPlayer(g, me) : g;
    const N = h.N, px = h.px, W = h.W, H = h.H, d = h.dir4;
    if (!this.dPeople || this.dPeople.length !== N) {
      this.dPeople = new Int32Array(N);
      this.dMine = new Int32Array(N).fill(-1);
      this.bq = new Int32Array(N);
    }
    let placed = false;
    for (let o = 0; o < h.humans; o++) if (o !== me && h.terr[o] > 0) placed = true;
    if (!placed) return [];
    const dist = Strategy.prototype.spawnDist.call(this, h, this.dPeople, (o) => o < h.humans && o !== me);
    const cand = [];
    const far = [], cut = [];
    for (let y = 6; y < H - 7; y += 4) {
      for (let x = 6; x < W - 7; x += 4) {
        const c = y * W + x;
        if (px[c] !== T_LAND) continue;
        if (dist[c] >= 0) far.push(c);
        else cut.push(c);
      }
    }
    far.sort((a, b) => dist[b] - dist[a]);
    const spaced = (list, k, gap) => {
      const out = [];
      for (const c of list) {
        if (out.length >= k) break;
        const x = c % W, y = iV(c, W);
        if (out.some((o) => Math.abs((o % W) - x) + Math.abs(iV(o, W) - y) < gap)) continue;
        out.push(c);
      }
      return out;
    };
    // land no person reaches by land (islands, pockets): a few spots of it
    cand.push(...spaced(far, P.spawnK, P.spawnGap), ...spaced(cut, 8, 64));
    for (const s of this.spawnCandidates(g, 8)) cand.push(s.y * W + s.x);
    const dd = this.dMine, q = this.bq, lam = P.spawnP, maxD = P.spawnMaxD, M = P.spawnM;
    const fronts = P.spawnB > 0 || P.spawnN > 0;
    const who = fronts ? this.peopleCells(h, dist) : null;
    const seen = new Int32Array(h.humans);
    let stamp = 0;
    const score = (s) => {
      if (px[s] !== T_LAND) return -1;
      let qh = 0, qt = 0, sc = 0, B = 0, nN = 0;
      stamp++;
      dd[s] = 0;
      q[qt++] = s;
      while (qh < qt) {
        const c = q[qh++];
        const dc = dd[c];
        const w = M > 0 && dist[c] >= 0 ? Math.min(1, (dist[c] - dc) / M) : 1;
        sc += (w * lam) / (lam + dc);
        if (dc >= maxD) continue;
        let edge = false;
        for (let k = 0; k < 4; k++) {
          const n = c + d[k];
          if (dd[n] >= 0 || px[n] !== T_LAND) continue;
          if (dist[n] >= 0 && dc + 1 >= dist[n]) {
            if (fronts) {
              edge = true;
              const o = who[n];
              if (o >= 0 && seen[o] !== stamp) {
                seen[o] = stamp;
                nN++;
              }
            }
            continue;
          }
          dd[n] = dc + 1;
          q[qt++] = n;
        }
        if (edge) B++;
      }
      for (let i = 0; i < qt; i++) dd[q[i]] = -1;
      if (!fronts) return sc;
      return (sc - P.spawnB * B) / (1 + P.spawnN * Math.max(0, nN - 1));
    };
    const scored = cand.map((s) => ({ s, v: score(s) })).filter((c) => c.v > 0).sort((a, b) => b.v - a.v);
    if (!scored.length) return [];
    let best = scored[0].s, bestS = scored[0].v;
    // then a local search in shrinking steps
    for (let step = P.spawnGap >> 1; step >= 2; step >>= 1) {
      let moved = true;
      while (moved) {
        moved = false;
        const x = best % W, y = iV(best, W);
        for (const [dx, dy] of [[step, 0], [-step, 0], [0, step], [0, -step]]) {
          const nx = x + dx, ny = y + dy;
          if (nx < 6 || ny < 6 || nx >= W - 7 || ny >= H - 7) continue;
          const v = score(ny * W + nx);
          if (v > bestS) {
            bestS = v;
            best = ny * W + nx;
            moved = true;
          }
        }
      }
    }
    const out = [best];
    for (const { s } of scored) {
      if (out.length >= k) break;
      if (out.some((o) => Math.abs((o % W) - (s % W)) + Math.abs(iV(o, W) - iV(s, W)) < 2 * P.spawnGap)) continue;
      out.push(s);
    }
    return out.map((c) => ({ x: c % W, y: iV(c, W) }));
  }

  // The person each land pixel is nearest to by land (-1: none reaches it),
  // ties to the first reached, as spawnDist measures the distances.
  peopleCells(g, dist) {
    const N = g.N, px = g.px, own = g.own, d = g.dir4, me = this.me;
    if (!this.who || this.who.length !== N) this.who = new Int16Array(N);
    const who = this.who, q = this.bq;
    who.fill(-1);
    let qh = 0, qt = 0;
    for (let c = 0; c < N; c++) {
      if (px[c] >= P_INNER && own[c] < g.humans && own[c] !== me) {
        who[c] = own[c];
        q[qt++] = c;
      }
    }
    while (qh < qt) {
      const c = q[qh++];
      for (let k = 0; k < 4; k++) {
        const n = c + d[k];
        if (who[n] < 0 && px[n] === T_LAND && dist[n] >= 0) {
          who[n] = who[c];
          q[qt++] = n;
        }
      }
    }
    return who;
  }

  idle(g) {
    return g.bal[this.me] >= this.p.idleCap * 100 * g.terr[this.me];
  }

  act(g) {
    const P = this.p;
    if (P.raceEnd > 0) this.floorK = g.t < P.raceEnd ? P.raceK : 1;
    this.held = P.holdOn > 0 && g.canAct(this.me) && g.t % P.period === 0 && this.hold(g);
    const turn = g.canAct(this.me) && g.t % P.period === 0;
    if (P.bank > 0 && turn && this.nb) this.bankAct(g);
    const n = this.cmds;
    super.act(g);
    if (!turn) return;
    if (P.boatFood > 0 && this.cmds === n) this.boatFood(g);
  }

  send(g, target, troops) {
    const boat = this.p.front2 > 0 && target !== NEUTRAL ? this.frontBoat(g, target, troops) : 0;
    if (!boat) return super.send(g, target, troops);
    if (troops - boat >= this.minCmd(g)) super.send(g, target, troops - boat);
    return true;
  }

  // Troops of an attack on q going by boat to a beachhead (see front2; 0:
  // none).
  frontBoat(g, q, troops) {
    const P = this.p, me = this.me;
    if (!g.alive[q] || !g.boatsAllowed(me) || g.boatCount[me] >= P.maxBoats) return 0;
    if (!this.frontAt) this.frontAt = new Map();
    if (g.t - (this.frontAt.get(q) ?? -1e9) < P.frontEvery || this.attackTicks(g, q) <= P.frontT) return 0;
    const bal = g.bal[me], amount = P.front2 * troops;
    if (amount < Math.max(60, P.frontFee * iV(32 * bal, 1024))) return 0;
    this.frontAt.set(q, g.t);
    const land = this.beachhead(g, q);
    if (land < 0) return 0;
    const pct = Math.max(0, Math.min(1023, Math.ceil((amount * 1024) / bal) - 1));
    if (!g.boatTo(pct, land, me)) return 0;
    this.boats++;
    this.cmds++;
    return amount;
  }

  // A shore pixel of q at most frontD from our coast, the farthest from our
  // front with q (at least frontGap away; -1: none).
  beachhead(g, q) {
    const P = this.p, me = this.me, W = g.W, px = g.px, own = g.own, d = g.dir4;
    const front = [];
    const B = g.border[me];
    const step = Math.max(1, Math.floor(B.length / 256));
    for (let i = 0; i < B.length && front.length < 32; i += step) {
      const b = B[i];
      for (let k = 0; k < 4; k++) {
        const c = b + d[k];
        if (px[c] >= P_INNER && own[c] === q) {
          front.push(b);
          break;
        }
      }
    }
    let x = (Math.imul(g.t + 7, 2654435761) ^ (me + 1)) >>> 0;
    const rnd = () => (x = (Math.imul(x, 1664525) + 1013904223) >>> 0) / 4294967296;
    let best = -1, bestD = P.frontGap;
    for (const s of seaSample(g, me, 96, rnd)) {
      if (s.o !== q || s.d > P.frontD) continue;
      let m = Infinity;
      const cx = s.c % W, cy = iV(s.c, W);
      for (const f of front) m = Math.min(m, Math.hypot(cx - (f % W), cy - iV(f, W)));
      if (m > bestD) {
        bestD = m;
        best = s.c;
      }
    }
    return best;
  }

  // Bank boats (see bank), before the usual spending: near their landing
  // they land or turn back; with troops to spare, a new one sails.
  bankAct(g) {
    const P = this.p, me = this.me;
    // In the real game a chase at 849/1024 aimed at one's own boat turns it
    // back (the sim's chase skips 849 and offers recall instead).
    const recall = typeof g.recall === 'function' ? (id) => g.recall(id, me)
      : typeof g.chase === 'function' ? (id) => g.chase(849, id, me) : null;
    if (!recall || !g.bRoute || g.boatNextId === undefined) return false;
    if (!this.bankIds) this.bankIds = new Set();
    let on = 0;
    for (const q of g.attackersOf(me)) if (q < g.humans) on += g.attackTroopsOn(q, me);
    const hit = on >= P.bankThreat * g.bal[me];
    for (const id of [...this.bankIds]) {
      const b = g.playerBoat(me, id);
      if (b < 0) {
        this.bankIds.delete(id);
        continue;
      }
      if (g.bType[b] % 64 === 5) continue;
      if (hit || (this.routeLeft(g, b) <= P.bankNear && !this.bankLands(g, b))) recall(id);
    }
    if (hit || !g.boatsAllowed(me) || g.boatCount[me] >= P.maxBoats || g.t - (this.lastBank ?? -1e9) < P.boatEvery) return false;
    const bal = g.bal[me], T = g.terr[me];
    const keep = Math.max(P.bankTo * 100 * T, P.bank * this.peopleSafe(g));
    const fee = iV(32 * bal, 1024);
    if (bal - fee - keep < P.bankFee * fee) return false;
    let x = (Math.imul(g.t + 3, 2654435761) ^ (me + 1)) >>> 0;
    const rnd = () => (x = (Math.imul(x, 1664525) + 1013904223) >>> 0) / 4294967296;
    let land = -1, bestP = Infinity;
    for (const s of seaSample(g, me, 64, rnd)) {
      if (s.d < P.bankMin || s.d > P.boatRange) continue;
      if (s.o >= 0 && this.isProtectedSquadMate(g, s.o)) continue;
      const price = s.o < 0 ? 2 : this.price(g, s.o);
      if (price < bestP) {
        bestP = price;
        land = s.c;
      }
    }
    if (land < 0) return false;
    const pct = Math.max(0, Math.min(1023, Math.floor(((bal - fee - keep) * 1024) / bal) - 1));
    if (!g.boatTo(pct, land, me)) return false;
    this.bankIds.add((g.boatNextId + 65535) % 65536);
    this.lastBank = g.t;
    this.boats++;
    this.cmds++;
    return true;
  }

  // Pixels of water left on boat b's route.
  routeLeft(g, b) {
    const rb = g.bRoute[b], leg = g.bLeg[b];
    let len = g.pixDist(g.subToPixel(g.bPos[b]), rb[leg + 1]);
    for (let i = leg + 1; i < rb.length - 1; i++) len += g.pixDist(rb[i], rb[i + 1]);
    return len;
  }

  // Whether bank boat b should land: on free land, a bot we would buy, or a
  // person we may attack that its troops collapse bankKill times over.
  bankLands(g, b) {
    const P = this.p, me = this.me, px = g.px;
    const rb = g.bRoute[b], type = g.bType[b] % 64, end = rb[rb.length - 1];
    const at = type < 4 ? end + g.dir4[type] : end;
    if (px[at] === T_LAND) return true;
    if (px[at] < P_INNER) return false;
    const o = g.own[at];
    if (o === me || !g.alive[o]) return false;
    if (!this.person(g, o)) return this.price(g, o) <= P.botMax;
    const need = this.elimCost(g, o) + g.attackTroopsOn(o, me) - g.attackTroopsOn(me, o);
    return this.allow(g, o) && g.bTroops[b] >= P.bankKill * need;
  }

  // War on thin people (see warK): top up a running war, else open one on
  // the biggest neighbour person that qualifies. True on a command.
  warAct(g) {
    const P = this.p, me = this.me;
    if (!(P.warK > 0)) return false;
    const bal = g.bal[me], T = g.terr[me];
    const spare = bal - P.warKeep * 100 * T;
    const min = this.minCmd(g);
    if (!this.wars) this.wars = new Set();
    let best = -1, bestT = 0, bestSend = 0;
    for (const q of this.nb) {
      if (g.alive[q] === 0 || !this.person(g, q)) continue;
      const Tq = g.terr[q];
      if (Tq === 0) continue;
      const have = g.attackTroopsOn(me, q);
      const cost = this.elimCost(g, q) + g.attackTroopsOn(q, me) + 3 * this.cnt[q];
      if (this.wars.has(q)) {
        if (have === 0) this.wars.delete(q);
        else {
          const top = P.warK * cost - have;
          if (top >= min && spare >= min) return this.send(g, q, Math.min(top, spare));
          continue;
        }
      }
      if (Tq < P.warMin * T || cost > P.warPx * Tq || P.warK * cost > spare) continue;
      if (have === 0 && !g.hasFreeSlot(me)) continue;
      if (Tq > bestT) {
        bestT = Tq;
        best = q;
        bestSend = P.warK * cost - have;
      }
    }
    if (best < 0 || bestSend < min || !this.send(g, best, bestSend)) return false;
    this.wars.add(best);
    return true;
  }

  // With no neutral land and no bot to buy by land, the cheapest food over
  // water by troops per pixel (see searchFood) if at most botMax; the boat
  // carries foodK x what takes it once the troops lost at sea are counted,
  // and the land it takes makes the rest of the target a land neighbour.
  // Troops at sea cannot come back to defend for hundreds of ticks (a land
  // attack retreats at once), so boats keep the full defence floor, not
  // the lower one of bots bought by land. Its own timer: lastBoat also
  // gates the boats of idle troops (General.act).
  boatFood(g) {
    const P = this.p, me = this.me;
    if (this.neutral > 0 || g.t - (this.lastFood ?? -1e9) < P.boatEvery) return false;
    if (!g.boatsAllowed(me) || g.boatCount[me] >= P.maxBoats) return false;
    for (const q of this.nb) if (g.alive[q] && !this.person(g, q) && this.price(g, q) <= P.botMax) return false;
    this.lastFood = g.t;
    const hit = this.searchFood(g);
    if (!hit || hit.eff > P.botMax) return false;
    const bal = g.bal[me];
    const { floorAt } = this.floors(g);
    const floor = Math.max(this.reserve(g, hit.price), floorAt(hit.price));
    const max = P.boatFrac * (bal - floor);
    const min = Math.max(60, P.feeK * iV(32 * bal, 1024));
    if (max < min) return false;
    const amount = Math.min(max, Math.max(P.foodK * hit.cost, min));
    const pct = Math.max(0, Math.min(1023, Math.ceil((amount * 1024) / bal) - 1));
    if (!g.boatTo(pct, hit.land, me)) return false;
    this.boats++;
    this.cmds++;
    return true;
  }

  // Neutral land and bots over water that are not land neighbours, by troops
  // per pixel: price x exp(boatDecay x distance) (a boat loses 1/128 of its
  // troops every 5 ticks at under 0.6 pixels per tick) plus the boat fee
  // (32 / 1024 of our balance) over the pixels to take: the land component
  // for neutral land, what falls before collapse for a bot.
  searchFood(g) {
    const N = g.N, px = g.px, own = g.own, d = g.dir4, me = this.me, P = this.p;
    if (!this.wdist || this.wdist.length !== N) {
      this.wdist = new Int32Array(N);
      this.wq = new Int32Array(N);
    }
    const dist = this.wdist.fill(-1), q = this.wq;
    let h = 0, t = 0;
    for (const list of [g.coast[me], g.border[me]]) {
      for (let i = list.length - 1; i >= 0; i--) {
        for (let k = 0; k < 4; k++) {
          const c = list[i] + d[k];
          if (px[c] === T_WATER && dist[c] < 0) {
            dist[c] = 0;
            q[t++] = c;
          }
        }
      }
    }
    const comp = this.compSize(g);
    const fee = iV(32 * g.bal[me], 1024);
    let best = null;
    while (h < t) {
      const c = q[h++];
      const dc = dist[c];
      const grow = Math.exp(P.boatDecay * dc);
      if (dc > P.boatRange || (best && 2 * grow >= best.eff)) break;
      for (let k = 0; k < 4; k++) {
        const n = c + d[k];
        const v = px[n];
        if (v === T_WATER) {
          if (dist[n] < 0) {
            dist[n] = dc + 1;
            q[t++] = n;
          }
          continue;
        }
        let hit = null;
        if (v === T_LAND) {
          const s = comp[n];
          hit = { land: n, price: 2, cost: (3 * s + 300) * grow, eff: 2 * grow + fee / s };
        } else if (v >= P_INNER) {
          const o = own[n];
          if (o === me || this.cnt[o] > 0 || this.person(g, o) || g.alive[o] === 0 || !this.botOk(g, o)) continue;
          const gain = Math.max(1, g.terr[o] - iV(g.peak[o], 4));
          const cost = this.elimCost(g, o) * grow;
          hit = { land: n, price: this.price(g, o), cost, eff: (cost + fee) / gain };
        }
        if (hit && (!best || hit.eff < best.eff)) best = hit;
      }
    }
    return best;
  }

  // Whether a person is attacking us; if so, our attacks on people return.
  hold(g) {
    const me = this.me;
    if (!g.attackersOf(me).some((q) => q < g.humans)) return false;
    const base = g.slotBase(me);
    for (let i = g.atkCount[me] - 1; i >= 0; i--) {
      const q = g.atkTarget[base + i];
      if (q < g.humans) g.retreat(q, me);
    }
    return true;
  }

  minShare(g, q) {
    const P = this.p;
    return P.foodMin >= 0 && this.food(g, q) && (P.foodMinPpl > 0 || this.lowFood(g, q)) ? P.foodMin : P.minSend;
  }

  // Whether foodMin and foodRef apply to food q now (see foodPpl, foodT).
  lowFood(g, q) {
    return g.t >= this.p.foodT && (this.p.foodPpl > 0 || !this.person(g, q));
  }

  // Food floor on q: this x the mean balance of our neighbours (see foodRef).
  foodRef(g, q) {
    const P = this.p;
    return (P.foodRef >= 0 && this.lowFood(g, q) ? P.foodRef : P.refN) * (g.t < P.raceEnd ? P.raceK : 1);
  }

  allow(g, q) {
    const P = this.p;
    if (!this.person(g, q)) return (this.botOk(g, q) && this.price(g, q) <= P.botMax) || this.idle(g);
    if (this.held) return false;
    if (this.food(g, q)) return true;
    if (P.waitEnd && g.attackTroopsOn(q, this.me) > 0) return false;
    if (this.duelOn(g) && !this.duelOk(g, q)) return false;
    if (P.reachBan > 0 && this.outOfReach(g, q)) return false;
    return P.preyKill > 0 || this.motive(g, q) !== null;
  }

  // Whether the duel rule applies now (see duelK, duelN).
  duelOn(g) {
    const P = this.p;
    if (!(P.duelK > 0)) return false;
    if (!(P.duelN > 0)) return true;
    let n = 0;
    for (let o = 0; o < g.humans; o++) if (g.terr[o] > 0 && ++n > P.duelN) return false;
    return true;
  }

  // Whether person q is thin enough to strike (see duelK).
  duelOk(g, q) {
    const P = this.p, me = this.me, T = Math.max(g.terr[me], 1);
    if (g.bal[me] >= P.duelCap * 100 * T) return true;
    const dQ = (g.bal[q] + g.attackTroopsOn(q, me)) / Math.max(g.terr[q], 1);
    return dQ <= P.duelK * (g.bal[me] / T);
  }

  // Troops for a strike on person q (see duelK): what collapses it when we
  // can afford it, else the most that leaves our density at least duelM x
  // its own once the land has changed hands (0 if none does).
  duelSend(g, q, need, min) {
    const P = this.p, me = this.me;
    const B = g.bal[me], L = Math.max(g.terr[me], 1);
    const Bq = g.bal[q], Lq = Math.max(g.terr[q], 1);
    const counter = g.attackTroopsOn(q, me);
    const fee = iV(12 * B, 1024);
    const top = B - fee - 1;
    if (top <= 0) return 0;
    if (1.1 * need + 3 * this.cnt[q] <= top) return Math.max(1.1 * need + 3 * this.cnt[q], min);
    const per = this.price(g, q);
    const gap = (X) => {
      const hit = Math.max(0, X - counter);
      const x = Math.min(Lq - 1, hit / per);
      return (B - fee - X) / (L + x) - P.duelM * Math.max(0, Bq - hit / 2) / (Lq - x);
    };
    if (gap(min) < 0) return 0;
    let lo = min, hi = top;
    if (gap(hi) >= 0) return hi;
    for (let i = 0; i < 24; i++) {
      const mid = (lo + hi) / 2;
      if (gap(mid) >= 0) lo = mid;
      else hi = mid;
    }
    return lo;
  }

  // Why person q may be attacked: 'grudge', 'idle', 'cheap' or null.
  motive(g, q) {
    const P = this.p, me = this.me;
    if (this.grudgeOn(g, q)) return g.terr[q] <= P.grudgeRatio * g.terr[me] ? 'grudge' : null;
    if (this.idle(g) && g.terr[q] <= P.idleRatio * g.terr[me]) return 'idle';
    return this.price(g, q) <= P.personMax ? 'cheap' : null;
  }

  food(g, q) {
    const P = this.p;
    if (!(P.foodK > 0)) return false;
    if (!this.person(g, q) || P.preyK > 0) return this.price(g, q) <= P.botMax;
    return P.hoardBuy > 0 && this.hoardFood(g, q);
  }

  // Whether person q's land is cheaper now than land will be once our
  // troops reach the idle threshold (see hoardBuy).
  hoardFood(g, q) {
    const P = this.p;
    if (this.neutral > 0 || this.idle(g)) return false;
    const c = g.bal[this.me] / (100 * g.terr[this.me]);
    return this.price(g, q) <= Math.min(P.botMax, (338 * c) / P.idleCap);
  }

  floors(g) {
    const r = super.floors(g);
    this.avgNb = r.avgNb;
    return r;
  }

  // Balance at which our density is pplK x that of the densest neighbour
  // person (troops it has on us counted as its own), or hungryK x the
  // density below which a neighbour person with no neutral land left buys
  // our land (a v5 buys a person whose land costs at most 2.7 x its own
  // density, up to 60 per pixel).
  peopleFloor(g) {
    const P = this.p, me = this.me;
    if (!(P.pplK > 0) && !(P.hungryK > 0 && g.t < P.hungryEnd)) return 0;
    let d = 0;
    for (const q of this.nb) {
      if (g.alive[q] === 0 || !this.person(g, q) || g.terr[q] === 0) continue;
      const Dq = (g.bal[q] + g.attackTroopsOn(q, me)) / g.terr[q];
      if (P.pplK > 0) d = Math.max(d, P.pplK * Dq);
      if (P.hungryK > 0 && g.t < P.hungryEnd && (P.hungryAll > 0 || !this.hasNeutral(g, q))) d = Math.max(d, (P.hungryK * (Math.min(60, 2.7 * Dq) - 2)) / 3.2);
    }
    return d * g.terr[me];
  }

  // Whether q borders neutral land (long borders are sampled).
  hasNeutral(g, q) {
    const B = g.border[q], px = g.px, d = g.dir4;
    const n = B.length;
    const step = n > 512 ? Math.ceil(n / 512) : 1;
    for (let i = n - 1; i >= 0; i -= step) {
      const b = B[i];
      for (let k = 0; k < 4; k++) if (px[b + d[k]] === T_LAND) return true;
    }
    return false;
  }

  floorFor(g, q, f) {
    const s = this.p.safeP > 0 ? this.p.safeP * this.peopleSafe(g, this.person(g, q) ? q : -1) : 0;
    return Math.max(this.floorFor0(g, q, f), s);
  }

  floorFor0(g, q, f) {
    const P = this.p;
    if (P.winR > 0 && g.t < P.dpEnd && !this.person(g, q)) return Math.max(this.winFloor(g, q), this.peopleFloor(g));
    if (this.food(g, q)) return Math.max(g.t < P.dpEnd ? this.dpKeep(g) : this.reserve(g, this.price(g, q)), Math.min(f, this.foodRef(g, q) * (this.avgNb ?? Infinity)), this.peopleFloor(g));
    if (P.idleLo > 0 && this.idle(g)) return Math.min(f, P.idleLo * 100 * g.terr[this.me]);
    return P.preyKill > 0 && this.person(g, q) && this.motive(g, q) === null ? P.preyFloor * f : f;
  }

  peopleCache(g) {
    if (this.pnT === g.t && this.pnG === g) return;
    this.pnT = g.t;
    this.pnG = g;
    this.pn = new Map();
    this.ps = new Map();
  }

  // People bordering person q (long borders are sampled), cached per tick.
  peopleOf(g, q) {
    this.peopleCache(g);
    let s = this.pn.get(q);
    if (s) return s;
    s = [];
    const B = g.border[q], px = g.px, own = g.own, d = g.dir4;
    const n = B.length;
    const step = n > 512 ? Math.ceil(n / 512) : 1;
    const seen = this.oseen, st = ++this.ostamp;
    for (let i = n - 1; i >= 0; i -= step) {
      const b = B[i];
      for (let k = 0; k < 4; k++) {
        const c = b + d[k];
        if (px[c] < P_INNER) continue;
        const o = own[c];
        if (o === q || seen[o] === st) continue;
        seen[o] = st;
        if (g.alive[o] && !g.isBot(o) && !this.isProtectedSquadMate(g, o)) s.push(o);
      }
    }
    this.pn.set(q, s);
    return s;
  }

  // Balance below which a neighbour person would find us its weakest
  // neighbour person by troops while holding safeRatio x our troops or sitting
  // near the cap (see safeP); with person q gone (q >= 0), its people border
  // us and it borders nobody.
  peopleSafe(g, q = -1) {
    const P = this.p, me = this.me;
    this.peopleCache(g);
    if (this.ps.has(q)) return this.ps.get(q);
    const cands = [];
    for (const o of this.nb) if (o !== q && g.alive[o] && g.terr[o] > 0 && this.person(g, o)) cands.push(o);
    if (q >= 0) for (const o of this.peopleOf(g, q)) if (o !== me && g.terr[o] > 0 && !cands.includes(o)) cands.push(o);
    if (P.safeSea > 0) for (const o of this.seaPeople(g)) if (o !== q && g.alive[o] && g.terr[o] > 0 && !cands.includes(o)) cands.push(o);
    let need = 0;
    for (const B of cands) {
      const bB = g.bal[B];
      let w = Infinity;
      for (const o of this.peopleOf(g, B)) if (o !== me && o !== q && g.terr[o] > 0) w = Math.min(w, g.bal[o]);
      const line = bB >= P.safeCapD * Math.max(1, g.terr[B]) ? Infinity : bB / P.safeRatio;
      need = Math.max(need, Math.min(w, line));
    }
    need = Math.min(need, P.safeMax * 150 * g.terr[me]);
    this.ps.set(q, need);
    return need;
  }

  // People on the shores of the water bodies along our coast (64 shore
  // pixels sampled every 50 ticks).
  seaPeople(g) {
    if (this.seaG === g && g.t - this.seaT < 50) return this.seaP;
    this.seaG = g;
    this.seaT = g.t;
    let x = (Math.imul(g.t + 1, 2654435761) ^ (this.me + 1)) >>> 0;
    const rnd = () => (x = (Math.imul(x, 1664525) + 1013904223) >>> 0) / 4294967296;
    const out = [];
    for (const s of seaSample(g, this.me, 64, rnd)) if (s.o >= 0 && g.alive[s.o] && this.person(g, s.o) && !this.isProtectedSquadMate(g, s.o) && !out.includes(s.o)) out.push(s.o);
    this.seaP = out;
    return out;
  }

  amount(g, q, avail, need, min) {
    const a = this.amount0(g, q, avail, need, min);
    const s = this.p.idleSafe;
    if (!(s > 0) || !this.idle(g)) return a;
    const me = this.me, bal = g.bal[me], perPx = this.price(g, q);
    const safe = (bal - iV(12 * bal, 1024) - s * 100 * g.terr[me]) / (1 + (100 * s) / perPx);
    const ring = g.hasAttack(me, q) ? 0 : this.cnt[q] * perPx;
    return safe >= ring ? Math.min(a, safe) : 0;
  }

  boatOut(g, floorAt, maxEff) {
    const s = this.p.idleSafe;
    if (!(s > 0) || !this.idle(g)) return super.boatOut(g, floorAt, maxEff);
    const keep = s * 100 * g.terr[this.me] + iV(32 * g.bal[this.me], 1024);
    return super.boatOut(g, (price) => Math.max(floorAt(price), keep), maxEff);
  }

  amount0(g, q, avail, need, min) {
    const P = this.p;
    if (this.food(g, q)) {
      const top = g.t < P.dpEnd ? P.dpSpend * g.bal[this.me] - iV(12 * g.bal[this.me], 1024) : Infinity;
      if (!this.person(g, q)) return this.waitDump(g, q) ? 0 : Math.min(P.sendFrac * avail, top, Math.max(P.foodK * need + 3 * this.cnt[q], min));
      const out = g.totalAttackTroops(q) - g.attackTroopsOn(q, this.me);
      if (!(P.preyK > 0)) return Math.min(P.sendFrac * avail, Math.max(P.foodK * (need + out) + 3 * this.cnt[q], min));
      const want = Math.max(P.preyK * (need + out) + 3 * this.cnt[q], min);
      return P.sendFrac * avail >= want ? want : 0;
    }
    if (P.pKill > 0 && this.person(g, q)) {
      const want = P.pKill * need + 3 * this.cnt[q];
      return avail >= want ? Math.max(want, min) : 0;
    }
    if (P.idleLo > 0 && this.idle(g)) return avail;
    if (this.person(g, q)) {
      const m = this.motive(g, q);
      if (m === null) return P.sendFrac * avail >= P.preyKill * need ? Math.min(P.sendFrac * avail, Math.max(1.25 * need + 3 * this.cnt[q], min)) : 0;
      if (m === 'idle' && P.idleKill > 0 && P.sendFrac * avail < P.idleKill * need) return 0;
      if (this.duelOn(g)) {
        const T = Math.max(g.terr[this.me], 1);
        const dQ = (g.bal[q] + g.attackTroopsOn(q, this.me)) / Math.max(g.terr[q], 1);
        if (dQ <= P.duelK * (g.bal[this.me] / T)) return this.duelSend(g, q, need, min);
      }
    }
    return super.amount(g, q, avail, need, min);
  }

  spawnDist(g, dist) {
    const off = this.p.botOff;
    if (!(off > 0)) return super.spawnDist(g, dist);
    if (!this.dBot || this.dBot.length !== g.N) this.dBot = new Int32Array(g.N);
    const dB = super.spawnDist(g, this.dBot, (o) => g.isBot(o));
    super.spawnDist(g, dist, (o) => !g.isBot(o));
    for (let i = g.N - 1; i >= 0; i--) {
      const b = dB[i];
      if (b >= 0 && (dist[i] < 0 || b + off < dist[i])) dist[i] = b + off;
    }
    return dist;
  }

  expandNeutral(g, spend) {
    if (g.t < this.p.dpEnd) return this.dpNeutral(g);
    if (this.p.nFloor > 0) spend = Math.min(spend, g.bal[this.me] - this.reserve(g, 2));
    if (this.p.pplK > 0 || this.p.hungryK > 0) spend = Math.min(spend, g.bal[this.me] - this.peopleFloor(g));
    if (this.p.safeP > 0) spend = Math.min(spend, g.bal[this.me] - this.p.safeP * this.peopleSafe(g));
    super.expandNeutral(g, spend);
  }

  // The rent cycle's land command on free land (see dpEnd), once the rings
  // it pays for would no longer all land by tick 98 from the next act tick.
  dpNeutral(g) {
    const P = this.p, me = this.me, cyc = Math.floor(g.t / 100);
    if (this.dpCyc === cyc) return;
    const bal = g.bal[me], u = g.t % 100;
    const fee = iV(12 * bal, 1024);
    const max = Math.min(P.dpSpend * bal, bal - this.dpKeep(g)) - fee;
    if (!(max > 0)) return;
    const rings = this.dpRings(g, u);
    let n = 0, sum = 0;
    for (const { r } of rings) {
      if (2 * (sum + r) + r > max) break;
      sum += r;
      n++;
    }
    if (n === 0) return;
    let later = 0;
    for (const { at } of rings) if (at + P.period <= 98) later++;
    if (later >= n) return;
    const X = 2 * sum + rings[n - 1].r;
    if (X < this.minCmd(g)) return;
    if (this.send(g, NEUTRAL, X)) {
      this.dpCyc = cyc;
      if (typeof window !== "undefined" && window.__hlLog) {
        window.__hlLog(`[HL-OPENING] t=${g.t} cyc=${cyc} DP expand rings=${n} spend=${Math.round(X)}/${bal} terr=${g.terr[me]}`);
      }
    }
  }

  // Breadth-first layers of free land from our border with the tick of the
  // rent cycle each lands at for a command at tick u of the cycle, while
  // that is at most 98.
  dpRings(g, u) {
    const N = g.N, px = g.px, d = g.dir4, me = this.me;
    if (!this.dpQ || this.dpQ.length !== N) {
      this.dpQ = new Int32Array(N);
      this.dpMark = new Uint32Array(N);
      this.dpSt = 0;
    }
    const q = this.dpQ, mark = this.dpMark, st = ++this.dpSt;
    let h = 0, e = 0;
    const B = g.border[me];
    for (let i = B.length - 1; i >= 0; i--) {
      for (let k = 0; k < 4; k++) {
        const c = B[i] + d[k];
        if (px[c] === T_LAND && mark[c] !== st) {
          mark[c] = st;
          q[e++] = c;
        }
      }
    }
    const out = [];
    let L = g.terr[me], at = u + 7;
    while (h < e && at <= 98) {
      const end = e;
      out.push({ r: end - h, at });
      at += L < 1e3 ? 4 : L < 1e4 ? 3 : L < 6e4 ? 2 : 1;
      L += end - h;
      for (; h < end; h++) {
        const c = q[h];
        for (let k = 0; k < 4; k++) {
          const x = c + d[k];
          if (px[x] === T_LAND && mark[x] !== st) {
            mark[x] = st;
            q[e++] = x;
          }
        }
      }
    }
    return out;
  }

  // Troops at home below which the strongest neighbour person (its troops
  // on us counted) collapses us with its whole balance.
  dpKeep(g) {
    const me = this.me;
    let m = 0;
    for (const q of this.nb) if (g.alive[q] && this.person(g, q)) m = Math.max(m, g.bal[q] + g.attackTroopsOn(q, me));
    return Math.max(0, (m - 1.5 * g.terr[me]) / 1.78);
  }

  // Whether bot q may be bought now (see dpLand, aiFrom, winR).
  botOk(g, q) {
    const P = this.p;
    if (g.t >= P.dpEnd) return true;
    if (g.t < P.aiFrom) return false;
    if (P.winR > 0 && this.botPx(g, q) > this.winWorth(g)) return false;
    return !(P.dpLand > 0) || this.botPx(g, q) <= this.dpValue(g.t);
  }

  // Per pixel of bot q when collapsed (the quarter left neutral taken at 2).
  botPx(g, q) {
    return 2 + (1.78 * g.bal[q]) / Math.max(1, g.terr[q]);
  }

  // Troops a pixel is worth for winning now (see winR).
  winWorth(g) {
    const me = this.me;
    return (this.p.winR * g.t * g.bal[me]) / Math.max(1, g.terr[me]);
  }

  // Balance kept before dpEnd when buying bot q (see winR): the troop
  // density at which its land stops paying, dpKeep, and the balance at
  // which no neighbouring bot prefers us as its target (once per tick).
  winFloor(g, q) {
    if (this.sbT !== g.t) {
      this.sbT = g.t;
      this.sb = this.safeFinite(g);
    }
    const me = this.me;
    return Math.max((this.botPx(g, q) * g.terr[me]) / (this.p.winR * Math.max(1, g.t)), this.dpKeep(g), this.sb);
  }

  // safeBalance over the bots that border someone other than us: a bot
  // that borders only us takes us whatever we keep.
  safeFinite(g) {
    const me = this.me;
    let safe = 0;
    for (const q of this.nb) {
      if (g.alive[q] === 0 || !g.isBot(q) || !g.hasFreeSlot(q) || g.hasAttack(q, me)) continue;
      const th = this.threatOf(g, q);
      if (th.neutral || !Number.isFinite(th.minOther)) continue;
      safe = Math.max(safe, th.minOther - g.attackTroopsOn(me, q));
    }
    return safe;
  }

  // Price per pixel up to which land bought at tick t beats troops held
  // until dpEnd (see dpLand); per 10 ticks, built backwards from dpEnd
  // (interest comes before the rent at tick 99 of the 100).
  dpValue(t) {
    const P = this.p;
    if (!this.dpVal) {
      this.dpVal = new Float64Array(Math.ceil(P.dpEnd / 10) + 1);
      let G = 1, rents = 0;
      for (let k = P.dpEnd - 1; k >= 0; k--) {
        if (k % 100 === 99) rents += G;
        if (k % 10 === 9) G *= 1 + Math.max(iV(100 * (13440 - 6 * k), 1920), 100) / 1e4;
        if (k % 10 === 0) this.dpVal[k / 10] = (P.dpLand + rents) / G;
      }
    }
    return this.dpVal[Math.min(this.dpVal.length - 1, Math.floor(t / 10))];
  }

  analyze(g) {
    super.analyze(g);
    if (this.p.botWait > 0) this.watchDumps(g);
  }

  // Last dump (a drop of its balance to under a tenth) and the ticks between
  // dumps of every bot, watched before we border it. A gap of over 1.5
  // cycles is a skipped dump (no free target), not a slower bot.
  watchDumps(g) {
    if (!this.dumps) this.dumps = new Map();
    for (let i = g.aliveCount - 1; i >= 0; i--) {
      const q = g.aliveList[i];
      if (!g.isBot(q)) continue;
      const b = g.bal[q], d = this.dumps.get(q);
      if (!d || g.t - d.seen > 2 * this.p.period) {
        this.dumps.set(q, { bal: b, seen: g.t, at: -1, every: d ? d.every : 104 });
        continue;
      }
      if (b < 0.1 * d.bal) {
        const gap = g.t - d.at;
        if (d.at >= 0 && gap >= d.every / 2 && gap <= 1.5 * d.every) d.every = gap;
        d.at = g.t;
      }
      d.bal = b;
      d.seen = g.t;
    }
  }

  // Whether bot q is better bought after its next dump. Dumps are seen on
  // our own 5-tick grid, so the one expected is awaited 2 periods past
  // its time before giving up on it.
  waitDump(g, q) {
    const P = this.p, me = this.me;
    if (!(P.botWait > 0)) return false;
    const d = this.dumps?.get(q);
    if (!d || d.at < 0) return false;
    const w = d.at + d.every - g.t;
    if (w <= -2 * P.period || g.bal[me] >= 100 * g.terr[me]) return false;
    for (const o of g.attackersOf(q)) if (o !== me && !g.isBot(o)) return false;
    const T = g.terr[q], x = Math.min(1, iV(g.peak[q], 4) / Math.max(T, 1));
    return 0.98 * 2 * g.bal[q] * (1 - Math.pow(x, 1.6)) > (T * Math.max(w, 0)) / 100;
  }

  elimCost(g, q) {
    const c = super.elimCost(g, q);
    if (!(this.p.botRegen > 0) || this.person(g, q)) return c;
    return c + (this.p.botRegen * 1.25 * g.terr[q] * this.attackTicks(g, q)) / 100;
  }

  // Ticks for our attack to take 3/4 of q's land.
  attackTicks(g, q) {
    const L = g.terr[this.me], T = g.terr[q];
    const perStep = L < 1e3 ? 4 : L < 1e4 ? 3 : L < 6e4 ? 2 : 1;
    return (perStep * 0.75 * T) / Math.max(this.cnt[q], Math.sqrt(T), 1);
  }

  // Balance kept at home when buying cheap land at `price` per pixel.
  reserve(g, price) {
    const P = this.p;
    if (P.byRate > 0 && price * this.baseRate(g) < 0.1) return 0;
    return (g.t < P.raceEnd ? P.raceK : 1) * P.nFloor * 100 * g.terr[this.me];
  }

  // Our interest per 10 ticks on a balance below the soft cap
  // (Game.interestRate without the cut above the cap).
  baseRate(g) {
    const i = iV(511 * g.terr[this.me], g.land);
    let n1 = 100 + Math.sqrt((25600 * i) / 508);
    if (g.t < 1920) n1 = Math.max((100 * (13440 - 6 * g.t)) / 1920, n1);
    return Math.min(n1, 700) / 1e4;
  }

  targetBias(g, q) {
    const P = this.p;
    let k = super.targetBias(g, q);
    if (P.contestW !== 1 && !this.person(g, q) && this.contested(g, q)) k *= P.contestW;
    if (P.reachW !== 1 && this.person(g, q) && !this.food(g, q) && this.outOfReach(g, q)) k *= P.reachW;
    if ((P.focusW !== 1 || P.focusX !== 1) && this.person(g, q) && !this.food(g, q)) {
      const f = this.focusOf(g);
      if (f >= 0) k *= q === f ? P.focusW : P.focusX;
    }
    return k;
  }

  // The person we are at war with (see focusW): the neighbour person we hit
  // last, within focusT ticks (our sends on people are single strikes over
  // before the next one), the most troops on it breaking ties (-1: none).
  focusOf(g) {
    if (this.focusAt === g.t) return this.focusQ;
    const me = this.me;
    let q = -1, last = g.t - this.p.focusT, most = -1;
    for (const o of this.nb) {
      if (g.alive[o] === 0 || g.terr[o] === 0 || !this.person(g, o)) continue;
      const t = this.hitTo.get(o) ?? -1e9;
      const x = g.attackTroopsOn(me, o);
      if (t > last || (t === last && x > most)) {
        q = o;
        last = t;
        most = x;
      }
    }
    this.focusQ = q;
    this.focusAt = g.t;
    return q;
  }

  // Whether collapsing person q costs more than reachK x our whole balance:
  // troops spent on it buy land at its full price and draw its grudge, while
  // a person we can finish leaves a quarter of its land neutral and nobody
  // to hit back.
  outOfReach(g, q) {
    const me = this.me;
    const need = this.elimCost(g, q) + g.attackTroopsOn(q, me) - g.attackTroopsOn(me, q);
    return need > this.p.reachK * g.bal[me];
  }

  // Whether a person other than us borders q (long borders are sampled).
  contested(g, q) {
    const B = g.border[q], px = g.px, own = g.own, d = g.dir4, me = this.me;
    const n = B.length;
    const step = n > 512 ? Math.ceil(n / 512) : 1;
    for (let i = n - 1; i >= 0; i -= step) {
      const b = B[i];
      for (let k = 0; k < 4; k++) {
        const c = b + d[k];
        if (px[c] < P_INNER) continue;
        const o = own[c];
        if (o !== q && o !== me && g.alive[o] && !g.isBot(o)) return true;
      }
    }
    return false;
  }
}


const P17 = {
  coreFrom: 1500,
  chunk: 0.2,
  safeW: 0,
  killW: 1,
  maxW: 0.5,
  pplKill: 0,
  surplus: 1,
  hold: 0.9,
  growth: 1,
  post: 1,
  floorCap: 0,
  killF: 0,
  seaFree: 1,
  seaSafe: 0,
  botSkip: 0,
  postKill: 0,
  peerMax: 0,
  winT: [[1500, 3], [2000, 2.85], [2500, 1.8]],
};

class V17 extends V13 {
  constructor(params = {}, me = 0) {
    super({ ...P17, ...params }, me);
  }

  act(g) {
    const P = this.p, me = this.me;
    if (g.t < P.coreFrom) return super.act(g);
    if (!g.canAct(me) || g.t % P.period !== 0) return;
    this.analyze(g);
    if (typeof window !== "undefined" && window.__hlLog && g.t > 0 && g.t % 90 === 0 && this._lastTickLog !== g.t) {
      this._lastTickLog = g.t;
      const pf = window.__hlPerf;
      const pfStr = pf && pf.ticks > 0 ? ` avgMs=${(pf.totalMs / pf.ticks).toFixed(2)} maxMs=${pf.maxMs.toFixed(1)} skip=${pf.skippedTicks}` : "";
      window.__hlLog(`[HL-TICK] t=${g.t} terr=${g.terr[me]}(${(100 * g.terr[me] / Math.max(1, g.land)).toFixed(1)}%) bal=${g.bal[me]} dens=${(g.bal[me] / Math.max(1, g.terr[me])).toFixed(1)} nb=${this.nb.length} neut=${this.neutral} cmds=${this.cmds} boats=${this.boats}${pfStr}`);
    }
    this.tryPeaceVote(g);
    if (this.tryEmergencyBossRescue(g) && g.online) return;
    this.updateGrudges(g);
    this.updateWars(g);
    const n = this.cmds;
    if (this.neutral > 0) this.expandNeutral(g, g.bal[me] - this.safeAt(g, -1));
    this.buyLand(g);
    if (this.cmds === n) this.idleBoats(g);
  }

  // Safety floor (see above), for buying the land of q (-1: none).
  safeAt(g, q) {
    const P = this.p;
    const person = q >= 0 && this.person(g, q);
    let s = this.safeFinite(g, P.botSkip > 0 && q >= 0 && !person ? q : -1);
    const around = P.postKill > 0 && q >= 0 ? this.peopleOf(g, q) : null;
    if (P.killF > 0) s = Math.max(s, this.killKeep(g, P.killF, around));
    else if (P.killW > 0) s = Math.max(s, P.killW * (around ? this.killKeep(g, 1, around) : this.dpKeep(g)));
    if (P.safeW > 0) s = Math.max(s, P.safeW * this.peopleSafe(g, person ? q : -1));
    if (P.floorCap > 0) s = Math.min(s, P.floorCap * 100 * g.terr[this.me]);
    return s;
  }

  // Balance at which no neighbour person collapses us with f x its troops
  // (its troops on us counted in full; collapse costs 1.5 L + 1.78 B). With
  // postKill > 0 the people around the land bought (`around`) count too:
  // they border us once it is ours (in mvy2yww4 the land of bot36 made the
  // giant bot68 our neighbour).
  killKeep(g, f, around = null) {
    const me = this.me;
    let m = 0;
    for (const q of this.nb) if (g.alive[q] && this.person(g, q)) m = Math.max(m, f * g.bal[q] + g.attackTroopsOn(q, me));
    if (around) for (const o of around) if (o !== me && g.alive[o]) m = Math.max(m, f * g.bal[o] + g.attackTroopsOn(o, me));
    return Math.max(0, (m - 1.5 * g.terr[me]) / 1.78);
  }

  // Balance at which no neighbouring bot finds us its weakest neighbour,
  // bot `skip` left out (botSkip: the bot we buy is not there afterwards;
  // otherwise a bot next to a big person locks the floor at that person's
  // troops and keeps us from buying the bot that sets it).
  safeFinite(g, skip = -1) {
    if (skip < 0) return super.safeFinite(g);
    const me = this.me;
    let safe = 0;
    for (const q of this.nb) {
      if (q === skip || g.alive[q] === 0 || !g.isBot(q) || !g.hasFreeSlot(q) || g.hasAttack(q, me)) continue;
      const th = this.threatOf(g, q);
      if (th.neutral || !Number.isFinite(th.minOther)) continue;
      safe = Math.max(safe, th.minOther - g.attackTroopsOn(me, q));
    }
    return safe;
  }

  // Land neighbours, cheapest per pixel first: [{ q, c, need }] (need:
  // troops to collapse it).
  offers(g) {
    const P = this.p, me = this.me;
    let active = 0;
    const base = g.slotBase(me);
    for (let i = g.atkCount[me] - 1; i >= 0; i--) if (g.atkTarget[base + i] !== NEUTRAL) active++;
    const fee = iV(12 * g.bal[me], 1024);
    const out = [];
    for (const q of this.nb) {
      if (!g.alive[q] || !g.terr[q]) continue;
      if (!g.hasAttack(me, q) && (active >= P.maxTargets || !g.hasFreeSlot(me))) continue;
      const need = this.elimCost(g, q) + g.attackTroopsOn(q, me) - g.attackTroopsOn(me, q);
      if (need <= 0) continue;
      const left = iV(g.peak[q], 4);
      const share = Math.min(1, this.cnt[q] / Math.max(1, g.border[q].length));
      out.push({ q, need, c: (need + fee) / Math.max(1, g.terr[q] - left + left * P.shareW * share) });
    }
    return out.sort((a, b) => a.c - b.c);
  }

  // One send at the cheapest offer that takes one (see the head comment).
  buyLand(g) {
    const P = this.p, me = this.me;
    const B = g.bal[me], L = Math.max(1, g.terr[me]), fee = iV(12 * B, 1024);
    const m = P.maxW * this.winRatio(g.t), worth = (m * B) / L, over = P.surplus > 0 && B > 100 * L;
    const cheap = P.growth > 0 ? 0.1 / this.baseRate(g) : 0;
    for (const { q, c, need } of this.offers(g)) {
      if (c >= worth && c >= cheap && !over) break;
      const person = this.person(g, q);
      const safe = this.safeAt(g, q);
      let keep = Infinity;
      if (c < cheap) keep = 0;
      if (c < worth) keep = Math.min(keep, P.post > 0 ? B - fee - (m * (B - fee) - c * L) / (1 + m) : (c * L) / m);
      if (over) keep = Math.min(keep, P.hold * 100 * L);
      keep = Math.max(keep, safe);
      if (!person && g.hasAttack(me, q) && (!g.hasAttack(q, me) || g.attackTroopsOn(me, q) >= 0.35 * need)) continue;
      const want = 1.25 * need + 3 * this.cnt[q];
      const x = Math.min(B - fee - keep, want);
      if (x < this.minCmd(g) || (x < want && (x < P.chunk * B || (P.pplKill > 0 && person)))) continue;
      if (P.peerMax > 0 && person && x < want && g.bal[q] >= P.peerMax * B && !g.hasAttack(me, q) && !g.hasAttack(q, me)) continue;
      return this.send(g, q, x);
    }
    return false;
  }

  // Land a boat can take at each unowned pixel (see seaFree; v13: the size
  // of its land mass).
  compSize(g) {
    if (!(this.p.seaFree > 0) || g.t < this.p.coreFrom) return super.compSize(g);
    if (this.freeAt === g.t) return this.freeComp;
    const N = g.N, px = g.px, own = g.own, d = g.dir4, me = this.me;
    const c = this.freeComp?.length === N ? this.freeComp.fill(0) : new Int32Array(N);
    const seen = new Uint8Array(N), q = new Int32Array(N);
    for (let s = 0; s < N; s++) {
      if (px[s] !== T_LAND || seen[s]) continue;
      let h = 0, t = 0, taken = false;
      q[t++] = s;
      seen[s] = 1;
      while (h < t) {
        const a = q[h++];
        for (let k = 0; k < 4; k++) {
          const n = a + d[k];
          if (n < 0 || n >= N) continue;
          const v = px[n];
          if (v === T_LAND) {
            if (!seen[n]) {
              seen[n] = 1;
              q[t++] = n;
            }
          } else if (v >= P_INNER && own[n] !== me) taken = true;
        }
      }
      if (!taken) for (let i = 0; i < t; i++) c[q[i]] = t;
    }
    this.freeAt = g.t;
    this.freeComp = c;
    return c;
  }

  floors(g) {
    const r = super.floors(g);
    if (!(this.p.seaSafe > 0) || g.t < this.p.coreFrom) return r;
    const s = this.safeAt(g, -1);
    return { ...r, floorAt: (price) => Math.max(r.floorAt(price), s) };
  }

  // Boats when no land is bought, as v13: food over water, then idle troops.
  idleBoats(g) {
    const P = this.p, me = this.me;
    if (P.boatFood > 0 && this.boatFood(g)) return;
    if (this.neutral > 0 || g.t - this.lastBoat < P.boatEvery) return;
    if (this.nb.length && g.bal[me] < P.idleCap * 100 * g.terr[me]) return;
    const { floorAt } = this.floors(g);
    this.boatOut(g, floorAt, P.boatFee > 0 && this.nb.length ? P.boatFee * this.minNbPrice(g) : Infinity);
  }

  // Land / troops weight for winning at tick t (winR before winT[0][0], then
  // winT, linear in between, flat after).
  winRatio(t) {
    const T = this.p.winT;
    if (!T || !T.length || t < T[0][0]) return this.p.winR * Math.max(1, t);
    for (let i = 1; i < T.length; i++) {
      if (t <= T[i][0]) return T[i - 1][1] + ((T[i][1] - T[i - 1][1]) * (t - T[i - 1][0])) / (T[i][0] - T[i - 1][0]);
    }
    return T[T.length - 1][1];
  }

  winWorth(g) {
    const me = this.me;
    return (this.winRatio(g.t) * g.bal[me]) / Math.max(1, g.terr[me]);
  }
}


function trip(d, troops, t0) {
  const len = Math.max(16 * Math.round(d), 1);
  let prog = 0, v = troops;
  for (let t = t0; ; t++) {
    if (prog === 65535) return { ticks: t - t0, troops: v };
    const speed = 25e4 + Math.min(20 * v, 3e5) + Math.min(v >> 3, 5e4);
    prog = Math.min(prog + Math.max(~~((speed + 0.5) / len), 1), 65535);
    if (t % 5 === 3) v = Math.max(v - Math.max(1, v >> 7), 0);
    if (v === 0) return null;
  }
}

function troopsFor(need, d, t0) {
  need = Math.max(1, need);
  let lo = Math.max(60, need), hi = 2 * lo + 200;
  while ((trip(d, hi, t0)?.troops ?? 0) < need) {
    hi *= 2;
    if (hi > 2e9) return null;
  }
  while (lo < hi) {
    const m = Math.floor((lo + hi) / 2);
    if ((trip(d, m, t0)?.troops ?? 0) >= need) hi = m;
    else lo = m + 1;
  }
  return lo;
}

// Unified Sea & Cross-Sea Blitzkrieg Module (`strategy/sea-core.js`)
//
// Implements the 3-part architecture specified by the admin (#2457-#2509 & #3475):
//
// 1. Independent Stepping-Stone Island Line (`frogHopStep`):
//    - Completely independent branch (never increments `this.cmds`, never blocks land or other boat actions).
//    - Because troops in `bal[me]` can be deployed from ANY pixel we own on the map (#2477), owning
//      an island makes it a 100% functional launchpad (`g.coast[me]`), PROVIDED all pixels on that island
//      are conquered so `refreshBorder` (`sim/game.js:953`) promotes them from `border[me]` into `coast[me]` (#3475)!
//    - Targets small islands (`1-22` px, smaller is strictly better!) from near to far,
//      including both unowned islands AND small bot-occupied islands (#2477: "有人机就顺势把人机岛占掉"),
//      carrying enough troops (`2 * isle.size + 10` or `2.1 * bal[bot] + 2 * terr[bot] + 16`) to conquer 100%
//      of the island in one shot so it immediately enters `g.coast[me]`.
//
// 2. Bridgehead-Only Landing ("桥头堡只是登陆的手段，登陆只用桥头堡" #2509):
//    - Boats NEVER carry the main army across water! Whether landing on a large neutral island, a cross-sea
//      AI bot, or a cross-sea human, boats only carry a minimal bridgehead vanguard (enough to take 1-3 beach pixels).
//    - Checked EVERY SINGLE TICK (`g.t % 1 === 0`, 0-tick delay!): the exact tick a bridgehead boat lands
//      and establishes a 1-3 px land border (`this.neutral > 0` or `this.cnt[q] > 0`), the main army teleports
//      directly from home `bal[me]` via land attack (`expandNeutral` or `g.attack`) with 0% sea decay!
//
// 3. Multi-Bridgehead Coastal Coverage -> Main Land Assault + Dynamic `P_BORDER` Re-Ignite (#2470 / #2501 / #7):
//    - For BOTH cross-sea targets (`cnt[q] === 0`) AND narrow-front land neighbours (`cnt[q] < 32` with reachable coast):
//      first launches 1-3 small bridgehead boats spaced >= 22 px apart along `q`'s coastline from our nearby
//      stepping-stone islands/coast; once those coastal bridgeheads touch shore and widen the contact
//      surface area, fires the main land attack across all fronts simultaneously!


const DX = [0, 1, 1, 1, 0, -1, -1, -1];
const DY = [-1, -1, 0, 1, 1, 1, 0, -1];

const mapIsleCache = new WeakMap();

// Precompute 1-30 px island components and their water adjacency graph once per map.
function getMapIsles(g, maxIsleSize = 30, maxHopWater = 80, doorRadius = 35) {
  if (!g.map || !g.px) return null;
  let cached = mapIsleCache.get(g.map);
  if (cached) return cached;

  const W = g.W, N = g.N, d4 = g.dir4;
  const type = g.map.type ?? g.px;
  const isLand = (i) => type[i] === T_LAND || type[i] >= P_INNER || type[i] === 3;
  const isWater = (i) => type[i] === T_WATER;

  const comp = new Int32Array(N).fill(-1);
  const sizes = [];
  const stack = new Int32Array(N);

  for (let s = 0; s < N; s++) {
    if (comp[s] >= 0 || !isLand(s)) continue;
    const id = sizes.length;
    let n = 0, sp = 0;
    stack[sp++] = s;
    comp[s] = id;
    while (sp) {
      const c = stack[--sp];
      n++;
      const x = c % W;
      if (c >= W && comp[c - W] < 0 && isLand(c - W)) { comp[c - W] = id; stack[sp++] = c - W; }
      if (c + W < N && comp[c + W] < 0 && isLand(c + W)) { comp[c + W] = id; stack[sp++] = c + W; }
      if (x > 0 && comp[c - 1] < 0 && isLand(c - 1)) { comp[c - 1] = id; stack[sp++] = c - 1; }
      if (x < W - 1 && comp[c + 1] < 0 && isLand(c + 1)) { comp[c + 1] = id; stack[sp++] = c + 1; }
    }
    sizes.push(n);
  }

  const pixToIsle = new Int32Array(N).fill(-1);
  const islePixMap = new Map();
  for (let i = 0; i < N; i++) {
    const m = comp[i];
    if (m >= 0 && sizes[m] <= maxIsleSize) {
      if (!islePixMap.has(m)) islePixMap.set(m, []);
      islePixMap.get(m).push(i);
    }
  }

  const isles = [];
  for (const [m, pix] of islePixMap) {
    let landPix = -1, waterPix = -1, dir = -1;
    const shores = [];
    for (const c of pix) {
      const x = c % W;
      for (let k = 0; k < 4; k++) {
        if ((k === 1 && x === 0) || (k === 3 && x === W - 1)) continue;
        const w = c - d4[k];
        if (w >= 0 && w < N && isWater(w)) {
          if (waterPix < 0) {
            landPix = c;
            waterPix = w;
            dir = k;
          }
          shores.push({ landPix: c, waterPix: w, dir: k });
          break;
        }
      }
    }
    if (waterPix < 0) continue;
    const idx = isles.length;
    isles.push({ idx, compId: m, size: sizes[m], pix, landPix, waterPix, dir, shores });
    for (const p of pix) pixToIsle[p] = idx;
  }

  const dist = new Int32Array(N).fill(-1);
  cached = { isles, pixToIsle, dist, comp, sizes };
  mapIsleCache.set(g.map, cached);
  return cached;
}

function medianHumanDensity(g) {
  const H = g.humans;
  const ds = [];
  for (let p = 0; p < H; p++) {
    if (g.alive[p] && g.terr[p] >= 100 && !g.isBot(p)) {
      ds.push(g.bal[p] / g.terr[p]);
    }
  }
  if (!ds.length) return 1;
  ds.sort((a, b) => a - b);
  return ds[ds.length >> 1];
}

// 1. Independent Stepping-Stone Island Line (`frogHopStep`):
// - CRITICAL ENGINE RULE (`sim/game.js:953 refreshBorder`, #3475): A conquered pixel on an island ONLY enters
//   `g.coast[me]` (making it usable by `nearestCoast` as a boat launchpad) when it has ZERO adjacent
//   hostile/unowned pixels (`!this.hostileTo(c, p)`).
// - Therefore, every stepping-stone island must be completely unowned or occupied by a small AI bot (`terr <= 18, bal <= 220`)
//   that we wipe out 100% in one shot (`needTroops = max(2 * isle.size + 10, 2.1 * bal[o] + 2 * terr[o] + 16)`),
//   guaranteeing the entire island promotes into `g.coast[me]`!
function frogHopStep(g, me, state, opts = {}) {
  const maxHopWater = opts.maxHopWater ?? 85;
  const maxIsleSize = opts.maxIsleSize ?? 22;
  const maxHopBoats = opts.maxHopBoats ?? 2;
  if (!g.boatsAllowed || !g.boatsAllowed(me)) return false;
  if (g.boatCount[me] >= (opts.maxTotalBoats ?? 5)) return false;

  const mapData = getMapIsles(g, 30, maxHopWater, opts.doorRadius ?? 35);
  if (!mapData || !mapData.isles.length) return false;
  const { isles, pixToIsle, dist } = mapData;

  state.inFlightIsles ??= new Map();
  let activeHops = 0;
  for (const [idx, expT] of state.inFlightIsles) {
    if (g.t >= expT) state.inFlightIsles.delete(idx);
    else activeHops++;
  }
  if (activeHops >= maxHopBoats) return false;

  const B = g.bal[me];
  const fee = iV(32 * B, 1024);
  if (B < 120) return false;

  const px = g.px, own = g.own, W = g.W, N = g.N, d4 = g.dir4;

  const isOurIsle = new Uint8Array(isles.length);
  const canStepIsle = new Uint8Array(isles.length);
  let anyCanStep = false;
  for (let i = 0; i < isles.length; i++) {
    if (state.inFlightIsles.has(i)) continue;
    const isle = isles[i];
    let hasOurs = false;
    for (const p of isle.pix) {
      if (px[p] >= P_INNER && own[p] === me) {
        hasOurs = true;
        break;
      }
    }
    if (hasOurs) {
      isOurIsle[i] = 1;
      continue;
    }
    if (isle.size > maxIsleSize) continue;
    // Valid stepping stone if the island is completely unowned (`T_LAND`) or occupied by a small AI bot
    // that we can wipe out in one shot (#2477 & #3475: "有人机就顺势把人机岛占掉" + "跳板岛注意要小要占全")!
    let allValid = true;
    for (const p of isle.pix) {
      if (px[p] === T_LAND) continue;
      if (px[p] >= P_INNER) {
        const o = own[p];
        if (o !== me && g.alive[o] && g.isBot(o) && g.terr[o] <= 18 && g.bal[o] <= 220) continue;
      }
      allValid = false;
      break;
    }
    if (allValid) {
      canStepIsle[i] = 1;
      anyCanStep = true;
    }
  }
  if (!anyCanStep) return false;

  const C = g.coast[me];
  if (!C || !C.length) return false;
  const maxCost = Math.ceil(5 * maxHopWater);
  const visited = [];
  const buckets = [[]];
  const stride = C.length > 320 ? (C.length >> 8) + 1 : 1;
  for (let i = C.length - 1; i >= 0; i -= stride) {
    const c = C[i], x = c % W;
    for (let k = 0; k < 4; k++) {
      if ((k === 1 && x === W - 1) || (k === 3 && x === 0)) continue;
      const w = c + d4[k];
      if (w >= 0 && w < N && px[w] === T_WATER && dist[w] < 0) {
        dist[w] = 0;
        visited.push(w);
        buckets[0].push(w);
      }
    }
  }

  // Find shortest water hop from our current coast/islands to each candidate stepping-stone island
  const firstHop = new Map(); // isleIdx -> { d, waterPix, dir, landPix }
  for (let cost = 0; cost < buckets.length && cost <= maxCost; cost++) {
    const b = buckets[cost];
    if (!b) continue;
    for (const w of b) {
      if (dist[w] !== cost) continue;
      const x = w % W;
      for (let k = 0; k < 4; k++) {
        if ((k === 1 && x === W - 1) || (k === 3 && x === 0)) continue;
        const n = w + d4[k];
        if (n >= 0 && n < N) {
          const idx = pixToIsle[n];
          if (idx >= 0 && canStepIsle[idx] && !firstHop.has(idx)) {
            let okShore = false;
            if (px[n] === T_LAND) okShore = true;
            else if (px[n] >= P_INNER) {
              const o = own[n];
              if (o !== me && g.alive[o]) {
                const doDens = g.bal[o] / Math.max(1, g.terr[o]);
                if (g.isBot(o) ? doDens < 25 : doDens < 8) okShore = true;
              }
            }
            if (okShore) {
              firstHop.set(idx, { d: cost / 5, waterPix: w, dir: k, landPix: n });
            }
          }
        }
      }
      for (let g8 = 0; g8 < 8; g8++) {
        const dx = DX[g8];
        if ((x === 0 && dx < 0) || (x === W - 1 && dx > 0)) continue;
        const n = w + DY[g8] * W + dx;
        if (n < 0 || n >= N || px[n] !== T_WATER) continue;
        const nc = cost + (g8 & 1 ? 7 : 5);
        if (nc > maxCost || (dist[n] >= 0 && dist[n] <= nc)) continue;
        if (dist[n] < 0) visited.push(n);
        dist[n] = nc;
        (buckets[nc] ??= []).push(n);
      }
    }
  }
  for (const w of visited) dist[w] = -1;
  if (!firstHop.size) return false;

  // Rank candidate islands: strictly near-to-far + smaller-is-better (#2475: "岛越小越好 先距离近的 一点点往外推 这样顺路")
  let bestIdx = -1;
  let bestScore = -Infinity;
  for (const [idx, hop] of firstHop) {
    if (hop.d < 2) continue;
    const isle = isles[idx];
    const isUnowned = px[hop.landPix] === T_LAND;
    const score = (isUnowned ? 25 : 10) - hop.d * 1.5 - isle.size * 1.8;
    if (score > bestScore) {
      bestScore = score;
      bestIdx = idx;
    }
  }

  if (bestIdx < 0) return false;
  const isle = isles[bestIdx];
  const hop = firstHop.get(bestIdx);

  // Carry enough troops to conquer 100% of the small neutral/bot island in one shot
  // so all island pixels promote into `g.coast[me]` (#3475) and no leftover neutral/bot blocks `boatFood`!
  let needTroops = 2 * isle.size + 10;
  let hasBotOnIsle = false;
  for (const p of isle.pix) {
    if (px[p] >= P_INNER) {
      const o = own[p];
      if (o !== me && g.alive[o]) {
        hasBotOnIsle = true;
        needTroops = Math.max(needTroops, Math.ceil(2.1 * g.bal[o] + 2 * g.terr[o] + 16));
      }
    }
  }
  // Exploit #15 (`t % 51 === 45` 60-px bot boat-interception blind spot):
  // If the island has a bot and we are within 6 ticks before `t % 51 === 45`, wait until `t % 51 >= 46`!
  if (opts.botPhaseMode && hasBotOnIsle && hop.d <= 60) {
    const ticksToIntercept = (45 - (g.t % 51) + 51) % 51;
    if (ticksToIntercept <= 6) return false;
  }

  const sendTr = troopsFor(needTroops, hop.d, g.t);
  const safeFloor = opts.safeFloor ?? 0;
  if (sendTr === null || B - fee - sendTr < safeFloor) return false;

  // Cost-benefit gate ("算账再发"): a small stepping-stone island hop must only cost a few hundred troops
  // (`fee + sendTr <= maxAbsCost`, #2475: "就几百个兵 都不需要啥") so we never pay 35,000+ boat tax for a 2-px rock!
  const maxAbsCost = opts.maxAbsCost ?? 600;
  if (sendTr + fee > maxAbsCost) return false;

  const pct = Math.max(0, Math.min(1023, Math.ceil((sendTr * 1024) / B) - 1));
  const launched = g.boatTo ? g.boatTo(pct, hop.landPix, me, 12) : g.boat(pct, hop.waterPix, hop.dir, me);
  if (!launched) {
    state.inFlightIsles.set(bestIdx, g.t + 90);
    return false;
  }
  state.inFlightIsles.set(bestIdx, g.t + Math.ceil(hop.d * 2.5) + 40);
  return true;
}

// Helper: Find up to `maxSpots` well-spaced coastal landing spots (`>= minSpacing` px apart)
// on `targetQ`'s coastline within `maxWaterDist` water pixels of our `g.coast[me]` / stepping-stone islands!
function findCoastalBridgeheads(g, me, state, targetQ, opts = {}) {
  const maxWaterDist = opts.maxWaterDist ?? 35;
  const maxSpots = opts.maxSpots ?? 3;
  const minSpacing = opts.minSpacing ?? 22;
  const C = g.coast[me];
  if (!C || !C.length) return [];

  const mapData = getMapIsles(g, 30, 80, maxWaterDist);
  if (!mapData) return [];
  const { dist } = mapData;
  const W = g.W, N = g.N, px = g.px, own = g.own, d4 = g.dir4;

  // Collect existing contact points with `targetQ` (both our land border adjacent to `targetQ`
  // and any pending landing pixels on `targetQ`) so new bridgeheads are well-spaced!
  const existing = [];
  const Bd = g.border[me];
  for (let i = Bd.length - 1; i >= 0; i--) {
    const b = Bd[i], bx = b % W;
    for (let k = 0; k < 4; k++) {
      if ((k === 1 && bx === W - 1) || (k === 3 && bx === 0)) continue;
      const n = b + d4[k];
      if (n >= 0 && n < N && px[n] >= P_INNER && own[n] === targetQ) {
        existing.push(n);
        break;
      }
    }
  }
  const ph = state.pendingHandoffs.get(targetQ);
  if (ph?.landings) {
    for (const lp of ph.landings) if (lp >= 0) existing.push(lp);
  }
  const widenSpots = state.widenLandings?.get(targetQ);
  if (widenSpots) {
    for (const lp of widenSpots) if (lp >= 0) existing.push(lp);
  }

  const maxCost = Math.ceil(5 * maxWaterDist);
  const visited = [];
  const buckets = [[]];
  for (let i = C.length - 1; i >= 0; i--) {
    const c = C[i], x = c % W;
    for (let k = 0; k < 4; k++) {
      if ((k === 1 && x === W - 1) || (k === 3 && x === 0)) continue;
      const w = c + d4[k];
      if (w >= 0 && w < N && px[w] === T_WATER && dist[w] < 0) {
        dist[w] = 0;
        visited.push(w);
        buckets[0].push(w);
      }
    }
  }

  const spots = [];
  const minSpacing2 = minSpacing * minSpacing;
  for (let cost = 0; cost < buckets.length && cost <= maxCost && spots.length < maxSpots; cost++) {
    const b = buckets[cost];
    if (!b) continue;
    for (const w of b) {
      if (dist[w] !== cost) continue;
      const x = w % W;
      for (let k = 0; k < 4; k++) {
        if ((k === 1 && x === W - 1) || (k === 3 && x === 0)) continue;
        const n = w + d4[k];
        if (n >= 0 && n < N && px[n] >= P_INNER && own[n] === targetQ) {
          const nx = n % W, ny = (n - nx) / W;
          let farEnough = true;
          for (const ep of existing) {
            const ex = ep % W, ey = (ep - ex) / W;
            if ((nx - ex) * (nx - ex) + (ny - ey) * (ny - ey) < minSpacing2) {
              farEnough = false;
              break;
            }
          }
          if (farEnough) {
            spots.push({ d: cost / 5, waterPix: w, dir: k, landPix: n });
            existing.push(n);
            if (spots.length >= maxSpots) break;
          }
        }
      }
      if (spots.length >= maxSpots) break;
      for (let g8 = 0; g8 < 8; g8++) {
        const dx = DX[g8];
        if ((x === 0 && dx < 0) || (x === W - 1 && dx > 0)) continue;
        const n = w + DY[g8] * W + dx;
        if (n < 0 || n >= N || px[n] !== T_WATER) continue;
        const nc = cost + (g8 & 1 ? 7 : 5);
        if (nc > maxCost || (dist[n] >= 0 && dist[n] <= nc)) continue;
        if (dist[n] < 0) visited.push(n);
        dist[n] = nc;
        (buckets[nc] ??= []).push(n);
      }
    }
  }
  for (const w of visited) dist[w] = -1;
  return spots;
}

// 2. Cross-Sea Multi-Bridgehead Harvesting Candidates (`doorHarvestCandidates`):
function doorHarvestCandidates(g, me, state, opts = {}) {
  const doorRadius = opts.doorRadius ?? 40;
  if (!g.boatsAllowed || !g.boatsAllowed(me)) return [];
  const C = g.coast[me];
  if (!C || !C.length) return [];

  const mapData = getMapIsles(g, 30, 80, doorRadius);
  if (!mapData) return [];
  const { dist } = mapData;
  const W = g.W, N = g.N, px = g.px, own = g.own, H = g.humans, d4 = g.dir4, B = g.bal[me];

  const landBorder = new Set();
  const Bd = g.border[me];
  for (let i = Bd.length - 1; i >= 0; i--) {
    for (let k = 0; k < 4; k++) {
      const n = Bd[i] + d4[k];
      if (px[n] >= P_INNER && own[n] !== me) landBorder.add(own[n]);
    }
  }

  const busyTargets = new Set();
  for (const q of state.pendingHandoffs.keys()) busyTargets.add(q);

  let targetSpots = state.doorSpotCache;
  if (!targetSpots || g.t - (state.doorSpotTick ?? -999) >= 15) {
    const maxCost = Math.ceil(5 * doorRadius);
    const visited = [];
    const buckets = [[]];
    const stride = C.length > 320 ? (C.length >> 8) + 1 : 1;
    for (let i = C.length - 1; i >= 0; i -= stride) {
      const c = C[i], x = c % W;
      for (let k = 0; k < 4; k++) {
        if ((k === 1 && x === W - 1) || (k === 3 && x === 0)) continue;
        const w = c + d4[k];
        if (w >= 0 && w < N && px[w] === T_WATER && dist[w] < 0) {
          dist[w] = 0;
          visited.push(w);
          buckets[0].push(w);
        }
      }
    }

    targetSpots = new Map();
    const minSpacing2 = 22 * 22;
    for (let cost = 0; cost < buckets.length && cost <= maxCost; cost++) {
      const b = buckets[cost];
      if (!b) continue;
      for (const w of b) {
        if (dist[w] !== cost) continue;
        const x = w % W;
        for (let k = 0; k < 4; k++) {
          if ((k === 1 && x === W - 1) || (k === 3 && x === 0)) continue;
          const n = w + d4[k];
          if (n >= 0 && n < N) {
            if (px[n] >= P_INNER) {
              const o = own[n];
              if (o !== me && o < H && g.alive[o] && g.terr[o] >= 600 && !(g.teams && g.teams[me] > 0 && g.teams[o] === g.teams[me]) && !(g._wildAlive && SQUAD_POOL_SET.has(String(g.names?.[o] ?? "").trim().toLowerCase()))) {
                let list = targetSpots.get(o);
                if (!list) {
                  list = [];
                  targetSpots.set(o, list);
                }
                if (list.length < 3) {
                  const nx = n % W, ny = (n - nx) / W;
                  let far = true;
                  for (const s of list) {
                    const sx = s.landPix % W, sy = (s.landPix - sx) / W;
                    if ((nx - sx) * (nx - sx) + (ny - sy) * (ny - sy) < minSpacing2) {
                      far = false;
                      break;
                    }
                  }
                  if (far) list.push({ d: cost / 5, landPix: n, waterPix: w, dir: k });
                }
              }
            }
          }
        }
        for (let g8 = 0; g8 < 8; g8++) {
          const dx = DX[g8];
          if ((x === 0 && dx < 0) || (x === W - 1 && dx > 0)) continue;
          const n = w + DY[g8] * W + dx;
          if (n < 0 || n >= N || px[n] !== T_WATER) continue;
          const nc = cost + (g8 & 1 ? 7 : 5);
          if (nc > maxCost || (dist[n] >= 0 && dist[n] <= nc)) continue;
          if (dist[n] < 0) visited.push(n);
          dist[n] = nc;
          (buckets[nc] ??= []).push(n);
        }
      }
    }
    for (const w of visited) dist[w] = -1;
    state.doorSpotCache = targetSpots;
    state.doorSpotTick = g.t;
  }
  if (!targetSpots.size) return [];

  const dMed = medianHumanDensity(g);
  const out = [];

  for (const [q, rawSpots] of targetSpots) {
    if (landBorder.has(q) || busyTargets.has(q) || !g.alive[q] || g.terr[q] < 600) continue;
    const spots = rawSpots.filter((s) => px[s.landPix] >= P_INNER && own[s.landPix] === q);
    if (!spots.length) continue;
    if (!g.hasAttack(me, q) && !g.hasFreeSlot(me)) continue;
    const sh = spots[0];
    const Lq = g.terr[q], Bq = g.bal[q], dq = Bq / Math.max(1, Lq);
    const tD = dq / Math.max(0.1, dMed);
    const collapseLine = iV(g.peak[q], 4);
    const xRatio = Math.min(1, collapseLine / Math.max(1, Lq));
    const elim = 2 * Bq * (1 - Math.pow(xRatio, 1.6)) + 2 * (Lq - collapseLine);

    let atkIn = 0;
    for (const a of g.attackersOf(q)) {
      if (a !== me) atkIn += g.attackTroopsOn(a, q);
    }

    const nearCollapse = Lq <= 1.45 * collapseLine || (atkIn > 0 && atkIn >= 0.65 * elim);
    const bleedingWeak = (atkIn > 0 && (tD < (opts.maxDoorTD ?? 0.68) || atkIn >= 0.16 * Bq)) || (tD < 0.38 && Lq >= 2500);
    if (!nearCollapse && !bleedingWeak) continue;

    // Wait: if we are not currently attacking `q` and `q` is not attacking us (`counter === 0`),
    // `landAt` sets `atkFresh = 1`, which draws the 1st-ring shore cost from `bal[me]` tax-free!
    const counterZero = opts.atkFreshBoats && g.attackTroopsOn(q, me) === 0 && !g.hasAttack(me, q);
    const needOnShore = counterZero ? 5 : Math.max(30, Math.ceil(2 * (2 + 3.2 * dq) + 15));
    const bridgeTroops = troopsFor(needOnShore, sh.d, g.t);
    if (!bridgeTroops) continue;

    const oneBoatFee = iV(32 * B, 1024);
    const maxBoatsAvail = Math.max(1, Math.min(spots.length, (opts.maxBoats ?? 6) - g.boatCount[me]));
    let numSpots = 1;
    if (maxBoatsAvail >= 2 && Lq >= 8000 && oneBoatFee * 2 <= 0.08 * B && spots[1].d <= sh.d + 12) {
      numSpots = maxBoatsAvail >= 3 && Lq >= 20000 && spots[2].d <= sh.d + 16 ? 3 : 2;
    }
    const chosenSpots = spots.slice(0, numSpots);

    let totalFee = iV((32 * numSpots + 12) * B, 1024);
    if (opts.baseRatePer10 > 0 && B > 105 * g.terr[me]) {
      const rebate = futureInterestRebate(g, me, bridgeTroops * numSpots, 50, opts.baseRatePer10);
      totalFee = Math.max(0, totalFee - rebate);
    }
    const shareEst = Math.min(0.45, 0.15 * numSpots);
    const effCostPerPx = nearCollapse
      ? (totalFee + bridgeTroops * numSpots) / Math.max(200, shareEst * collapseLine) + 2 + 1.2 * dq
      : (totalFee + bridgeTroops * numSpots) / Math.max(200, shareEst * Lq) + 2 + 3.2 * dq;

    out.push({
      q,
      kind: nearCollapse ? 'door_collapse' : 'door_bleed',
      c: effCostPerPx,
      d: sh.d,
      water: sh.waterPix,
      dir: sh.dir,
      landing: sh.landPix,
      spots: chosenSpots,
      boatTroops: bridgeTroops,
      needOnShore,
      tD,
      nearCollapse,
    });
  }
  return out.sort((a, b) => a.c - b.c);
}

// Foothold-to-Land Handoff (`handoffFootholds`):
// MUST BE CALLED EVERY 1 TICK (`g.t % 1 === 0`, before `g.t % P.period !== 0`!).
function handoffFootholds(g, me, state, safeFloorFn) {
  const px = g.px, own = g.own;
  for (const [q, info] of state.pendingHandoffs) {
    if (g.t > info.expireTick || !g.alive[q] || !g.terr[q]) {
      state.pendingHandoffs.delete(q);
      continue;
    }

    const landings = info.landings ?? [];
    let landedSpots = 0;
    for (const lp of landings) {
      if (lp >= 0 && px[lp] >= P_INNER && own[lp] === me) landedSpots++;
    }

    if (landedSpots === 0) continue;

    if (info.firstLandedTick === undefined || info.firstLandedTick < 0) {
      info.firstLandedTick = g.t;
    }

    // If multiple coastal bridgeheads were launched, wait up to 2 ticks after the first one
    // touches shore so any simultaneous bridgehead boat also steps onto the beach before `g.attack`!
    if (landedSpots < landings.length && g.t - info.firstLandedTick < 2) {
      continue;
    }

    const B = g.bal[me], fee = iV(12 * B, 1024);
    const safe = safeFloorFn ? safeFloorFn(g, q) : 0;
    const avail = B - fee - safe;
    if (info.reigniteOnly) {
      if (g.attackTroopsOn(me, q) >= 0.08 * B) {
        g.attack(0, q, me);
      }
    } else if (avail > fee * 2) {
      const want = info.wantTroops ? Math.min(avail, info.wantTroops) : Math.min(avail, Math.floor(0.12 * B));
      if (want > fee * 2) {
        const pct = Math.max(0, Math.min(1023, Math.ceil((want * 1024) / B) - 1));
        g.attack(pct, q, me);
      }
    }
    state.pendingHandoffs.delete(q);
  }
}

// Exploit #7: Active Attack Slot `P_BORDER` Re-Igniter (`reigniteNewBorders`)
function reigniteNewBorders(g, me, state, cnt, minShare = 0.10) {
  state.lastActiveCnt ??= new Map();
  const base = g.slotBase(me);
  const activeTargets = new Set();
  for (let i = g.atkCount[me] - 1; i >= 0; i--) {
    const q = g.atkTarget[base + i];
    if (q >= 0 && q < g.humans && g.alive[q]) activeTargets.add(q);
  }
  for (const q of state.lastActiveCnt.keys()) {
    if (!activeTargets.has(q)) state.lastActiveCnt.delete(q);
  }
  if (!activeTargets.size) return false;

  const px = g.px, own = g.own, d4 = g.dir4, W = g.W, N = g.N;
  const Bd = g.border[me];

  for (const q of activeTargets) {
    const curCnt = cnt?.[q] ?? 0;
    const prevCnt = state.lastActiveCnt.get(q) ?? curCnt;
    state.lastActiveCnt.set(q, curCnt);

    const myAtk = g.attackTroopsOn(me, q);
    if (
      curCnt >= prevCnt + 6 &&
      myAtk >= minShare * g.bal[me] &&
      g.bal[me] <= 80 * g.terr[me] &&
      g.attackTroopsOn(q, me) === 0
    ) {
      let unignited = 0;
      const step = Bd.length > 512 ? Math.ceil(Bd.length / 512) : 1;
      for (let i = Bd.length - 1; i >= 0; i -= step) {
        const b = Bd[i];
        if (px[b] !== P_BORDER) continue;
        const bx = b % W;
        for (let k = 0; k < 4; k++) {
          if ((k === 1 && bx === W - 1) || (k === 3 && bx === 0)) continue;
          const n = b + d4[k];
          if (n >= 0 && n < N && px[n] >= P_INNER && own[n] === q) {
            unignited += step;
            break;
          }
        }
        if (unignited >= 6) break;
      }
      if (unignited >= 6) {
        state.lastActiveCnt.set(q, curCnt);
        if (g.attack(0, q, me)) return true;
      }
    }
  }
  return false;
}

// 3. Multi-Point Coastal Bridgehead Widening (`widenFrontBoats`):
// Works identically in both Simulator and `LiveGame` (never reads `g.front`, `g.bId`, or `g.boatOf`!).
function widenFrontBoats(g, me, state, cnt, opts = {}) {
  if (!g.boatsAllowed || !g.boatsAllowed(me)) return false;
  if (g.boatCount[me] >= (opts.maxBoats ?? 4)) return false;
  if ((g.border?.[me]?.length ?? 0) > 1600) return false;
  const B = g.bal[me], fee = iV(32 * B, 1024);
  if (B < 3000) return false;

  const maxFront = opts.maxFront ?? 20;
  const minSteps = opts.minSteps ?? 0;
  const minAtkShare = opts.minAtkShare ?? 0.08;
  const base = g.slotBase(me);
  let targetQ = -1;
  for (let i = g.atkCount[me] - 1; i >= 0; i--) {
    const q = g.atkTarget[base + i];
    if (q >= 0 && q < g.humans && g.alive[q] && g.terr[q] >= 10000) {
      const cq = cnt?.[q] ?? 0;
      const stepsQ = (0.75 * g.terr[q]) / Math.max(1, cq);
      if (cq < maxFront || (minSteps > 0 && cq < 120 && stepsQ >= minSteps)) {
        const ourAtk = g.attackTroopsOn(me, q);
        if (ourAtk >= minAtkShare * B && fee <= 0.16 * ourAtk) {
          if ((state.widenCount.get(q) ?? 0) < 2) {
            targetQ = q;
            break;
          }
        }
      }
    }
  }
  if (targetQ < 0) return false;

  const spots = findCoastalBridgeheads(g, me, state, targetQ, {
    maxWaterDist: opts.maxWaterDist ?? 25,
    maxSpots: 1,
    minSpacing: 24,
  });
  if (!spots.length) return false;
  const bestSpot = spots[0];

  const dq = g.bal[targetQ] / Math.max(1, g.terr[targetQ]);
  const needOnShore = opts.atkFreshBoats ? 5 : Math.max(30, Math.ceil(2 * (2 + 3.2 * dq) + 15));
  const sendTr = troopsFor(needOnShore, bestSpot.d, g.t);
  let effFee = fee;
  if (opts.baseRatePer10 > 0 && B > 105 * g.terr[me]) {
    effFee = Math.max(0, fee - futureInterestRebate(g, me, sendTr ?? 60, 40, opts.baseRatePer10));
  }
  if (!sendTr || sendTr + effFee > 0.07 * B) return false;

  const pct = Math.max(0, Math.min(1023, Math.ceil((sendTr * 1024) / B) - 1));
  const ok = g.boatTo ? g.boatTo(pct, bestSpot.landPix, me, 12) : g.boat(pct, bestSpot.waterPix, bestSpot.dir, me);
  if (!ok) return false;
  state.widenCount.set(targetQ, (state.widenCount.get(targetQ) ?? 0) + 1);
  state.widenLandings ??= new Map();
  const wl = state.widenLandings.get(targetQ) ?? [];
  wl.push(bestSpot.landPix);
  state.widenLandings.set(targetQ, wl);
  return true;
}

function guardAndRecall() {
  // No-op: LiveGame does not expose per-boat route/id arrays (`bId`, `boatOf`, `bRoute`),
  // and bridgehead boats only carry 1-3 pixels of vanguard troops.
}

// 5. Offensive Boat Futures Rebate (#1007):
function futureInterestRebate(g, me, sendTroops, ticks, baseRatePer10) {
  const L = Math.max(1, g.terr[me]), cap = 100 * L, B0 = g.bal[me];
  if (B0 <= cap || ticks <= 0) return 0;
  const fee = iV(32 * B0, 1024);
  const steps = Math.min(30, Math.floor(ticks / 10));
  let bHold = B0, bSend = Math.max(0, B0 - fee - sendTroops);
  const stepGrow = (b) => {
    const f = b > cap ? Math.max(0, 3 - (2 * b) / cap) : 1;
    return Math.min(1.5 * cap, b + b * baseRatePer10 * f);
  };
  for (let k = 0; k < steps; k++) {
    bHold = stepGrow(bHold);
    bSend = stepGrow(bSend);
  }
  const extraInterest = (bSend - (B0 - fee - sendTroops)) - (bHold - B0);
  return Math.max(0, extraInterest);
}

// v24: 4-Combo Engine-Exploit Land + Sea Strategy (by c58)
//
// Core 4 Combos over v23 (0135a3e8):
// 1. Independent Stepping-Stone Island Line (`frogHopStep`):
//    - Small islands (`1-12` px, smaller is strictly better) conquered 100% into `coast[me]` (`needArrive = 2 * isle.size + 8`
//      or full bot-island handoff) so `refreshBorder` promotes all island pixels into `coast[me]`.
//    - Strictly gated to low-fee moments (`maxAbsCost <= 550` or trapped `<= 1500`) or `t + 1` post-land-spend dip in `LiveGame`.
// 2. Multi-Bridgehead Coastal Widening -> 2-Tick `P_BORDER` Wait -> Main Land Assault + Re-Ignite (`reigniteNewBorders`):
//    - Uses minimal `atkFresh = 1` boats (`troopsFor(3, d)`), waits 2 ticks after landing until beachhead pixels turn into
//      `P_BORDER` (widening contact surface area 3x and setting `schedWait = 2`), then fires `g.attack`!
//    - Dynamically re-ignites newly exposed `P_BORDER` pixels (`>= 6` px) on active human targets via `g.attack(0, q)`.
// 3. Exact 1-Ring `attack(0)` Probing (`zeroPulseMode`):
//    - For non-kill probing pulses where `1.20 * need > pulseFrac * B` and `counter === 0`, uses `g.attack(0, q)` so
//      `atkFresh = 1` draws the exact 1st-ring cost from home `bal[me]` tax-free with 0 leftover troops burning on ring 2!
// 4. 1:2 Home Defense Absorption + Wave-Zero Aggressor Counter-Push.


export const PARAMS = {
  ...P17,
  coreFrom: 1500,
  contestW: 0.68,
  sharedBotMult: 1.0,
  marketFloor: 0.85,
  marketFrom: 2500,
  bleedDiscount: 1.0,
  bleedSafeCap: 1,
  collapseRatio: 1.40,
  pulseFrac: 0.12,
  pulseMinShare: 0.04,
  zeroPulseMode: 0,
  thinMaxTD: 0.48,
  thinDiscount: 1.0,
  pocket0Mult: 1.0,
  pocket1Rank: 1.0,
  contactStepsMax: 350,
  contactPenalty: 0.002,
  oppFloorCap: 88,
  focusBonus: 1.0,
  focusT: 350,
  defendDiscount: 0.85,
  defendDiscountMid: 0.88,
  overHumanCap: 1.28,
  overHumanKeep: 1.12,
  soleBufferPenalty: 1.60,
  topRivalMinShare: 0.52,
  topRivalFocusMult: 0.85,
  topRivalStrikeMult: 0.85,
  topRival3Mult: 0.90,
  guardMode: 1,
  crowdedHardPenalty: 1.35,
  crowdedHardCap: 1.26,
  absorbMode: 0,
  absorbWaveMin: 0.04,
  absorbMemory: 250,
  counterClearMode: 6,
  overPulseMode: 0,
  focusRankOnly: 0,
  defendFrom: 0,
  foodRebate: 1,
  seaCore: 0,
  seaEnd: 3200,
  ownWorthMinKeep: 1,
  ownWorthFrom: 4000,
  overPeerCap: 1.16,
  overPeerKeep: 1.04,
  aggMemMode: 8,
  reigniteBorders: 0,
  reigniteMinShare: 0.10,
  flashLoanMode: 0,
  flashLoanMinCost: 160000,
  flashLoanMinRatio: 2.2,
  atkFreshBoats: 0,
  narrowBoatFirstMode: 0,
  exactRingMode: 0,
  botPhaseMode: 1,
  seaRebateMode: 1,
  quotaGuardMode: 1,
  noFullSend: 0,
  collapseFloorCap: 85,
  emptyAllInMode: 1,
  latePocketMode: 0,
  widenStepsMin: 0,
  frogHopOverMode: 0,
  leaderHardFrom: 5000,
  leaderMinShare: 0.16,
  siegeShrinkRatio: 0.72,
  siegeOverKeep: 1.24,
  a06AloneSafe: 1,
  a06AggMemGate: 1,
  a06BoatUnderAtk: 0,
};

export class Policy extends V17 {
  constructor(params = {}, me = 0) {
    super({ ...PARAMS, ...params }, me);
    this.hitTo = new Map();
    this.hitFrom = new Map();
    this.lastLandSpendTick = -999;
    this.shadowQuota = 0;
    this.lastQuotaTick = -1;
    this.isNoFullSend = Boolean(this.p.noFullSend);
    this.pendingQuotaCheck = null;
    this.flState = null;
    this.lastFlashLoan = -999;
    this.flStats = { runs: 0, printed: 0, targets: 0 };
    this.seaState = {
      sentBoats: new Map(),
      pendingHandoffs: new Map(),
      widenCount: new Map(),
      widenLandings: new Map(),
      lastActiveCnt: new Map(),
      bankBoats: new Map(),
      lastFrogHop: -999,
      lastWiden: -999,
      stats: {
        froghop: { boats: 0, fee: 0, troops: 0 },
        door_harvest: { boats: 0, fee: 0, troops: 0 },
        widen: { boats: 0, fee: 0, troops: 0 },
      },
    };
  }

  updateShadowQuota(g) {
    const me = this.me, B = g.bal[me], L = Math.max(1, g.terr[me]);
    if (!this.isNoFullSend && Object.prototype.hasOwnProperty.call(g, "noFullSend") && g.noFullSend) {
      this.isNoFullSend = true;
    }
    if (this.lastQuotaTick < 0) {
      this.shadowQuota = g.t > 50 ? Math.max(iV(B, 4), 2048) : 0;
      this.lastQuotaTick = g.t;
    }
    const dt = Math.max(0, g.t - this.lastQuotaTick);
    const target = Math.max(iV(B, 4), 2048);
    if (dt > 0) {
      const cap = Math.min(100 * L, 1e9);
      let r = this.baseRate(g) * 1e4;
      if (B > cap) r -= (2 * r * (B - cap)) / cap;
      const lN = Math.max(Math.min(Math.round(r), 700), 100);
      this.shadowQuota = Math.min(target, this.shadowQuota + dt * iV(lN * target, 1e4));
      this.lastQuotaTick = g.t;
    } else if (this.shadowQuota > target) {
      this.shadowQuota = target;
    }
    if (this.pendingQuotaCheck && g.t >= this.pendingQuotaCheck.t) {
      const pc = this.pendingQuotaCheck;
      if (g.t > pc.t + 6) {
        this.pendingQuotaCheck = null;
      } else if (B < pc.bal0 - pc.fee) {
        const actualSent = Math.max(0, pc.bal0 - B - pc.fee);
        if (pc.want >= 1.12 * actualSent && actualSent < pc.bal0 - pc.fee - 50) {
          this.isNoFullSend = true;
          this.shadowQuota = 0;
        } else {
          this.shadowQuota = Math.max(0, this.shadowQuota - actualSent);
        }
        this.pendingQuotaCheck = null;
      }
    }
  }

  send(g, target, troops, budgetHint = troops) {
    const P = this.p, me = this.me;
    const balBefore = g.bal[me];
    const fee0 = iV(12 * balBefore, 1024);

    // Exploit #3963 (`z4.aSo` 25% No-Full-Sending quota guard & `attack(0)` bypass):
    if (P.quotaGuardMode > 0 && this.isNoFullSend && troops > 2 && this.shadowQuota < Math.min(0.55 * troops, 0.06 * balBefore)) {
      if (
        target !== NEUTRAL &&
        target >= 0 &&
        this.person(g, target) &&
        !g.hasAttack(me, target) &&
        g.attackTroopsOn(target, me) === 0
      ) {
        const cntQ = Math.max(1, this.cnt[target] ?? 1);
        const ring1Def = iV(cntQ * g.bal[target], 1 + iV(10 * g.terr[target], 16));
        const ring1Cost = cntQ * 2 + 2 * ring1Def + 1;
        if (cntQ >= 16 && ring1Cost >= 2.5 * fee0 && ring1Cost <= troops * 1.25) {
          troops = 1; // Use `g.attack(0)` so `atkFresh = 1` draws ring 1 via `aFo` bypassing `aSo`!
        } else {
          return false; // Hold fire during `aSo` cooldown instead of paying 1.17% fee for a clamped trickle!
        }
      } else if (target !== NEUTRAL) {
        return false;
      }
    }

    const ok = super.send(g, target, troops);
    if (ok) {
      if (!g.online) {
        const actualSent = Math.max(0, balBefore - g.bal[me] - fee0);
        if (troops >= 1.12 * actualSent && actualSent < balBefore - fee0 - 50) {
          this.isNoFullSend = true;
          this.shadowQuota = 0;
        } else {
          this.shadowQuota = Math.max(0, this.shadowQuota - actualSent);
        }
      } else {
        this.pendingQuotaCheck = { t: g.t + 1, bal0: balBefore, fee: fee0, want: troops };
      }
      if (g.bal[me] <= 0.75 * balBefore) {
        this.lastLandSpendTick = g.t;
      }
      if (target !== NEUTRAL && target >= 0 && this.person(g, target)) {
        this.hitTo.set(target, g.t);
        const cq = this.cnt[target] ?? 0;
        const stepsQ = (0.75 * g.terr[target]) / Math.max(1, cq);
        if (
          P.seaCore > 0 &&
          g.terr[target] >= 5000 &&
          (cq < 28 || (P.widenStepsMin > 0 && cq < 120 && stepsQ >= P.widenStepsMin)) &&
          (this.seaState.widenCount.get(target) ?? 0) < 2
        ) {
          const B = g.bal[me], fee = iV(32 * B, 1024);
          if (B >= 1000 && fee <= 0.20 * budgetHint && g.boatCount[me] < 5) {
            const spots = findCoastalBridgeheads(g, me, this.seaState, target, {
              maxWaterDist: 25,
              maxSpots: Math.min(2, 5 - g.boatCount[me]),
              minSpacing: 22,
            });
            if (spots.length > 0) {
              const dq = g.bal[target] / Math.max(1, g.terr[target]);
              const counterZero = P.atkFreshBoats > 0 && g.attackTroopsOn(target, me) === 0;
              const needOnShore = counterZero ? 6 : Math.max(30, Math.ceil(2 * (2 + 3.2 * dq) + 15));
              for (const sp of spots) {
                const curB = g.bal[me];
                if (curB < 500 || iV(32 * curB, 1024) > 0.16 * budgetHint) break;
                const sendTr = Math.max(60, Math.ceil(needOnShore * Math.exp(P.boatDecay * sp.d)));
                const pct = Math.max(0, Math.min(1023, Math.ceil((sendTr * 1024) / curB) - 1));
                const launched = g.boatTo ? g.boatTo(pct, sp.landPix, me, 12) : g.boat(pct, sp.waterPix, sp.dir, me);
                if (launched) {
                  this.seaState.widenLandings ??= new Map();
                  const wl = this.seaState.widenLandings.get(target) ?? [];
                  wl.push(sp.landPix);
                  this.seaState.widenLandings.set(target, wl);
                  this.seaState.widenCount.set(target, (this.seaState.widenCount.get(target) ?? 0) + 1);
                  this.seaState.stats.widen.boats++;
                  this.seaState.stats.widen.fee += iV(32 * curB, 1024);
                  this.boats++;
                }
              }
            }
          }
        }
      }
    }
    return ok;
  }

  isTeammate(g, p) {
    return !!(g.teams && g.teams[this.me] > 0 && g.teams[p] === g.teams[this.me]);
  }

  // Identify our Boss ("[Nope]kazerd183" / "[NPL] npl", excluding our guard bot names)
  isBossNpl(g, p) {
    if (p === this.me || !g.alive[p]) return false;
    const raw = String(g.names?.[p] ?? "").trim();
    const low = raw.toLowerCase();
    const stripped = raw.replace(/\[[^\]]*\]/g, "").trim().toLowerCase();
    if (SQUAD_POOL_SET.has(stripped) || SQUAD_POOL_SET.has(low)) return false;
    return stripped === "kazerd183" || stripped.includes("kazerd") || low.includes("kazerd183") || stripped === "npl" || low === "[npl]npl" || low.includes("auouf");
  }

  hasBossInMatch(g) {
    if (this._bossEnteredMatch) return true;
    for (let p = 0; p < g.humans; p++) {
      const raw = String(g.names?.[p] ?? "").trim();
      const low = raw.toLowerCase();
      const stripped = raw.replace(/\[[^\]]*\]/g, "").trim().toLowerCase();
      if (SQUAD_POOL_SET.has(stripped) || SQUAD_POOL_SET.has(low)) continue;
      if (stripped === "kazerd183" || stripped.includes("kazerd") || low.includes("kazerd183") || stripped === "npl" || low === "[npl]npl" || low.includes("auouf")) {
        this._bossEnteredMatch = true;
        return true;
      }
    }
    return false;
  }

  findBossId(g) {
    for (let p = 0; p < g.humans; p++) {
      if (this.isBossNpl(g, p) && (this.isTeammate(g, p) || !g.teams)) return p;
    }
    return -1;
  }

  isOurSquadBot(g, p) {
    const raw = String(g.names?.[p] ?? "").trim();
    return SQUAD_POOL_SET.has(raw.toLowerCase()) || raw.toUpperCase().includes("[NPL]") || raw.toUpperCase().includes("[NOPE]");
  }

  hasWildOutsidersAlive(g) {
    if (g._wildCheckTick === g.t) return g._wildAlive;
    g._wildCheckTick = g.t;
    for (let p = 0; p < g.humans; p++) {
      if (g.alive[p] && g.terr[p] >= 80 && !g.isBot(p) && !this.isOurSquadBot(g, p) && !this.isBossNpl(g, p)) {
        g._wildAlive = true;
        return true;
      }
    }
    g._wildAlive = false;
    return false;
  }

  // While wild outsiders are alive on the map, protect all 20 squad brothers across teams so they cooperate;
  // Once all wild outsiders are dead (#7821), lift cross-team protection so only 1 team survives!
  isProtectedSquadMate(g, p) {
    if (this.isTeammate(g, p) || this.isBossNpl(g, p)) return true;
    return this.hasWildOutsidersAlive(g) && this.isOurSquadBot(g, p);
  }

  // DISTRIBUTED BACKEND-COORDINATED TEAM SPAWNING:
  // 1) Reports map terrain + live human positions to the unified backend coordinator in tsb-team-squad.mjs
  //    ONLY when Boss [Nope]kazerd183 is present in the match (so 20 guards form a protective cluster around Boss).
  // 2) In autonomous 20-brother matches (without Boss), uses the original 80%-winrate distributed Voronoi
  //    spawnVsPeople(gClean) with TWO critical fixes:
  //      - Fixed slot = window.__tsbSquadSlot (0..19) so all 20 workers have deterministic, non-overlapping slots
  //        even when joining on different frames;
  //      - Erase ALL squad bots from gClean AND include gClean's human count in spawnKey so cached spawnOut
  //        never leaks a squadmate's own coordinates!
  chooseSpawn(g, final = true) {
    const me = this.me;
    const W = g.W, H = g.H;
    const mySquadIdx = typeof window !== "undefined" && Number.isInteger(window.__tsbSquadSlot) ? window.__tsbSquadSlot : 0;
    const squadIds = [];
    for (let p = 0; p < g.humans; p++) {
      if (p === me || (this.isOurSquadBot(g, p) && !this.isBossNpl(g, p))) {
        squadIds.push(p);
      }
    }
    const rankIdx = Math.max(0, squadIds.indexOf(me));
    const squadCount = Math.max(20, squadIds.length);
    const slot = mySquadIdx % 20;

    // Check if Boss [Nope]kazerd183 is in this match
    const bossId = this.findBossId(g);
    if (true) {
      const mapKey = `${W}x${H}_${g.land}_${g.humans}`;
      const nowMs = typeof performance !== "undefined" ? performance.now() : Date.now();
      if (typeof window !== "undefined" && window.__hlSpawnReq && (!this._lastSpawnReqAt || nowMs - this._lastSpawnReqAt > 260)) {
        this._lastSpawnReqAt = nowMs;
        const humans = [];
        for (let p = 0; p < g.humans; p++) {
          const terr = g.terr[p] | 0;
          humans.push({
            id: p,
            name: String(g.names?.[p] ?? ""),
            team: g.teams ? (g.teams[p] | 0) : 0,
            terr,
            x: terr > 0 ? ((g.x0[p] + g.x1[p]) >> 1) : -1,
            y: terr > 0 ? ((g.y0[p] + g.y1[p]) >> 1) : -1,
          });
        }
        const needMap = window.__lastSentSpawnMapKey !== mapKey;
        if (needMap) window.__lastSentSpawnMapKey = mapKey;
        const mapType = needMap ? (g.map?.type || g.px) : undefined;
        const curX = g.terr[me] > 0 ? ((g.x0[me] + g.x1[me]) >> 1) : -1;
        const curY = g.terr[me] > 0 ? ((g.y0[me] + g.y1[me]) >> 1) : -1;
        window.__hlSpawnReq({
          matchKey: mapKey, W, H, land: g.land, me, slot, rankIdx, squadCount,
          myTeam: g.teams ? (g.teams[me] | 0) : 0, curX, curY, humans, mapType,
        });
      }
      if (
        typeof window !== "undefined" &&
        window.__tsbAssignedSpawn &&
        Number.isInteger(window.__tsbAssignedSpawn.x) &&
        (!window.__tsbAssignedSpawn.mapW || (window.__tsbAssignedSpawn.mapW === W && window.__tsbAssignedSpawn.mapH === H))
      ) {
        const res = window.__tsbAssignedSpawn;
        if (window.__hlLog && (!this._lastLogSpawn || Math.hypot(res.x - this._lastLogSpawn.x, res.y - this._lastLogSpawn.y) > 4)) {
          this._lastLogSpawn = { x: res.x, y: res.y };
          window.__hlLog(`[HL-SPAWN-BACKEND] me=${me} slot=${res.slot ?? slot} role=${res.role || "SQUAD"} -> (${res.x},${res.y}) bossDist=${res.bossDist ?? -1} minAllyDist=${res.minAllyDist ?? -1} voronoi=${res.voronoiPixels ?? -1}`);
        }
        return { x: res.x, y: res.y };
      }
    }

    // Autonomous 20-brother distributed Voronoi spawn (original 36b5718 logic with fixed slot 0..19 and clean cache):
    const minSep = Math.max(85, Math.min(145, 0.14 * Math.hypot(W, H)));
    let gClean = g;
    for (const sid of squadIds) {
      if (sid !== me && gClean.terr[sid] > 0) {
        gClean = withoutPlayer(gClean, sid);
      }
    }

    // Throttle expensive spawnVsPeople BFS to at most once every 2200ms during spawnPhase so Worker never lags >3000ms!
    const nowSpawnMs = typeof performance !== "undefined" ? performance.now() : Date.now();
    if (!this._cachedSpawnCands || !this._lastSpawnCalcMs || nowSpawnMs - this._lastSpawnCalcMs > 2200 || this._cachedSpawnW !== W) {
      this._lastSpawnCalcMs = nowSpawnMs;
      this._cachedSpawnW = W;
      let rawCands = this.spawnVsPeople ? this.spawnVsPeople(gClean, 48) : [];
      if (!rawCands || rawCands.length < 32) {
        const more = this.spawnCandidates(gClean, 48) || [];
        rawCands = [...(rawCands || []), ...more];
      }
      this._cachedSpawnCands = rawCands;
    }
    let cands = this._cachedSpawnCands;
    if (cands && cands.length > 0) {
      const comp = this.compSize ? this.compSize(gClean) : null;
      const minMainLand = Math.min(18000, Math.floor(0.18 * Math.max(1, g.land)));
      const chosenSlots = [];
      for (const pos of cands) {
        const x = typeof pos === "object" ? pos.x : (pos % W);
        const y = typeof pos === "object" ? pos.y : Math.floor(pos / W);
        if (comp && comp[y * W + x] > 0 && comp[y * W + x] < minMainLand) continue;
        let tooClose = false;
        for (const prev of chosenSlots) {
          if (Math.hypot(x - prev.x, y - prev.y) < minSep) { tooClose = true; break; }
        }
        if (!tooClose) {
          chosenSlots.push({ x, y });
          if (chosenSlots.length > slot) break;
        }
      }
      // If fewer than slot+1 candidates pass minSep, relax minSep to 0.65x so slots never collide
      if (chosenSlots.length <= slot) {
        const relaxSep = minSep * 0.62;
        for (const pos of cands) {
          const x = typeof pos === "object" ? pos.x : (pos % W);
          const y = typeof pos === "object" ? pos.y : Math.floor(pos / W);
          if (comp && comp[y * W + x] > 0 && comp[y * W + x] < minMainLand) continue;
          if (chosenSlots.every((p) => Math.hypot(x - p.x, y - p.y) >= relaxSep)) {
            chosenSlots.push({ x, y });
            if (chosenSlots.length > slot) break;
          }
        }
      }
      let res = chosenSlots[slot] || cands[slot % cands.length];
      if (!chosenSlots[slot] && chosenSlots.length > 0) {
        // Fallback: Farthest-Point Sampling across the main-continent free land grid (pxArr[idx] === 1 = T_LAND) so all 10 slots are guaranteed >= 160px apart!
        const pxArr = gClean.px;
        for (let sIdx = chosenSlots.length; sIdx <= slot; sIdx++) {
          let bestPt = null, bestD = -1;
          for (let y = 18; y < H - 18; y += 16) {
            for (let x = 18; x < W - 18; x += 16) {
              const idx = y * W + x;
              if (pxArr[idx] !== 1) continue;
              if (comp && comp[idx] > 0 && comp[idx] < minMainLand) continue;
              let minD = 999999;
              for (const p of chosenSlots) minD = Math.min(minD, Math.hypot(x - p.x, y - p.y));
              for (let h = 0; h < gClean.humans; h++) {
                if (h !== me && gClean.terr[h] > 0) {
                  const hx = (gClean.x0[h] + gClean.x1[h]) >> 1, hy = (gClean.y0[h] + gClean.y1[h]) >> 1;
                  minD = Math.min(minD, Math.hypot(x - hx, y - hy) * 1.15);
                }
              }
              if (minD > bestD) {
                bestD = minD;
                bestPt = { x, y };
              }
            }
          }
          if (bestPt) chosenSlots.push(bestPt);
        }
        res = chosenSlots[slot] || res;
      }
      res = typeof res === "object" ? res : { x: res % W, y: Math.floor(res / W) };
      if (typeof window !== "undefined" && window.__hlLog && (!this._lastLogSpawn || Math.hypot(res.x - this._lastLogSpawn.x, res.y - this._lastLogSpawn.y) > 6)) {
        this._lastLogSpawn = res;
        window.__hlLog(`[HL-SPAWN] me=${me} slot=${slot} (squad=${squadIds.length},rankIdx=${rankIdx}) -> (${res.x},${res.y}) chosenSlots=${chosenSlots.length}/${cands.length} minSep=${Math.round(minSep)}`);
      }
      return res;
    }
    return super.chooseSpawn(g, final);
  }

  otherHumanMedDens(g) {
    const me = this.me, H = g.humans;
    const ds = [];
    for (let p = 0; p < H; p++) {
      if (p !== me && !this.isProtectedSquadMate(g, p) && g.alive[p] && g.terr[p] >= 100 && !g.isBot(p)) {
        ds.push(g.bal[p] / g.terr[p]);
      }
    }
    if (!ds.length) return null;
    ds.sort((a, b) => a - b);
    return ds[ds.length >> 1];
  }

  livingHumanCount(g) {
    let n = 0;
    for (let p = 0; p < g.humans; p++) {
      if (!this.isProtectedSquadMate(g, p) && g.alive[p] && g.terr[p] >= 100 && !g.isBot(p)) n++;
    }
    return Math.max(1, n);
  }

  topOtherHuman(g) {
    const me = this.me, H = g.humans;
    let bestP = -1, bestL = 0;
    for (let p = 0; p < H; p++) {
      if (p !== me && !this.isProtectedSquadMate(g, p) && g.alive[p] && g.terr[p] > bestL && !g.isBot(p)) {
        bestL = g.terr[p];
        bestP = p;
      }
    }
    return bestP;
  }

  // PRIVATELY SEND SCALES EMOJI (r5 = 1015) TO BOSS EVERY 10s (180 ticks) (#8051):
  // Uses directed private emoji packet b1.qo.rK(1015, bossId) directly (bypassing aO.r4 canvas draw),
  // so ONLY Boss sees the scales icon above all 20 undercover brothers on the map!
  tryPrivateBossEmoji(g) {
    if (typeof window === "undefined" || !g.online) return;
    const me = this.me;
    if (!g.alive[me] || g.terr[me] <= 0) return;
    const slot = ((typeof window.__tsbSquadSlot === "number" ? window.__tsbSquadSlot : me) | 0) % 20;
    if (g.t < 25 + slot * 4) return;
    if (g.t - (this._lastBossEmojiTick ?? -999) < 180) return;
    let bossId = -1;
    for (let p = 0; p < g.humans; p++) {
      if (this.isBossNpl(g, p) && g.alive[p] && g.terr[p] > 0) {
        bossId = p;
        break;
      }
    }
    if (bossId < 0) return;
    this._lastBossEmojiTick = g.t;
    try {
      const d = window.dictionary;
      const b1Net = (d && window[d.sbNet]) || window.b1;
      if (b1Net?.qo && typeof b1Net.qo.rK === "function") {
        b1Net.qo.rK(1015, bossId);
        if (slot === 0 && window.__hlLog) {
          window.__hlLog(`[HL-EMOJI] t=${g.t} sent private scales emoji (1015) -> boss=${bossId}(${g.names?.[bossId] || ""})`);
        }
      }
    } catch (e) {
      if (slot === 0 && window.__hlLog) {
        window.__hlLog(`[HL-EMOJI-ERR] ${e?.message || e}`);
      }
    }
  }

  // AUTO PEACE VOTE CALL & ACCEPT:
  // ONLY call or vote YES on peace once only 1 team remains alive (or while wild outsiders are still alive and our own team has >=58% land)!
  tryPeaceVote(g) {
    if (this.findBossId(g) < 0) return;
    if (typeof window === "undefined" || !window.ax || !window.dictionary || g.t < 1610) return;
    const me = this.me;
    const hz = window[window.dictionary.sbCommands]?.hz;
    if (!hz) return;
    let ourTeamLand = g.terr[me] || 0;
    let otherTeamAlive = false;
    if (g.teams && g.teams[me] > 0) {
      ourTeamLand = 0;
      for (let p = 0; p < g.players; p++) {
        if (g.alive[p] && g.terr[p] > 0) {
          if (g.teams[p] === g.teams[me]) ourTeamLand += g.terr[p];
          else if (g.terr[p] >= 80) otherTeamAlive = true;
        }
      }
    }
    // Rule #7821: If wild outsiders are all dead, fight until only 1 team remains (!otherTeamAlive) before voting peace!
    const wildAlive = this.hasWildOutsidersAlive(g);
    if (!wildAlive && otherTeamAlive) return;
    const weLead = (!otherTeamAlive) || (wildAlive && ourTeamLand >= 0.58 * Math.max(1, g.land)) || this.isMopUp(g);
    const caller = window.__lastPeaceCaller;
    const callerIsOurs =
      Number.isInteger(caller) &&
      caller >= 0 &&
      caller < g.humans &&
      (caller === me || this.isOurSquadBot(g, caller) || this.isBossNpl(g, caller));
    if (window.ax.iL && typeof window.ax.iM === "function" && window.ax.iM(me)) {
      if (callerIsOurs && (!otherTeamAlive || wildAlive) && typeof hz.iN === "function") {
        hz.iN(1);
        if (window.__hlLog && g.t - (this._lastPeaceVoteLog ?? -999) >= 100) {
          this._lastPeaceVoteLog = g.t;
          window.__hlLog(`[HL-PEACE] t=${g.t} voted YES on our squad's peace call by p=${caller}(${g.names?.[caller] || ""}) (teamLand=${(100 * ourTeamLand / Math.max(1, g.land)).toFixed(1)}%)`);
        }
      }
    } else if (!window.ax.iL && weLead && g.t - (this.lastPeaceKeyTick ?? -999) >= 105 && typeof window.ax.iO === "function" && window.ax.iO(me)) {
      this.lastPeaceKeyTick = g.t;
      window.__lastPeaceCaller = me;
      if (typeof hz.iK === "function") {
        hz.iK();
        if (window.__hlLog) window.__hlLog(`[HL-PEACE] t=${g.t} initiated peace vote (teamLand=${(100 * ourTeamLand / Math.max(1, g.land)).toFixed(1)}%)`);
      }
    }
  }

  // BOSS SUPPORT: CASH DONATION FIRST, ~10% LIGHT ASSIST SECOND!
  // "最好的解围是给钱，打人只是附和10个点左右"
  tryEmergencyBossRescue(g) {
    const me = this.me;
    if (!g.teams || !(g.teams[me] > 0) || !g.canAct(me)) return false;
    const bossId = this.findBossId(g);
    if (bossId < 0 || !g.alive[bossId] || g.terr[bossId] < 50) return false;

    const B = g.bal[me], L = Math.max(1, g.terr[me]), dMe = B / L;
    const B_boss = g.bal[bossId], L_boss = Math.max(1, g.terr[bossId]), dBoss = B_boss / L_boss;

    let bossInAtk = 0, bossOutAtk = 0;
    const bossAttackers = [];
    for (const a of g.attackersOf(bossId)) {
      if (a !== me && !this.isTeammate(g, a)) {
        const tr = g.attackTroopsOn(a, bossId);
        bossInAtk += tr;
        if (!g.isBot(a) || tr > 0.08 * B_boss) bossAttackers.push({ q: a, tr, isEnemyAtk: true });
      }
    }
    const sbB = g.slotBase(bossId);
    for (let i = 0; i < g.atkCount[bossId]; i++) {
      const tgt = g.atkTarget[sbB + i];
      if (tgt >= 0 && tgt < g.humans && !g.isBot(tgt) && !this.isTeammate(g, tgt)) {
        const tr = g.atkTroops[sbB + i];
        bossOutAtk += tr;
        if (!bossAttackers.some(x => x.q === tgt)) bossAttackers.push({ q: tgt, tr, isEnemyAtk: false });
      }
    }

    // 1. PRIMARY: Give cash (donate) to Boss npl, distinguishing PURE INLAND LOCKED vs COASTAL REAR vs FRONTLINE!
    if (typeof g.donate === "function" && g.t >= 350) {
      let myHumanInAtk = 0;
      for (const a of g.attackersOf(me)) {
        if (!g.isBot(a) && !this.isTeammate(g, a)) myHumanInAtk += g.attackTroopsOn(a, me);
      }
      const enemyHumanNbs = this.nb.filter((p) => g.alive[p] && this.person(g, p));
      const hasExposedCoast = (g.coast?.[me]?.length ?? 0) > 0;
      // Coastal rear bots MUST keep >= 68*L anti-boat-sneak-attack reserve so their back is never stolen by sea!
      const coastGuardFloor = hasExposedCoast && g.t >= 1100 ? 68 * L : 18 * L;
      const safeFloor = Math.max(coastGuardFloor, enemyHumanNbs.length > 0 ? this.safeAt(g, -1) : 0);
      const isPureInlandSafe = enemyHumanNbs.length === 0 && !hasExposedCoast && myHumanInAtk === 0;
      const isCoastalRearSafe = enemyHumanNbs.length === 0 && hasExposedCoast && myHumanInAtk === 0;
      const isUnderThreat = myHumanInAtk > 0 || B <= 1.10 * safeFloor;

      if (!isUnderThreat) {
        const underEmergencyFire = bossInAtk > 0 && (bossInAtk >= 0.03 * B_boss || dBoss < 95);
        const bossFightingHuman = bossOutAtk > 0 && dBoss < 115;
        const bossNeedsCash = g.t >= 950 && dBoss < 118;
        const boxedIn = this.nb.length === 0 && this.neutral === 0 && dBoss < 142;

        const minKeepDens = isPureInlandSafe ? (underEmergencyFire ? 15 : 22) : isCoastalRearSafe ? (underEmergencyFire ? 52 : 72) : (underEmergencyFire ? 58 : 78);
        const canAfford = dMe >= minKeepDens && B > 1.10 * safeFloor;

        const cooldown = isPureInlandSafe ? (underEmergencyFire ? 10 : 18) : (underEmergencyFire ? 15 : 25);
        if ((underEmergencyFire || bossFightingHuman || bossNeedsCash || boxedIn) && canAfford && g.t - (this.lastBossDonateTick ?? -999) >= cooldown) {
          const maxSurplus = Math.max(0, B - Math.max(safeFloor, (minKeepDens - 10) * L));
          const maxPct = Math.floor((maxSurplus * 1024) / Math.max(1, B));
          const targetPct = isPureInlandSafe
            ? (underEmergencyFire ? 350 : boxedIn ? 320 : 220)
            : isCoastalRearSafe
              ? (underEmergencyFire ? 220 : 160)
              : (underEmergencyFire ? 150 : 115);
          const pct = Math.min(maxPct, targetPct);
          if (pct >= 55 && g.donate(pct, bossId, me)) {
            this.lastDonateTick = g.t;
            this.lastBossDonateTick = g.t;
            this.cmds++;
            if (typeof window !== "undefined" && window.__hlLog) {
              window.__hlLog(`[HL-DONATE] t=${g.t} emergency boss donate pct=${pct}/1024 -> boss=${bossId}(${g.names?.[bossId] || "npl"}) myBal=${B} dMe=${Math.round(dMe)} dBoss=${Math.round(dBoss)}`);
            }
            return true;
          }
        }
      }
    }

    // 2. SECONDARY: Light ~10%B (pct=102/1024) assist poke ONLY if we share a land border and have healthy density!
    if (bossAttackers.length > 0 && B >= 8000 && dMe >= 38) {
      bossAttackers.sort((a, b) => (b.isEnemyAtk - a.isEnemyAtk) || (b.tr - a.tr));
      for (const { q } of bossAttackers) {
        if (!g.alive[q] || g.terr[q] < 100) continue;
        if ((this.cnt[q] ?? 0) > 0 && !g.hasAttack(me, q) && g.hasFreeSlot(me)) {
          if (g.attack(102, q, me)) { // ~10.0%B light assist!
            this.cmds++;
            this.hitTo.set(q, g.t);
            if (typeof window !== "undefined" && window.__hlLog) {
              window.__hlLog(`[HL-ASSIST] t=${g.t} 10% boss-assist poke -> target=${q}(${g.names?.[q] || ""}) myBal=${B} dMe=${Math.round(dMe)}`);
            }
            return true;
          }
        }
      }
    }
    return false;
  }

  // General Teammate Donation (prioritizing Boss npl first, then frontline squad teammates)
  tryDonateToTeammate(g) {
    const me = this.me;
    if (!g.teams || !(g.teams[me] > 0) || typeof g.donate !== "function") return false;
    if (g.t < 400 || g.t - (this.lastDonateTick ?? -999) < 18) return false;
    const B = g.bal[me], L = Math.max(1, g.terr[me]), dMe = B / L;
    const boxedIn = this.nb.length === 0 && this.neutral === 0;

    let myHumanInAtk = 0;
    for (const a of g.attackersOf(me)) {
      if (!g.isBot(a) && !this.isTeammate(g, a)) myHumanInAtk += g.attackTroopsOn(a, me);
    }
    const enemyHumanNbs = this.nb.filter((p) => g.alive[p] && this.person(g, p));
    const hasExposedCoast = (g.coast?.[me]?.length ?? 0) > 0;
    const coastGuardFloor = hasExposedCoast && g.t >= 1100 ? 68 * L : 18 * L;
    const safeFloor = Math.max(coastGuardFloor, enemyHumanNbs.length > 0 ? this.safeAt(g, -1) : 0);
    const isPureInlandSafe = enemyHumanNbs.length === 0 && !hasExposedCoast && myHumanInAtk === 0;
    if (myHumanInAtk > 0 || B <= 1.10 * safeFloor) return false;

    const maxSurplus = Math.max(0, B - 1.08 * safeFloor);
    const maxSafePct = Math.floor((maxSurplus * 1024) / Math.max(1, B));
    if (maxSafePct < 55) return false;

    // 1. Always check Boss "npl" first!
    const bossId = this.findBossId(g);
    if (bossId >= 0 && g.alive[bossId] && g.terr[bossId] >= 100) {
      const dBoss = g.bal[bossId] / Math.max(1, g.terr[bossId]);
      let bossInAtk = 0, bossOutAtk = 0;
      for (const a of g.attackersOf(bossId)) bossInAtk += g.attackTroopsOn(a, bossId);
      const sbB = g.slotBase(bossId);
      for (let i = 0; i < g.atkCount[bossId]; i++) {
        if (g.atkTarget[sbB + i] !== 512) bossOutAtk += g.atkTroops[sbB + i];
      }
      const bossNeedsHelp =
        (bossInAtk > 0 && dMe >= (isPureInlandSafe ? 16 : 55)) ||
        (bossOutAtk > 0.04 * g.bal[bossId] && dBoss < 120 && dMe >= (isPureInlandSafe ? 25 : 68)) ||
        (g.t >= 900 && dBoss < 118 && dMe >= (isPureInlandSafe ? 32 : 75)) ||
        (boxedIn && isPureInlandSafe && dBoss < 142 && dMe >= 18);
      if (bossNeedsHelp && g.t - (this.lastBossDonateTick ?? -999) >= (isPureInlandSafe ? 15 : 25)) {
        const pct = Math.min(maxSafePct, isPureInlandSafe ? (bossInAtk > 0 ? 340 : 240) : 150);
        if (pct >= 55 && g.donate(pct, bossId, me)) {
          this.lastDonateTick = g.t;
          this.lastBossDonateTick = g.t;
          this.cmds++;
          if (typeof window !== "undefined" && window.__hlLog) {
            window.__hlLog(`[HL-DONATE] t=${g.t} boss donate pct=${pct}/1024 -> boss=${bossId}(${g.names?.[bossId] || "npl"}) myBal=${B} dMe=${Math.round(dMe)}`);
          }
          return true;
        }
      }
    }

    // 2. SQUAD MUTUAL AID: Rescue any squad brother who is under human attack or sneaky boat landing,
    //    AND lightly poke (10%B) the attacker if we border them!
    const wildOutsidersAlive = this.hasWildOutsidersAlive(g);
    for (let p = 0; p < g.humans; p++) {
      if (p === me || !g.alive[p] || !this.isOurSquadBot(g, p) || (!wildOutsidersAlive && !this.isTeammate(g, p)) || g.terr[p] < 300) continue;
      const dAlly = g.bal[p] / Math.max(1, g.terr[p]);
      let inHumanAtk = 0, mainAttacker = -1, maxAtkTr = 0;
      for (const a of g.attackersOf(p)) {
        if (!g.isBot(a) && !this.isProtectedSquadMate(g, a)) {
          const tr = g.attackTroopsOn(a, p);
          inHumanAtk += tr;
          if (tr > maxAtkTr) { maxAtkTr = tr; mainAttacker = a; }
        }
      }
      if (inHumanAtk > 0 && (inHumanAtk >= 0.08 * g.bal[p] || dAlly < 75)) {
        // First donate cash to save our brother (if on same team, while keeping our own coastGuardFloor / safeFloor intact!)
        if (this.isTeammate(g, p) && dMe >= Math.max(55, dAlly + 15)) {
          const pct = Math.min(maxSafePct, isPureInlandSafe ? 240 : 155);
          if (pct >= 55 && g.donate(pct, p, me)) {
            this.lastDonateTick = g.t;
            this.cmds++;
            if (typeof window !== "undefined" && window.__hlLog) {
              window.__hlLog(`[HL-DONATE] t=${g.t} squad rescue donate pct=${pct}/1024 -> ally=${p}(${g.names?.[p] || ""}) myBal=${B} dMe=${Math.round(dMe)} dAlly=${Math.round(dAlly)}`);
            }
            return true;
          }
        }
        // Second, if we border the attacker on land and aren't already attacking them, do a ~10%B light assist poke (even across teams)!
        if (mainAttacker >= 0 && !this.isTeammate(g, mainAttacker) && (this.cnt[mainAttacker] ?? 0) > 0 && !g.hasAttack(me, mainAttacker) && g.hasFreeSlot(me) && dMe >= 65 && g.t - (this.lastAssistPokeTick ?? -999) >= 25) {
          this.lastAssistPokeTick = g.t;
          if (g.attack(102, mainAttacker, me)) {
            this.cmds++;
            this.hitTo.set(mainAttacker, g.t);
            if (typeof window !== "undefined" && window.__hlLog) {
              window.__hlLog(`[HL-ASSIST] t=${g.t} 10% squad-rescue poke -> enemy=${mainAttacker}(${g.names?.[mainAttacker] || ""}) for ally=${p}(${g.names?.[p] || ""})`);
            }
            return true;
          }
        }
      }
    }

    if (!boxedIn && dMe < 112) return false;
    if (boxedIn && dMe < 55) return false;

    let bestAlly = -1, bestScore = -Infinity;
    for (let p = 0; p < g.humans; p++) {
      if (p === me || !g.alive[p] || !this.isTeammate(g, p) || (!this.isBossNpl(g, p) && !this.isOurSquadBot(g, p)) || g.terr[p] < 600) continue;
      const dAlly = g.bal[p] / Math.max(1, g.terr[p]);
      if (dAlly >= 132) continue;
      let outAtk = 0, inAtk = 0;
      const sb = g.slotBase(p);
      for (let i = 0; i < g.atkCount[p]; i++) {
        const tgt = g.atkTarget[sb + i];
        if (tgt !== 512) outAtk += g.atkTroops[sb + i];
      }
      for (const a of g.attackersOf(p)) inAtk += g.attackTroopsOn(a, p);
      const allyEnemyNbs = this.peopleOf(g, p);
      if (!allyEnemyNbs.length && outAtk === 0 && inAtk === 0 && g.t > 2200) continue;
      const isBoss = p === bossId;
      const isSquad = this.isOurSquadBot(g, p);
      const score = (isBoss ? 5000 : isSquad ? 600 : 150) + (outAtk + inAtk) / 500 + (135 - dAlly) * 3 + Math.min(150, g.terr[p] / 500);
      if (score > bestScore && (isBoss || boxedIn || outAtk + inAtk > 0.04 * g.bal[p] || (isSquad && dMe >= 120 && dAlly < 98))) {
        bestScore = score;
        bestAlly = p;
      }
    }
    if (bestAlly < 0) return false;

    const pct = boxedIn ? (dMe > 110 ? 280 : 185) : 153;
    if (g.donate(pct, bestAlly, me)) {
      this.lastDonateTick = g.t;
      this.cmds++;
      if (typeof window !== "undefined" && window.__hlLog) {
        window.__hlLog(`[HL-DONATE] t=${g.t} surplus donate pct=${pct}/1024 -> ally=${bestAlly}(${g.names?.[bestAlly] || ""}) boxedIn=${boxedIn} myBal=${B} dMe=${Math.round(dMe)}`);
      }
      return true;
    }
    return false;
  }

  isMopUp(g) {
    const me = this.me;
    if (g.teams && g.teams[me] > 0) {
      let enemyAlive = false;
      for (let p = 0; p < g.players; p++) {
        if (g.alive[p] && g.terr[p] > 0 && g.teams[p] !== g.teams[me]) {
          enemyAlive = true;
          break;
        }
      }
      if (!enemyAlive && this.nb.length === 0 && this.neutral === 0) return true;
    }
    return this.nb.length === 0 && this.neutral === 0 && g.terr[me] >= 0.80 * g.land && this.livingHumanCount(g) <= 1;
  }

  spawnWeight(g, s) {
    const w = super.spawnWeight ? super.spawnWeight(g, s) : 1;
    const comp = this.compSize(g);
    const sz = comp?.[s] ?? g.land;
    if (sz > 0 && sz < 15000 && sz < 0.25 * g.land) return w * 0.25;
    return w;
  }

  safeAt(g, q) {
    let s = super.safeAt(g, q);
    const P = this.p, me = this.me, L = Math.max(1, g.terr[me]);
    if (q < 0 || !this.person(g, q)) {
      s = Math.min(s, P.oppFloorCap * L);
    } else if (P.a06AloneSafe > 0 && !this.isNoFullSend && g.t >= 4800 && g.attackTroopsOn(q, me) === 0 && g.bal[q] > 0.10 * g.bal[me]) {
      for (const p of this.nb) {
        if (p === q || !g.alive[p] || !this.person(g, p) || g.bal[p] <= 1.15 * g.bal[me]) continue;
        const pOthers = this.peopleOf(g, p).filter((o) => o !== me && g.alive[o] && g.terr[o] > 0);
        if (pOthers.length === 0) {
          const coalitionKeep = Math.max(0, (g.bal[p] + 0.45 * g.bal[q] - 1.5 * L) / 1.78);
          s = Math.max(s, coalitionKeep);
        }
      }
    }
    return s;
  }

  winFloor(g, q) {
    if (this.sbT !== g.t) {
      this.sbT = g.t;
      this.sb = this.safeFinite(g);
    }
    const P = this.p, me = this.me, L = Math.max(1, g.terr[me]);
    const mult = this.contested(g, q) ? P.sharedBotMult : 1.0;
    return Math.max((mult * this.botPx(g, q) * L) / (P.winR * Math.max(1, g.t)), this.dpKeep(g), this.sb);
  }

  hasBorderFood(g) {
    if (this.neutral > 0) return true;
    for (const q of this.nb) {
      if (g.alive[q] && g.terr[q] > 0 && !this.person(g, q)) return true;
    }
    return false;
  }

  newHumansExposed(g, q) {
    const me = this.me;
    let newCnt = 0;
    for (const o of this.peopleOf(g, q)) {
      if (o !== me && g.alive[o] && g.terr[o] > 0 && !this.nb.includes(o)) {
        newCnt++;
      }
    }
    return newCnt;
  }

  activeFocus(g) {
    const P = this.p;
    if (!(P.focusBonus < 1)) return -1;
    let bestQ = -1, bestT = g.t - P.focusT;
    for (const q of this.nb) {
      if (!g.alive[q] || !this.person(g, q) || (this.cnt[q] ?? 0) < 25) continue;
      const t = this.hitTo.get(q) ?? -1e9;
      if (t > bestT) {
        bestT = t;
        bestQ = q;
      }
    }
    return bestQ;
  }

  peerAggressor(g) {
    const P = this.p, me = this.me, B = g.bal[me];
    for (const q of this.nb) {
      if (!g.alive[q] || !this.person(g, q)) continue;
      const inc = g.attackTroopsOn(q, me);
      if (inc > Math.max(500, 0.02 * B)) {
        this.hitFrom.set(q, g.t);
      }
    }
    if (!(P.defendDiscount < 1) || g.t < P.defendFrom) return -1;
    if (P.absorbMode === 1) {
      let bestQ = -1, bestT = g.t - P.absorbMemory;
      for (const q of this.nb) {
        if (!g.alive[q] || !this.person(g, q) || (this.cnt[q] ?? 0) < 25) continue;
        const inc = g.attackTroopsOn(q, me);
        const t = this.hitFrom.get(q) ?? -1e9;
        if (inc < 0.015 * B && t > bestT && g.bal[q] + inc <= 1.4 * B) {
          bestT = t;
          bestQ = q;
        }
      }
      return bestQ;
    }
    let bestQ = -1, bestIn = 0;
    for (const q of this.nb) {
      if (!g.alive[q] || !this.person(g, q)) continue;
      const inc = g.attackTroopsOn(q, me);
      if (P.counterClearMode >= 5 && inc > P.pulseFrac * B + g.attackTroopsOn(me, q)) continue;
      if (inc > Math.max(500, 0.02 * B) && g.bal[q] + inc <= 1.6 * B && inc > bestIn) {
        bestIn = inc;
        bestQ = q;
      }
    }
    if (bestQ < 0 && P.aggMemMode >= 1) {
      let bestT = g.t - 150;
      for (const q of this.nb) {
        if (!g.alive[q] || !this.person(g, q) || (this.cnt[q] ?? 0) < 25) continue;
        const inc = g.attackTroopsOn(q, me);
        if (inc > P.pulseFrac * B + g.attackTroopsOn(me, q)) continue;
        const t = this.hitFrom.get(q) ?? -1e9;
        if (t > bestT && g.bal[q] + inc <= 1.5 * B) {
          bestT = t;
          bestQ = q;
        }
      }
    }
    return bestQ;
  }

  stepFlashLoan(g) {
    const P = this.p, me = this.me;
    const st = this.flState;
    if (!st) return false;
    if (g.t > st.expireTick) {
      if (st.phase === 'wait_expand' && g.hasAttack(me, st.E)) {
        g.retreat(st.E, me);
      }
      this.flState = null;
      return false;
    }

    if (st.phase === 'armed') {
      const waitGoal = g.online ? 3 : 7;
      if (g.t >= st.armTick + waitGoal) {
        if (!g.alive[st.E] || g.bal[me] > 142 * g.terr[me]) {
          this.flState = null;
          return false;
        }
        if (g.attack(1023, st.E, me)) {
          this.cmds++;
          if (!g.online && st.extraTargets?.length) {
            for (const b of st.extraTargets) {
              if (g.alive[b] && g.attackTroopsOn(b, me) === 0 && !g.hasAttack(me, b) && g.hasFreeSlot(me)) {
                g.attack(0, b, me);
                this.cmds++;
              }
            }
          }
          st.phase = 'wait_expand';
          st.parkTick = g.t;
          return true;
        }
      }
      return false;
    }

    if (st.phase === 'wait_expand') {
      let bFresh = false;
      const base = g.slotBase(me);
      for (let i = g.atkCount[me] - 1; i >= 0; i--) {
        if (g.atkTarget[base + i] === st.B1 && g.atkFresh[base + i] === 1) {
          bFresh = true;
          break;
        }
      }
      if (!bFresh || g.t >= st.armTick + 9) {
        if (g.hasAttack(me, st.E)) {
          if (g.retreat(st.E, me)) {
            this.cmds++;
            this.flStats.runs++;
            this.flStats.printed += st.estPrint;
            this.flStats.targets += 1 + (st.extraTargets?.length ?? 0);
            this.lastFlashLoan = g.t;
            this.flState = null;
            return true;
          }
        } else {
          this.flState = null;
        }
      }
      return false;
    }
    return false;
  }

  tryStartFlashLoan(g) {
    const P = this.p, me = this.me;
    if (!(P.flashLoanMode > 0) || this.flState || g.t < 2000 || g.t - this.lastFlashLoan < 45) return false;
    if (g.atkCount[me] > 0) return false; // Must be unscheduled so schedWait starts cleanly at 64 -> 6!
    const B = g.bal[me], L = Math.max(1, g.terr[me]);
    if (B < 80000 || B > 140 * L) return false;
    for (const a of g.attackersOf(me)) if (a < g.humans && !g.isBot(a)) return false;

    if (P.flashLoanMode === 3) {
      // Safe flash-loan gate: only when there is at most 1 living human neighbour AND no threatening bot neighbour,
      // or in a 1v1 endgame (`livingHumanCount(g) === 2`), so no third party can attack us while `bal === 0`!
      const humanNbs = this.nb.filter((p) => g.alive[p] && this.person(g, p));
      const botNbs = this.nb.filter((p) => g.alive[p] && !this.person(g, p) && g.bal[p] > 5000);
      if (humanNbs.length > 1 || botNbs.length > 0) return false;
    }

    const fee = iV(12 * B, 1024);
    let parkE = -1, parkScore = Infinity;
    if (this.neutral >= 4) {
      parkE = NEUTRAL;
      parkScore = 0;
    } else {
      for (const q of this.nb) {
        if (!g.alive[q] || !g.terr[q] || g.attackTroopsOn(q, me) > 0) continue;
        if (!this.person(g, q) && (this.cnt[q] ?? 0) >= 3) {
          const s = g.bal[q];
          if (s < parkScore) {
            parkScore = s;
            parkE = q;
          }
        }
      }
    }
    if (parkE < 0 && P.flashLoanMode >= 2) {
      for (const q of this.nb) {
        if (!g.alive[q] || !this.person(g, q) || g.attackTroopsOn(q, me) > 0) continue;
        if ((this.cnt[q] ?? 0) >= 8 && g.bal[q] < 0.7 * B) {
          if (g.bal[q] < parkScore) {
            parkScore = g.bal[q];
            parkE = q;
          }
        }
      }
    }
    if (parkE < 0) return false;

    const cands = [];
    for (const q of this.nb) {
      if (q === parkE || !g.alive[q] || !this.person(g, q) || g.attackTroopsOn(q, me) > 0) continue;
      const cntQ = this.cnt[q] ?? 0;
      if (cntQ < 16) continue;
      const def = iV(cntQ * g.bal[q], 1 + iV(10 * g.terr[q], 16));
      const ring1Cost = cntQ * 2 + 2 * def + 1;
      if (ring1Cost >= P.flashLoanMinCost && ring1Cost >= P.flashLoanMinRatio * (62500 + 2 * fee)) {
        cands.push({ q, cost: ring1Cost });
      }
    }
    if (!cands.length) return false;
    cands.sort((a, b) => b.cost - a.cost);
    const B1 = cands[0].q;
    const extraTargets = !g.online && P.flashLoanMode >= 2 ? cands.slice(1, 3).map((x) => x.q) : [];
    const estPrint = cands.slice(0, 1 + extraTargets.length).reduce((s, x) => s + x.cost, 0);

    if (g.attack(0, B1, me)) {
      this.cmds++;
      this.hitTo.set(B1, g.t);
      this.flState = {
        phase: 'armed',
        armTick: g.t,
        expireTick: g.t + 16,
        B1,
        E: parkE,
        extraTargets,
        estPrint,
      };
      return true;
    }
    return false;
  }

  act(g) {
    const P = this.p, me = this.me;
    if (!g.canAct(me)) return;
    if (P.quotaGuardMode > 0) this.updateShadowQuota(g);

    // 0. Every single tick: step the 50k debt cap flash-loan state machine if active!
    if (P.flashLoanMode > 0 && this.flState) {
      if (this.stepFlashLoan(g) && g.online) return;
      if (this.flState) return; // Hold normal decisions during the 8-tick flash-loan window!
    }

    // 1. Every single tick: check 2-tick `P_BORDER` bridgehead handoffs (#6 / #8)!
    if (P.seaCore > 0 && this.seaState.pendingHandoffs.size > 0) {
      handoffFootholds(g, me, this.seaState, (gm, q) => this.safeAt(gm, q));
    }

    // 2. Combo 1 (#2): In online `LiveGame` (where only 1 command can be sent per tick),
    // if the previous tick (`g.t - 1`) just executed a major land spend that dropped `bal[me]` to a dip,
    // use this off-period tick `t + 1` to launch our cheap stepping-stone boat!
    if (
      P.seaCore > 0 &&
      g.online &&
      g.t - this.lastLandSpendTick === 1 &&
      g.t >= 750 &&
      this.neutral === 0 &&
      g.t - this.seaState.lastFrogHop >= 35 &&
      g.canAct(me)
    ) {
      const B = g.bal[me], fee = iV(32 * B, 1024);
      if (fee <= 500 && frogHopStep(g, me, this.seaState, { maxHopBoats: 1, maxTotalBoats: 4, maxAbsCost: 550 })) {
        this.seaState.lastFrogHop = g.t;
        this.seaState.stats.froghop.boats++;
        this.seaState.stats.froghop.fee += fee;
        return;
      }
    }

    if (g.t % P.period !== 0) return;
    this.tryPrivateBossEmoji(g);
    if (g.t < P.coreFrom) {
      this.analyze(g);
      if (typeof window !== "undefined" && window.__hlLog && g.t > 0 && g.t % 90 === 0 && this._lastTickLog !== g.t) {
        this._lastTickLog = g.t;
        const pf = window.__hlPerf;
        const pfStr = pf && pf.ticks > 0 ? ` avgMs=${(pf.totalMs / pf.ticks).toFixed(2)} maxMs=${pf.maxMs.toFixed(1)} skip=${pf.skippedTicks}` : "";
        window.__hlLog(`[HL-TICK] t=${g.t} terr=${g.terr[me]}(${(100 * g.terr[me] / Math.max(1, g.land)).toFixed(1)}%) bal=${g.bal[me]} dens=${(g.bal[me] / Math.max(1, g.terr[me])).toFixed(1)} nb=${this.nb.length} neut=${this.neutral} cmds=${this.cmds} boats=${this.boats}${pfStr}`);
      }
      if (this.tryEmergencyBossRescue(g) && g.online) return;
      const before = this.cmds;
      const balBefore = g.bal[me];
      super.act(g);
      if (this.cmds > before && g.bal[me] <= 0.75 * balBefore) {
        this.lastLandSpendTick = g.t;
      }
      // Line 1: Independent Island-Hopping Line (#2475 / #2477 / #3475):
      if (
        P.seaCore > 0 &&
        g.t >= 750 &&
        this.neutral === 0 &&
        (!g.online || this.cmds === before) &&
        g.canAct(me) &&
        g.t % P.period === 0 &&
        g.t - this.seaState.lastFrogHop >= 35
      ) {
        this.analyze(g);
        const B = g.bal[me];
        const trapped = !this.hasBorderFood(g);
        const lowDip = (!g.online && this.cmds > before && B <= 0.75 * balBefore) || B <= 8000;
        if (trapped || lowDip) {
          const fee = iV(32 * B, 1024);
          const maxAbsCost = trapped ? 1500 : 550;
          if (frogHopStep(g, me, this.seaState, { maxHopBoats: 1, maxTotalBoats: 4, maxAbsCost })) {
            this.seaState.lastFrogHop = g.t;
            this.seaState.stats.froghop.boats++;
            this.seaState.stats.froghop.fee += fee;
          }
        }
      }
      return;
    }
    if (g.t % P.period !== 0) return;

    this.analyze(g);
    if (typeof window !== "undefined" && window.__hlLog && g.t > 0 && g.t % 90 === 0 && this._lastTickLog !== g.t) {
      this._lastTickLog = g.t;
      const pf = window.__hlPerf;
      const pfStr = pf && pf.ticks > 0 ? ` avgMs=${(pf.totalMs / pf.ticks).toFixed(2)} maxMs=${pf.maxMs.toFixed(1)} skip=${pf.skippedTicks}` : "";
      window.__hlLog(`[HL-TICK] t=${g.t} terr=${g.terr[me]}(${(100 * g.terr[me] / Math.max(1, g.land)).toFixed(1)}%) bal=${g.bal[me]} dens=${(g.bal[me] / Math.max(1, g.terr[me])).toFixed(1)} nb=${this.nb.length} neut=${this.neutral} cmds=${this.cmds} boats=${this.boats}${pfStr}`);
      if (g.t >= 3960 && g.t - (window.__lastReplaySnapAt || 0) >= 1350 && typeof window.bC === "object" && window.bC?.a7s?.a2b && window.__tsbReportResult) {
        let minAliveSquadId = me;
        for (let p = 0; p < g.humans; p++) {
          if (g.alive[p] && this.isTeammate(g, p) && this.isOurSquadBot(g, p) && p < minAliveSquadId) minAliveSquadId = p;
        }
        if (me === minAliveSquadId) {
          window.__lastReplaySnapAt = g.t;
          try {
            const repStr = window.bC.a7s.a2b();
            if (typeof repStr === "string" && repStr.length > 100) {
              const cut = repStr.indexOf("=");
              const pure = (cut >= 0 ? repStr.slice(cut + 1) : repStr).trim();
              window.__tsbReportResult(JSON.stringify({ type: "raw_replay", game: `t${g.t}`, replay: pure }));
            }
          } catch {}
        }
      }
    }
    this.tryPeaceVote(g);
    if (this.tryEmergencyBossRescue(g) && g.online) return;
    this.updateGrudges(g);
    this.updateWars(g);

    // Combo 2 (#7): If an active human attack target gained >= 8 new `P_BORDER` pixels
    // (e.g. from eating an adjacent bot or a secondary boat step) and our slot is large enough,
    // re-ignite those borders!
    if (P.seaCore > 0 && P.reigniteBorders > 0) {
      if (reigniteNewBorders(g, me, this.seaState, this.cnt, P.reigniteMinShare) && g.online) return;
    }

    const cmdsBefore = this.cmds;
    if (P.flashLoanMode > 0 && this.tryStartFlashLoan(g)) return;
    if (this.neutral > 0) this.expandNeutral(g, g.bal[me] - this.safeAt(g, -1));
    this.buyLand(g);

    if (P.seaCore > 0 && g.t - this.seaState.lastWiden >= 30) {
      const fee = iV(32 * g.bal[me], 1024);
      if (
        widenFrontBoats(g, me, this.seaState, this.cnt, {
          maxFront: 22,
          minSteps: P.widenStepsMin ?? 0,
          minAtkShare: 0.08,
          maxBoats: 5,
          atkFreshBoats: P.atkFreshBoats > 0,
          baseRatePer10: P.seaRebateMode > 0 ? this.baseRate(g) : 0,
        })
      ) {
        this.seaState.lastWiden = g.t;
        this.seaState.stats.widen.boats++;
        this.seaState.stats.widen.fee += fee;
      }
    }

    if (this.cmds === cmdsBefore) this.tryDonateToTeammate(g);
    if (this.cmds === cmdsBefore) this.idleBoats(g);

    // Line 1: Independent Island-Hopping Line ("算账再发" cost-benefit gate):
    if (P.seaCore > 0 && g.t - this.seaState.lastFrogHop >= 30) {
      const B = g.bal[me], L = Math.max(1, g.terr[me]), fee = iV(32 * B, 1024);
      const negInterestCap = P.frogHopOverMode > 0 && B >= 112 * L ? Math.min(25000, Math.floor(0.036 * B)) : 550;
      const maxAbsCost = !this.hasBorderFood(g) ? Math.max(1800, negInterestCap) : negInterestCap;
      if (
        frogHopStep(g, me, this.seaState, {
          maxHopBoats: 2,
          maxTotalBoats: 5,
          maxAbsCost,
          safeFloor: this.safeAt(g, -1),
          botPhaseMode: P.botPhaseMode > 0,
        })
      ) {
        this.seaState.lastFrogHop = g.t;
        this.seaState.stats.froghop.boats++;
        this.seaState.stats.froghop.fee += fee;
      }
    }
  }

  compSize(g) {
    if (!(this.p.seaFree > 0) || g.t < this.p.coreFrom) return super.compSize(g);
    if (this.freeAt === g.t) return this.freeComp;
    const N = g.N, px = g.px, own = g.own, d = g.dir4, me = this.me;
    const c = this.freeComp?.length === N ? this.freeComp.fill(0) : new Int32Array(N);
    const seen = new Uint8Array(N), q = new Int32Array(N);
    for (let s = 0; s < N; s++) {
      if (px[s] !== T_LAND || seen[s]) continue;
      let h = 0, t = 0, taken = false;
      q[t++] = s;
      seen[s] = 1;
      while (h < t) {
        const a = q[h++];
        for (let k = 0; k < 4; k++) {
          const n = a + d[k];
          if (n < 0 || n >= N) continue;
          const v = px[n];
          if (v === T_LAND) {
            if (!seen[n]) {
              seen[n] = 1;
              q[t++] = n;
            }
          } else if (v >= P_INNER && own[n] !== me) taken = true;
        }
      }
      const effSize = !taken ? t : t >= 120 ? Math.max(100, t >> 1) : 0;
      if (effSize > 0) for (let i = 0; i < t; i++) c[q[i]] = effSize;
    }
    this.freeAt = g.t;
    this.freeComp = c;
    return c;
  }

  idleBoats(g) {
    const P = this.p, me = this.me;
    if (this.isMopUp(g)) {
      if (!g.boatsAllowed(me) || g.boatCount[me] >= 6) return;
      const oldRange = P.boatRange;
      P.boatRange = 2500;
      this.boatOut(g, () => 0, Infinity);
      P.boatRange = oldRange;
      return;
    }
    if (P.a06BoatUnderAtk > 0 && g.t >= 3500 && g.bal[me] < 100 * g.terr[me]) {
      let humanInAtk = 0;
      for (const a of g.attackersOf(me)) if (a < g.humans && !g.isBot(a)) humanInAtk += g.attackTroopsOn(a, me);
      if (humanInAtk >= 0.06 * g.bal[me]) return;
    }
    if (P.boatFood > 0 && this.boatFood(g)) return;
    if (this.neutral > 0 || g.t - this.lastBoat < P.boatEvery) return;
    if (this.nb.length && g.bal[me] < P.idleCap * 100 * g.terr[me]) return;
    const { floorAt } = this.floors(g);
    let activeHops = 0;
    if (this.seaState.inFlightIsles) {
      for (const [, expT] of this.seaState.inFlightIsles) if (g.t < expT) activeHops++;
    }
    const oldMax = P.maxBoats;
    P.maxBoats = oldMax + activeHops;
    this.boatOut(g, floorAt, P.boatFee > 0 && this.nb.length ? P.boatFee * this.minNbPrice(g) : Infinity);
    P.maxBoats = oldMax;
  }

  offers(g) {
    const P = this.p, me = this.me;
    let active = 0;
    const base = g.slotBase(me);
    for (let i = g.atkCount[me] - 1; i >= 0; i--) if (g.atkTarget[base + i] !== NEUTRAL) active++;
    const B = g.bal[me], L = Math.max(1, g.terr[me]), dMe = B / L, fee = iV(12 * B, 1024);
    const dMed = this.otherHumanMedDens(g) ?? dMe;
    const nHumans = this.livingHumanCount(g);
    const humanNbs = this.nb.filter((p) => g.alive[p] && this.person(g, p));
    const focusQ = this.activeFocus(g);
    const aggQ = this.peerAggressor(g);
    const topRival = this.topOtherHuman(g);
    const out = [];

    for (const q of this.nb) {
      if (!g.alive[q] || !g.terr[q]) continue;
      const already = g.hasAttack(me, q);
      if (!already && (active >= P.maxTargets || !g.hasFreeSlot(me))) continue;

      const Lq = g.terr[q], Bq = g.bal[q], dq = Bq / Math.max(1, Lq);
      const person = this.person(g, q);
      const inAtk = g.attackTroopsOn(q, me);
      const myAtk = g.attackTroopsOn(me, q);
      const rawNeed = this.elimCost(g, q) + inAtk - myAtk;
      if (rawNeed <= 0) continue;
      const left = iV(g.peak[q], 4);
      const share = Math.min(1, this.cnt[q] / Math.max(1, g.border[q].length));
      const baseGain = Math.max(1, Lq - left + left * P.shareW * share);
      let c = (rawNeed + fee) / baseGain;

      if (!person) {
        out.push({
          q,
          person: false,
          tD: dq / Math.max(0.1, dMed),
          need: rawNeed,
          c,
          rankC: c,
          pulseMode: false,
          nearCollapse: false,
          bleeding: false,
        });
      } else {
        const tD = dq / Math.max(0.1, dMed);
        const bossId = this.findBossId(g);
        let otherAtk = 0, otherAtkers = 0, allyAtk = 0, clanAllyAtkers = 0, bossAtkOnQ = 0;
        for (const a of g.attackersOf(q)) {
          if (a !== me && !g.isBot(a)) {
            const tr = g.attackTroopsOn(a, q);
            otherAtkers++;
            otherAtk += tr;
            if (a === bossId) bossAtkOnQ += tr;
            if (this.isProtectedSquadMate(g, a)) {
              allyAtk += tr;
              clanAllyAtkers += this.isOurSquadBot(g, a) ? 2 : 1;
            }
          }
        }
        let atkOnAlly = 0, atkOnBoss = 0;
        if (g.teams && g.teams[me] > 0) {
          const sbQ = g.slotBase(q);
          for (let i = 0; i < g.atkCount[q]; i++) {
            const tgt = g.atkTarget[sbQ + i];
            if (tgt >= 0 && tgt < 512 && this.isProtectedSquadMate(g, tgt)) {
              const tr = g.atkTroops[sbQ + i];
              atkOnAlly += tr;
              if (tgt === bossId) atkOnBoss += tr;
            }
          }
        }
        const emptyAllIn = P.emptyAllInMode > 0 && inAtk > 0.15 * B && Bq < 0.08 * inAtk && tD < 0.06 && Lq >= 5000;
        const nearCollapse = Lq <= P.collapseRatio * left || (otherAtk > 0 && otherAtk >= 0.65 * rawNeed) || emptyAllIn;
        const bleeding = (otherAtkers > 0 && (tD < 0.75 || otherAtk >= 0.15 * Bq)) || emptyAllIn;
        const onMe = inAtk > 0;

        if (nearCollapse) {
          const effNeed = emptyAllIn ? Math.max(1, this.elimCost(g, q)) : rawNeed;
          const pulseBudget = Math.max(fee * 4, Math.min(0.12 * B, effNeed));
          const expectedFree = Math.max(100, (Lq - left) * share + left * Math.max(0.20, share));
          c = Math.min(c, (pulseBudget + fee) / expectedFree + 2 + 0.8 * dq);
        } else if (bleeding) {
          c *= P.bleedDiscount;
        } else if (P.thinDiscount < 1 && tD < P.thinMaxTD && dq < 0.65 * dMe) {
          c *= P.thinDiscount;
        }

        const isStaleHardAgg =
          P.a06AggMemGate > 0 &&
          !this.isNoFullSend &&
          g.t >= 4800 &&
          !onMe &&
          humanNbs.length >= 3 &&
          rawNeed > 0.65 * B &&
          dq > 0.80 * dMe;

        if (q === aggQ && !nearCollapse && !isStaleHardAgg) {
          const baseNeedNoIn = Math.max(1, this.elimCost(g, q) - myAtk);
          const defDisc = g.t < 4200 && B <= 100 * L ? P.defendDiscountMid : P.defendDiscount;
          c = Math.min(c, (defDisc * (baseNeedNoIn + fee)) / baseGain);
        }

        const steps = (0.75 * Lq) / Math.max(1, this.cnt[q]);
        if (this.cnt[q] < 25 && steps > P.contactStepsMax && !nearCollapse && !onMe) {
          c *= 1 + P.contactPenalty * Math.min(400, steps - P.contactStepsMax);
        }

        let rankMult = 1.0;
        if (atkOnBoss > 0 || bossAtkOnQ > 0) {
          // Moderate assist bias for Boss's target (10% poke already handled in tryEmergencyBossRescue)
          c *= 0.78;
          rankMult *= 0.72;
        } else if (clanAllyAtkers > 0 || allyAtk > 0.06 * Bq) {
          c *= 0.82;
          rankMult *= 0.78;
        } else if (atkOnAlly > 0.08 * Bq) {
          c *= 0.85;
          rankMult *= 0.82;
        }
        if (
          (P.aggMemMode === 2 ||
            (P.aggMemMode === 8 && g.t >= 4500 && !bleeding && !nearCollapse && nHumans <= 20)) &&
          q === aggQ &&
          !nearCollapse &&
          !isStaleHardAgg
        ) {
          rankMult *= 0.82;
        }
        if (q === focusQ && !nearCollapse) {
          const inRankWindow =
            (P.focusRankOnly === 1 && B <= 100 * L && g.t < 3800) ||
            (P.focusRankOnly === 2 && B <= 100 * L && g.t >= 2950 && g.t < 3800);
          if (inRankWindow) {
            rankMult *= P.focusBonus;
          } else {
            c *= P.focusBonus;
          }
        }

        const newNbs = nHumans >= 3 ? this.newHumansExposed(g, q) : 0;
        if (g.t < 2500 && nHumans >= 4) {
          if (newNbs === 0) c *= P.pocket0Mult;
          else if (newNbs === 1) c *= P.pocket1Rank;
        }
        if (P.latePocketMode > 0 && g.t >= 3500 && nHumans >= 5 && humanNbs.length >= 3 && !nearCollapse && !bleeding && !onMe) {
          if (newNbs === 0) rankMult *= 0.85;
          else if (newNbs >= 2) rankMult *= 1.18;
        }

        if (g.t >= 2500 && nHumans >= 3 && humanNbs.length === 1 && !nearCollapse && !bleeding && !onMe && newNbs > 0) {
          c *= P.soleBufferPenalty;
        }

        if (q === topRival && g.t >= 3500 && g.terr[me] + Lq >= P.topRivalMinShare * g.land && B >= 0.70 * Bq && (this.cnt[q] ?? 0) >= 35 && !nearCollapse) {
          if (q === focusQ) {
            c *= P.topRivalFocusMult;
          } else if (nHumans <= 3 && !onMe) {
            c *= P.topRival3Mult;
          } else if (P.topRivalStrikeMult < 1 && B >= 1.10 * Bq && !onMe) {
            c *= P.topRivalStrikeMult;
          }
        }

        const shadowedByTop = P.leaderHardFrom > 0 && !this.isNoFullSend && g.t >= P.leaderHardFrom && topRival >= 0 && g.terr[topRival] > L && g.bal[topRival] > B;
        const isGiantTopRival = P.a06AloneSafe > 0 && !this.isNoFullSend && q === topRival && g.t >= 4800 && Bq > 1.15 * B && dq >= 120 && rawNeed > 1.5 * B;
        const isLeaderFortress =
          P.leaderHardFrom > 0 &&
          !this.isNoFullSend &&
          g.t >= P.leaderHardFrom &&
          L >= P.leaderMinShare * g.land &&
          nHumans >= 5 &&
          dq >= 0.90 * dMe &&
          (Bq >= 0.30 * B || dq >= 120) &&
          rawNeed > 0.45 * B;
        const baseHard =
          q !== focusQ &&
          !nearCollapse &&
          !bleeding &&
          !onMe &&
          ((q !== topRival && ((dq > 1.08 * dMe && Bq >= 0.70 * B) || (shadowedByTop && dq >= 110 && Bq >= 0.55 * B))) ||
            isLeaderFortress || isGiantTopRival);
        const stageMatch =
          P.guardMode === 1
            ? nHumans >= 5 && g.terr[me] + Lq < 0.50 * g.land
            : P.guardMode === 2
              ? nHumans <= 5 || g.terr[me] + Lq >= 0.50 * g.land
              : P.guardMode === 3;
        const isCrowdedHard = baseHard && stageMatch;
        if (isCrowdedHard && P.crowdedHardPenalty > 1) {
          c *= P.crowdedHardPenalty;
        }

        const pulseMode =
          nearCollapse ||
          bleeding ||
          ((tD < P.thinMaxTD || rawNeed > 0.30 * B) && !(g.t < 2400 && !onMe && rawNeed > 0.35 * B));
        out.push({
          q,
          person: true,
          tD,
          need: rawNeed,
          c,
          rankC: c * rankMult,
          pulseMode,
          nearCollapse,
          bleeding,
          onMe,
          inAtk,
          newNbs,
          isCrowdedHard,
          isAgg: q === aggQ,
        });
      }
    }

    if (P.seaCore > 0 && g.t >= 1000) {
      for (const dh of doorHarvestCandidates(g, me, this.seaState, {
        maxBoats: 5,
        atkFreshBoats: P.atkFreshBoats > 0,
        baseRatePer10: P.seaRebateMode > 0 ? this.baseRate(g) : 0,
      })) {
        if (g.terr[dh.q] < 1200) continue;
        out.push({
          q: dh.q,
          person: true,
          isDoorSea: true,
          doorInfo: dh,
          tD: dh.tD,
          need: dh.boatTroops * (dh.spots?.length ?? 1),
          c: dh.c,
          rankC: dh.c,
          pulseMode: true,
          nearCollapse: dh.nearCollapse,
          bleeding: true,
          onMe: false,
          inAtk: 0,
        });
      }
    }

    return out.sort((a, b) => (a.rankC ?? a.c) - (b.rankC ?? b.c));
  }

  buyLand(g) {
    const P = this.p, me = this.me;
    const B = g.bal[me], L = Math.max(1, g.terr[me]), fee = iV(12 * B, 1024);
    const dMe = B / L;
    const dMedOther = this.otherHumanMedDens(g);
    const nHumans = this.livingHumanCount(g);
    const humanNbCount = this.nb.filter((p) => g.alive[p] && this.person(g, p)).length;

    const m = P.maxW * this.winRatio(g.t);
    const refDens = dMedOther !== null && g.t >= P.marketFrom ? Math.max(dMe, P.marketFloor * dMedOther) : dMe;
    const worth = m * refDens;
    const over = P.surplus > 0 && B > 100 * L;
    const cheap = P.growth > 0 ? 0.1 / this.baseRate(g) : 0;

    for (const o of this.offers(g)) {
      const { q, c, need, person } = o;

      if (c >= worth && c >= cheap && !over) break;

      const isSoleHealthyBuffer =
        person && !o.isDoorSea && nHumans >= 3 && !o.nearCollapse && !o.bleeding && !o.onMe && o.newNbs > 0 && humanNbCount === 1;
      if (isSoleHealthyBuffer && c >= worth && c >= cheap && B < P.overHumanCap * 100 * L) {
        continue;
      }

      if (person && !o.isDoorSea && g.terr[q] < 250 && fee > 2 * need && c > 8 * worth && nHumans >= 3) {
        continue;
      }

      const hardCapMult = o.isCrowdedHard && c >= 2.15 * worth && g.bal[q] >= 0.55 * B ? 1.50 : P.crowdedHardCap;
      if (person && !o.isDoorSea && o.isCrowdedHard && c >= worth && c >= cheap && B < hardCapMult * 100 * L) {
        continue;
      }

      if (P.absorbMode >= 1 && person && !o.isDoorSea && !o.nearCollapse && (o.inAtk ?? 0) >= P.absorbWaveMin * B) {
        continue;
      }

      if (o.isDoorSea) {
        const dh = o.doorInfo;
        const spots = dh.spots?.length ? dh.spots : [{ d: dh.d, waterPix: dh.water, dir: dh.dir, landPix: dh.landing }];
        const safe = Math.min(this.safeAt(g, -1), P.oppFloorCap * L);
        const combinedFee = iV((32 * spots.length + 12) * B, 1024);
        if (B - combinedFee - dh.boatTroops * spots.length < safe || dh.c >= 0.90 * worth) continue;
        let launched = 0;
        for (const sp of spots) {
          const curB = g.bal[me];
          if (curB < 200 || g.boatCount[me] >= 5) break;
          const sendTr = Math.max(30, dh.boatTroops);
          const pct = Math.max(0, Math.min(1023, Math.ceil((sendTr * 1024) / curB) - 1));
          const ok = g.boatTo ? g.boatTo(pct, sp.landPix, me, 12) : g.boat(pct, sp.waterPix, sp.dir, me);
          if (ok) {
            this.seaState.stats.door_harvest.boats++;
            this.seaState.stats.door_harvest.fee += iV(32 * curB, 1024);
            this.seaState.stats.door_harvest.troops += sendTr;
            this.boats++;
            launched++;
          }
        }
        if (launched > 0) {
          this.seaState.pendingHandoffs.set(q, {
            expireTick: g.t + 90,
            initialCnt: 0,
            landings: spots.slice(0, launched).map((s) => s.landPix),
            wantTroops: Math.floor(P.pulseFrac * g.bal[me]),
          });
          this.cmds++;
          return true;
        }
        continue;
      }

      let safe = this.safeAt(g, q);
      if (!person || o.nearCollapse || (P.bleedSafeCap > 0 && (o.bleeding || o.tD < 0.45))) {
        const capPerPx = person && o.nearCollapse && (o.inAtk ?? 0) < 0.02 * B && ((c < 0.25 * worth && need <= 0.10 * B) || (g.bal[q] <= 0.05 * B && c < 25)) ? Math.min(P.oppFloorCap, P.collapseFloorCap ?? 85) : P.oppFloorCap;
        safe = Math.min(safe, capPerPx * L);
      }

      let keep = Infinity;
      if (c < cheap) keep = 0;
      if (c < worth) {
        const worthOwn = P.ownWorthMinKeep > 0 && g.t >= P.ownWorthFrom && !o.nearCollapse ? m * dMe : worth;
        const budget = Math.max(0, (worthOwn * L - fee * m - c * L) / (1 + m));
        const minKeep = person && (o.nearCollapse || (P.bleedDiscount < 1 && o.bleeding) || (P.thinDiscount < 1 && o.tD < P.thinMaxTD)) ? (0.70 * c * L) / m : (c * L) / m;
        keep = Math.min(keep, P.post > 0 ? Math.max(minKeep, B - fee - budget) : minKeep);
      }
      const isSiegeShrink =
        P.siegeShrinkRatio > 0 &&
        !this.isNoFullSend &&
        g.t >= P.leaderHardFrom &&
        L < P.siegeShrinkRatio * (g.peak?.[me] ?? L) &&
        nHumans >= 4 &&
        person &&
        !o.nearCollapse &&
        !o.bleeding;
      if (isSiegeShrink && c >= worth && c >= cheap && B < P.crowdedHardCap * 100 * L) {
        continue;
      }
      if (over) {
        const overKeepMult = isSoleHealthyBuffer
          ? P.overHumanKeep
          : isSiegeShrink
            ? P.siegeOverKeep
            : o.isCrowdedHard
              ? 1.08
              : P.hold;
        keep = Math.min(keep, overKeepMult * 100 * L);
      }
      keep = Math.max(keep, safe);

      const avail = B - fee - keep;
      if (avail <= 0) continue;

      if (!person) {
        if (g.hasAttack(me, q) && (!g.hasAttack(q, me) || g.attackTroopsOn(me, q) >= 0.35 * need)) continue;
        const want = 1.25 * need + 3 * this.cnt[q];
        const x = Math.min(avail, want);
        if (x < this.minCmd(g) || (x < want && x < P.chunk * B)) continue;
        return this.send(g, q, x);
      }

      const usePulseBlock =
        P.pulseFrac > 0 && (!over || (P.overPulseMode > 0 && (o.nearCollapse || o.bleeding || avail < P.chunk * B)));
      const inAtk = o.inAtk ?? 0;
      const curAtk = g.attackTroopsOn(me, q);
      const blockUndersized = (amt) => {
        if (P.counterClearMode === 6) return false;
        if (!(P.counterClearMode >= 1) || o.nearCollapse || !(inAtk > 0) || !(curAtk + amt <= 1.05 * inAtk)) return false;
        if (P.counterClearMode >= 3 && o.bleeding) return false;
        if (P.counterClearMode >= 4 && g.t < 3500) return false;
        return true;
      };

      // Helper for Combo 2 (#2470): For narrow-front land neighbours (`cnt[q] < 18`), launch 1-2 minimal
      // coastal bridgehead boats FIRST, wait 2 ticks after landing until they turn into `P_BORDER`, then fire `g.attack`!
      const tryNarrowBoatFirst = (wantLandTroops) => {
        if (
          !(P.narrowBoatFirstMode > 0) ||
          !(P.seaCore > 0) ||
          o.nearCollapse ||
          o.onMe ||
          inAtk > 0 ||
          curAtk > 0 ||
          g.hasAttack(me, q) ||
          this.seaState.pendingHandoffs.has(q) ||
          (this.cnt[q] ?? 0) >= 18 ||
          g.terr[q] < 5000 ||
          !g.boatsAllowed ||
          !g.boatsAllowed(me) ||
          g.boatCount[me] >= 5
        ) {
          return false;
        }
        const oneBoatFee = iV(32 * B, 1024);
        if (oneBoatFee > 0.14 * wantLandTroops) return false;
        const spots = findCoastalBridgeheads(g, me, this.seaState, q, {
          maxWaterDist: 18,
          maxSpots: Math.min(2, 5 - g.boatCount[me]),
          minSpacing: 22,
        });
        if (!spots.length) return false;
        let launched = 0;
        const landedList = [];
        for (const sp of spots) {
          const curB = g.bal[me];
          if (curB < 500 || iV(32 * curB, 1024) > 0.14 * wantLandTroops) break;
          const sendTr = Math.max(60, Math.ceil(6 * Math.exp(P.boatDecay * sp.d)));
          const pct = Math.max(0, Math.min(1023, Math.ceil((sendTr * 1024) / curB) - 1));
          const ok = g.boatTo ? g.boatTo(pct, sp.landPix, me, 12) : g.boat(pct, sp.waterPix, sp.dir, me);
          if (ok) {
            this.seaState.widenLandings ??= new Map();
            const wl = this.seaState.widenLandings.get(q) ?? [];
            wl.push(sp.landPix);
            this.seaState.widenLandings.set(q, wl);
            this.seaState.widenCount.set(q, (this.seaState.widenCount.get(q) ?? 0) + 1);
            this.seaState.stats.widen.boats++;
            this.seaState.stats.widen.fee += iV(32 * curB, 1024);
            this.boats++;
            landedList.push(sp.landPix);
            launched++;
          }
        }
        if (launched > 0) {
          this.seaState.pendingHandoffs.set(q, {
            expireTick: g.t + 75,
            initialCnt: this.cnt[q] ?? 0,
            landings: landedList,
            wantTroops: wantLandTroops,
          });
          this.cmds++;
          return true;
        }
        return false;
      };

      if (usePulseBlock) {
        // Combo 3 (#1): Use `attack(0)` exact 1-ring draw ONLY for non-kill probing (`1.20 * need > capFrac`),
        // where sending `12%` would only take 1-2 rings and burn its leftover tail troops on the next ring!
        // When `1.20 * need <= capFrac` (target is weak enough to be conquered across multiple rings in one go),
        // send the full multi-ring amount `x`!
        const cntQ = Math.max(1, this.cnt[q] ?? 1);
        const ring1Def = iV(cntQ * g.bal[q], 1 + iV(10 * g.terr[q], 16));
        const ring1Cost = cntQ * 2 + 2 * ring1Def + inAtk + 1;
        const recentHit = g.t - (this.hitTo.get(q) ?? -999) < 12;
        const canZeroPulse = (amt) =>
          !g.online && P.zeroPulseMode > 0 &&
          !o.nearCollapse &&
          (!o.bleeding || P.exactRingMode >= 2) &&
          inAtk === 0 &&
          curAtk === 0 &&
          !g.hasAttack(me, q) &&
          !recentHit &&
          cntQ >= 18 &&
          1.20 * need > amt &&
          ring1Cost >= 2.5 * fee &&
          ring1Cost <= avail &&
          amt < 1.85 * ring1Cost;

        // Multi-ring exact alignment (`exactRingMode`): when `amt >= 1.85 * ring1Cost` and `1.20 * need > amt`,
        // trim `amt` to the exact cost of `K` full rings + `2 * cntQ` so the `(K+1)`-th ring tail is returned to `bal[me]`!
        const alignMultiRing = (amt) => {
          if (!(P.exactRingMode > 0) || o.nearCollapse || curAtk > 0 || 1.20 * need <= amt || cntQ < 16) return amt;
          let remB = g.bal[q], remL = g.terr[q], total = 0, rings = 0;
          for (let r = 0; r < 6; r++) {
            const def = iV(cntQ * remB, 1 + iV(10 * remL, 16));
            const cost = cntQ * 2 + 2 * def + (r === 0 ? inAtk : 0);
            if (total + cost + cntQ > amt) break;
            total += cost;
            rings++;
            remB = Math.max(0, remB - def);
            remL = Math.max(1, remL - cntQ);
          }
          if (rings >= 1 && amt - total > 2.5 * cntQ) {
            const trimmed = total + 2 * cntQ;
            if (trimmed >= Math.max(this.minCmd(g), P.pulseMinShare * B)) return trimmed;
          }
          return amt;
        };

        if (g.t >= 3800 && (o.nearCollapse || o.bleeding || (P.aggMemMode === 2 && o.isAgg))) {
          if (curAtk >= 0.08 * B || curAtk >= 0.65 * need) continue;
          const targetSlot = Math.min(0.85 * need + 3 * this.cnt[q], Math.floor(P.pulseFrac * B));
          let pulse = Math.min(avail, Math.max(targetSlot - curAtk, Math.floor(0.08 * B)));
          if (P.counterClearMode === 2 && !o.nearCollapse && inAtk > 0 && curAtk + pulse <= 1.05 * inAtk) {
            pulse = Math.min(avail, Math.min(Math.floor(0.28 * B), Math.ceil(1.05 * inAtk - curAtk + 0.05 * B)));
          }
          if (blockUndersized(pulse)) continue;
          pulse = alignMultiRing(pulse);
          if (pulse < Math.max(this.minCmd(g), P.pulseMinShare * B)) continue;
          if (tryNarrowBoatFirst(pulse)) return true;
          return canZeroPulse(pulse) ? this.send(g, q, 1, pulse) : this.send(g, q, pulse);
        }

        if (o.nearCollapse) {
          if (curAtk >= 0.04 * B || curAtk >= 0.30 * need) continue;
          const pulse = Math.min(avail, Math.max(Math.floor(P.pulseFrac * B), Math.min(avail, Math.floor(0.30 * need))));
          if (pulse < Math.max(this.minCmd(g), P.pulseMinShare * B)) continue;
          return this.send(g, q, pulse);
        }

        if (o.pulseMode) {
          if (curAtk >= 0.04 * B) continue;
          let capFrac = Math.floor(P.pulseFrac * B);
          if (P.counterClearMode === 2 && inAtk > 0) {
            capFrac = Math.max(capFrac, Math.min(Math.floor(0.28 * B), Math.ceil(1.05 * inAtk - curAtk + 0.05 * B)));
          }
          const want = Math.min(1.20 * need + 3 * this.cnt[q], capFrac);
          let x = Math.min(avail, want);
          if (blockUndersized(x)) continue;
          x = alignMultiRing(x);
          if (x < Math.max(this.minCmd(g), P.pulseMinShare * B)) continue;
          if (tryNarrowBoatFirst(x)) return true;
          return canZeroPulse(x) ? this.send(g, q, 1, x) : this.send(g, q, x);
        }
      }

      const want = 1.25 * need + 3 * this.cnt[q];
      const x = Math.min(avail, want);
      if (x <= 0 || (x < want && (x < P.chunk * B || (P.pplKill > 0 && person)))) continue;
      if (person && blockUndersized(x)) continue;
      if (person && tryNarrowBoatFirst(x)) return true;
      return this.send(g, q, x);
    }
    return false;
  }

  boatFood(g) {
    const P = this.p, me = this.me;
    if (!(P.seaCore > 0)) return super.boatFood(g);
    if (this.neutral > 0 || g.t - (this.lastFood ?? -1e9) < P.boatEvery) return false;
    let activeHops = 0;
    if (this.seaState.inFlightIsles) {
      for (const [, expT] of this.seaState.inFlightIsles) if (g.t < expT) activeHops++;
    }
    if (!g.boatsAllowed(me) || g.boatCount[me] - activeHops >= P.maxBoats) return false;
    for (const q of this.nb) if (g.alive[q] && !this.person(g, q) && this.price(g, q) <= P.botMax) return false;
    this.lastFood = g.t;
    const hit = this.searchFood(g);
    if (!hit || hit.eff > P.botMax) return false;
    const bal = g.bal[me];
    const { floorAt } = this.floors(g);
    const floor = Math.max(this.reserve(g, hit.price), floorAt(hit.price));
    const max = P.boatFrac * (bal - floor);
    const min = Math.max(60, P.feeK * iV(32 * bal, 1024));
    if (max < min) return false;
    const fullAmount = Math.min(max, Math.max(P.foodK * hit.cost, min));

        const v = g.px[hit.land];
    if (!this.isMopUp(g) && v >= P_INNER) {
      const o = g.own[hit.land];
      // Exploit #15 (`t % 51 === 45` 60-px bot boat-interception blind spot):
      if (P.botPhaseMode > 0 && o >= 0 && g.isBot(o) && (45 - (g.t % 51) + 51) % 51 <= 6) {
        this.lastFood = g.t - P.boatEvery + P.period;
        return false;
      }
      if (fullAmount > 600 && o >= 0 && o !== me && g.alive[o] && g.terr[o] >= 200 && !this.seaState.pendingHandoffs.has(o)) {
        const landCost = this.elimCost(g, o);
        const grow = Math.max(1.0, hit.cost / Math.max(1, landCost));
        const seaLoss = fullAmount * (1 - 1 / grow);
        const landFee = iV(12 * bal, 1024);
        if (seaLoss > landFee + 250) {
          const doDens = g.bal[o] / Math.max(1, g.terr[o]);
          const bridgeAmt =
            P.atkFreshBoats > 0 && g.attackTroopsOn(o, me) === 0 && !g.hasAttack(me, o)
              ? Math.min(fullAmount, Math.max(60, Math.ceil(6 * grow)))
              : Math.min(fullAmount, Math.max(60, Math.ceil((3 * (2 + 3.2 * doDens) + 25) * grow)));
          const pct = Math.max(0, Math.min(1023, Math.ceil((bridgeAmt * 1024) / bal) - 1));
          if (g.boatTo(pct, hit.land, me)) {
            this.seaState.pendingHandoffs.set(o, {
              expireTick: g.t + 160,
              initialCnt: 0,
              landings: [hit.land],
              wantTroops: Math.floor(fullAmount / grow),
            });
            this.boats++;
            this.cmds++;
            return true;
          }
        }
      }
    }

    const pct = Math.max(0, Math.min(1023, Math.ceil((fullAmount * 1024) / bal) - 1));
    if (!g.boatTo(pct, hit.land, me)) return false;
    this.boats++;
    this.cmds++;
    return true;
  }

  searchFood(g) {
    if (this.isMopUp(g)) {
      const oldRange = this.p.boatRange;
      this.p.boatRange = 2500;
      const hit = super.searchFood(g);
      this.p.boatRange = oldRange;
      if (hit) hit.eff = Math.min(hit.eff, 2);
      return hit;
    }
    const hit = super.searchFood(g);
    if (!hit || !(this.p.foodRebate > 0)) return hit;
    const me = this.me, B = g.bal[me], L = Math.max(1, g.terr[me]);
    if (B > 100 * L) {
      const estTicks = 80;
      const rebate = futureInterestRebate(g, me, Math.min(hit.cost, 0.28 * B), estTicks, this.baseRate(g));
      if (rebate > 0) {
        const gain = Math.max(1, (hit.cost + iV(32 * B, 1024)) / Math.max(1, hit.eff));
        hit.eff = Math.max(2, hit.eff - rebate / gain);
      }
    }
    return hit;
  }
}
