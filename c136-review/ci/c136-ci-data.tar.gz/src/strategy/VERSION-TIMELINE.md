# 策略、选点与引擎版本精确时间线（供 R01~R10 代码行级对账）

## 1. `squad10`（A 组，`A001~A099`）三阶段完整源码对照

所有文件均已补齐在 `/agent/repos/c136-data/src/strategy/` 下：

| 阶段代号 | 覆盖对局 | UTC 时间范围 | 策略源码文件 | 选点源码文件 | 核心参数与调度特征 |
| :-: | :-- | :-- | :-- | :-- | :-- |
| **Va (`E1`)** | `A001 ~ A017` | `11-08 18:12 ~ 11-09 16:02` | `v27-team-c116-va.js` | `spawn-coordinator-c116-va.mjs` | `oppFloorCap=78, pulseFrac=0.20, focusBonus=0.78, overPulseMode=1`；`[HL-ASSIST]` 无 36 拍冷却（`dMe>=38, B>=8000, pct=102`）；`tryDonateToTeammate` 冷却 `12` 拍、`bal>=30000`、`prodOptFloor=boxedIn?(72L:66L):max(94L,safeAt)`、`emergDefFloor=boxedIn?(32L:22L):max(88L,safeAt)`、`underFire reqD=boxedIn?(42:30):102`、常态 `reqD=boxedIn?82:108`、`maxAllyD=boxedIn?(140:128):96`、`idealPct` 防守 `260/190` 进攻 `225/170`、`pct<128` 退出；选点 `r1=1.38*rCell, r2=2.35*rCell, innerCount=3`。 |
| **Vb (`E2`)** | `A018 ~ A095` | `11-09 23:33 ~ 11-10 10:17` | `v27-team-c116-vb.js` | `spawn-coordinator-c116-vb.mjs` | 由 `2026-11-09T23:34:05Z` 的 `apply_s01_s10_fixes.mjs` 热更生成（白天 74 场有效局全跑此版）：`oppFloorCap=88, pulseFrac=0.12, focusBonus=1.0, overPulseMode=0, soleBufferPenalty=1.60, crowdedHardPenalty=1.35`；`[HL-ASSIST]` 加 `36` 拍冷却与 `dMe>=86`；`tryDonateToTeammate` 冷却仍为 `12` 拍，但 **`prodOptFloor` 下调至 `boxedIn?(44L:34L)`，常态 `reqD` 下调至 `boxedIn?58:108`，且 `boxedIn` 分支缺少 `dMe >= dAlly + 15` 约束（导致 `dMe=58` 的内陆号向 `dAlly=135` 的前线号倒挂输血！）**，`idealPct` 暴涨至防守 `380/240`、进攻 `320/220`（`pct<180` 退出）；选点扇区收紧为 `r1=1.12*rCell (66..108), r2=1.88*rCell (122..182), fanHalf=PI/3.2, innerCount=3`（1 Apex + 3 Inner = 4 个内圈号扎堆憋死）。 |
| **Vc (`E3`)** | `A097 ~ A099` | `11-10 14:27 ~ 11-10 14:42` | `v27-team-c116.js` | `spawn-coordinator-c116.mjs` | 由 `2026-11-10T14:16:33Z` 的 `fix_c116_daytime_rootcause.mjs` 生成：冷却改为 `24` 拍、`bal>=35000`、`prodOptFloor` 恢复 `76L/70L`、`emergDefFloor` `58L/48L`、强制 `dMe >= dAlly + 15` 且 `dAlly < 85`（防守）/ `<= 94/88`（常态）、`reqD=96/108`、`idealPct` `260/190` 与 `220/170`（`pct<150` 退出）；选点改为 `r1=1.32*rCell, r2=2.28*rCell, fanHalf=PI/2.55, innerCount=2`。 |

> **注：** 在 `Va`、`Vb`、`Vc` 三个阶段中，`2026-11-08T07:58:30Z` 的 `fix_buyland_first_and_frontline_floor.mjs` 已经把 `act(g)` 开头 `buyLand(g)` 之前的 `tryDonateToTeammate(g, true)` 移除，因此在 `A001~A099` 中，`tryDonateToTeammate(g)` 均在 `buyLand(g)` 之后且 `this.cmds === cmdsBefore` 时调用。

---

## 2. `squad20`（B 组，`B001~B050`）与 `squad8`（G 组，`G00~G09`）源码对照

- **`squad8`（`G00 ~ G09`，11-07 晚 ~ 11-08 凌晨）：** 对应 `v27-team-g09.js`。
- **`squad20`（`B001 ~ B050`）：** 对应 `v27-team-c110.js`、`make_v27_team.py` 与 `spawn-coordinator-c110.mjs`（注：`2026-11-10T14:08:38Z` 仅将 `if (bossId >= 0)` 改为 `if (true)` 启用无 Boss 时的后端选点协调，局内 `buyLand` / `tryDonateToTeammate` 参数不变）。

---

## 3. 引擎双版本与模拟器全量地图二进制文件已补齐

1. **引擎双版本（`/agent/repos/c136-data/src/engine/`）：**
   - `live_game_js_2171.js`：sha256 `2b5731c7247dad761598fb8d978cb96b485e3264f4cef8f82c951b1c1d1dcba6`（版本 `2.17.1`，与 `engine-evidence.txt` 字节偏移 100% 对应）。
   - `live_game_js.js`：sha256 `c7d41fee823185ea4d0ffaf6557141bce9d5b387fea67b5502b63d7139f5f551`（版本 `2.17.4`，局内经济/战斗/捐款/海战/AI 逻辑与 `2.17.1` 零差异）。
2. **模拟器地图二进制（`/agent/repos/c136-data/src/sim/maps/`）：**
   - 已拷入全部 62 份 `<mapId>_<seed>.bin.gz` 地图文件，可直接配合 `src/sim/` 与 `replay.txt` 进行 512 玩家逐拍重演。

---

## 4. 关于 `event=left`、名字轮换与录像真账本（R03/R05/R10 核实汇总）

1. **录像指令流 = 引擎真实执行账本：**
   - 引擎 `live_game_js.js` 中，进攻/捐款/发船写入录像 `bC.rg.rh(id, ...)` 的位置在所有前置校验（含受捐方 `ao.ei` 反喂养配额校验）**之后**。
   - 因此，解码 `replay.txt` 中的 `type=2`（捐款）指令流即可精确得到每笔 `[HL-DISPATCH]` / `[HL-DONATE]` 是否真正被引擎执行、以及实际落地的服务器拍号（可直接使用 `c136-review/agents/R05/scripts/replay_cmds.mjs` 与 `donation_ledger.mjs`，或 `R03/scripts/replay-cmds.mjs`）。
2. **`B` 组（`squad20`）局内行首名字轮换：**
   - `B` 组的 worker 名字池按定时器轮换日志前缀名，但局内座位号 `me`（`meId`）、游戏内真实昵称（出现在 `ally=id(name)` 与录像 header 中）以及 `cmds / boats / maxMs` 轨迹在整局内连续不变。复盘 `B` 组时请以 `meId`（及 `c136-review/agents/R10/out/rooms/identity-map-discovery.csv`）串联同一槽位的完整生命周期。
3. **`results.csv` 中的 `event=left` 触发原因：**
   - 当某个 worker 发生连接断开（`socket close index 2/3`）或连续 3 次 `evalJs` 超时（4.5s watchdog）时，外层会触发 `sbLeave(true)` 或重启 worker，记下一条当时的本地 `tick` 且 `event=left, team=null`。遇到 `left` 行应视为中途掉线/离场（此后该席位在引擎内转为状态 2 由内置难度 6 AI 接管，不再获发利息），不要误判为被敌方打死（`died`）。
